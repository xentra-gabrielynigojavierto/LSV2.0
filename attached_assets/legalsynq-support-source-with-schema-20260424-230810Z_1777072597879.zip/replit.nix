{pkgs}: {
  deps = [
    pkgs.zip
    pkgs.mysql80
  ];
}

# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5 (TS) + .NET 8 ASP.NET Core (Support service)
- **Database**: PostgreSQL + Drizzle ORM (TS) + MySQL via Pomelo + EF Core 8 (Support service)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec) — used by `lib/api-client-react`; the
  Support service is consumed by a hand-written client to honor its integer-enum contract.
- **Build**: esbuild (CJS bundle)

## Artifacts

- `artifacts/api-server` — Express 5 API for the original product surface.
- `artifacts/mockup-sandbox` — Vite preview server for design / canvas mockups.
- `artifacts/support-ui` — **Support Portal** portal (React + Vite + Tailwind v4 +
  wouter + TanStack Query 5 + react-hook-form + zod + shadcn UI). Talks to the
  `services/support` .NET API at `/support/api/*`. In dev/preview it uses MSW
  with 5 seeded tickets so it runs standalone. Hand-written API client with
  numeric enum maps mirroring `services/support/.../Domain/Enums.cs` and
  `Domain/SupportTicketComment.cs` (CommentVisibility is `Internal=0,
  CustomerVisible=1` — do not invert). Built in SUP-B05; queues + assignment
  shipped in SUP-B06 (assignment panel on ticket detail, `/support/queues`
  admin page, ticket-list assignment filters). Reports at
  `analysis/SUP-B05-report.md` and `analysis/SUP-B06-report.md`. 39/39 vitest.

## Backend services (non-pnpm)

- `services/support` — .NET 8 / EF Core 8 / Pomelo MySQL Support service
  (SUP-B01..B08). Ticket / Comment / Timeline / Attachment / ProductReference
  / Queue / QueueMember domain. JWT-bearer auth with tenant resolved from
  claims; RBAC via `SupportRead` / `SupportInternal` / `SupportManage`
  policies. SUP-B07 added an `INotificationPublisher` abstraction (NoOp
  default, opt-in HTTP adapter via `Support:Notifications:Mode=Http`) that
  emits `support.ticket.{created,updated,status_changed,assigned,
  comment_added}` from the service layer; failures never break writes; report
  at `analysis/SUP-B07-report.md`. SUP-B08 added a parallel `IAuditPublisher`
  abstraction (same NoOp / Http pattern, `Support:Audit:Mode`) plus an
  `IActorAccessor` for JWT-claim-based actor / correlation enrichment;
  emits 12 compliance events
  (`support.ticket.{created,updated,status_changed,assignment_changed,
  comment_added,attachment_added,product_ref_linked,product_ref_removed}` +
  `support.queue.{created,updated,member_added,member_removed}`) from the
  service layer with the same failure-isolation contract; comment bodies
  and file contents are never placed in audit metadata; report at
  `analysis/SUP-B08-report.md`. 107/107 unit + integration tests
  (`dotnet test services/support`).

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run Express API server locally
- `pnpm --filter @workspace/support-ui run dev` — run the Support portal (Vite)
- `pnpm --filter @workspace/support-ui run test` — Vitest suite for the Support portal
- `dotnet test services/support` — Support service unit + integration tests

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

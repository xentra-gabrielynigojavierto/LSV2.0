import React from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ChevronsUpDown, UserCog } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { applyPersona } from "@/lib/auth/devSession";
import { DEV_PERSONAS, isCustomerPersona, type DevPersona } from "@/lib/auth/personas";
import { useCurrentPersona } from "@/hooks/useCurrentPersona";

interface RoleSwitcherProps {
  /** Base path of the artifact (e.g. "/support") so navigation respects the proxy prefix. */
  basePath: string;
}

/**
 * Dev-only sidebar control that swaps the active persona. Available roles
 * mirror Support.Api/Auth/SupportRoles.cs so policy decisions match what a
 * real JWT would produce. In production builds this component is never
 * rendered (see AppShell).
 */
export function RoleSwitcher({ basePath }: RoleSwitcherProps) {
  const persona = useCurrentPersona();
  const queryClient = useQueryClient();

  const onPick = (next: DevPersona) => {
    if (next.id === persona.id) return;
    applyPersona(next);
    // Bust every cached response — different personas can see different
    // ticket sets (and different visibility on comments), so leftover data
    // would confuse the new view.
    queryClient.clear();
    // Hard navigation forces every component (including route-level guards)
    // to re-evaluate against the new persona without manually wiring soft
    // navigation across the wouter base path.
    const target = basePath.replace(/\/$/, "") + next.landingPath;
    window.location.assign(target);
  };

  const grouped = {
    staff: DEV_PERSONAS.filter((p) => !isCustomerPersona(p)),
    customers: DEV_PERSONAS.filter((p) => isCustomerPersona(p)),
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className="w-full flex items-center gap-3 rounded-md p-2 text-left hover:bg-sidebar-accent/60 transition-colors group"
        data-testid="role-switcher-trigger"
      >
        <div className="h-8 w-8 rounded-full bg-sidebar-accent flex items-center justify-center text-xs font-medium border border-sidebar-border">
          {persona.initials}
        </div>
        <div className="flex flex-col min-w-0 flex-1">
          <span
            className="text-sm font-medium leading-none mb-1 truncate"
            data-testid="role-switcher-name"
          >
            {persona.displayName}
          </span>
          <span
            className="text-xs text-sidebar-foreground/60 leading-none truncate"
            data-testid="role-switcher-role"
          >
            {persona.roleLabel}
          </span>
        </div>
        <ChevronsUpDown className="h-3.5 w-3.5 text-sidebar-foreground/40 group-hover:text-sidebar-foreground/70 shrink-0" />
      </DropdownMenuTrigger>
      <DropdownMenuContent
        side="top"
        align="start"
        className="w-64"
        data-testid="role-switcher-menu"
      >
        <DropdownMenuLabel className="flex items-center gap-2 text-xs">
          <UserCog className="h-3.5 w-3.5" />
          Dev: switch persona
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold pt-1 pb-1">
            Internal staff
          </DropdownMenuLabel>
          {grouped.staff.map((p) => (
            <PersonaItem
              key={p.id}
              persona={p}
              active={p.id === persona.id}
              onPick={onPick}
            />
          ))}
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold pt-1 pb-1">
            Tenant users
          </DropdownMenuLabel>
          {grouped.customers.map((p) => (
            <PersonaItem
              key={p.id}
              persona={p}
              active={p.id === persona.id}
              onPick={onPick}
            />
          ))}
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <div className="px-2 py-1.5 text-[11px] text-muted-foreground leading-snug">
          Switching personas clears cached data and reloads to the persona&rsquo;s landing page.
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function PersonaItem({
  persona,
  active,
  onPick,
}: {
  persona: DevPersona;
  active: boolean;
  onPick: (p: DevPersona) => void;
}) {
  return (
    <DropdownMenuItem
      onSelect={(e) => {
        e.preventDefault();
        onPick(persona);
      }}
      className="flex items-start gap-2 py-2"
      data-testid={`role-switcher-item-${persona.id}`}
    >
      <div className="h-7 w-7 rounded-full bg-muted text-muted-foreground flex items-center justify-center text-[11px] font-semibold border shrink-0 mt-0.5">
        {persona.initials}
      </div>
      <div className="flex flex-col min-w-0 flex-1">
        <span className="text-sm font-medium truncate">
          {persona.displayName}
          {active && (
            <span className="ml-2 text-[10px] text-primary uppercase tracking-wider">
              Active
            </span>
          )}
        </span>
        <span className="text-xs text-muted-foreground truncate">{persona.roleLabel}</span>
      </div>
    </DropdownMenuItem>
  );
}

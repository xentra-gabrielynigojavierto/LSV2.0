import React from "react";
import { Link, useLocation } from "wouter";
import {
  Briefcase,
  Inbox,
  LayoutDashboard,
  Settings,
  LifeBuoy,
  Users,
  FilePlus2,
  Ticket,
} from "lucide-react";
import { useCurrentPersona } from "@/hooks/useCurrentPersona";
import { isCustomerPersona } from "@/lib/auth/personas";
import { RoleSwitcher } from "@/components/layout/RoleSwitcher";

const BASE_PATH = import.meta.env.BASE_URL.replace(/\/$/, "");

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  testId?: string;
  /** Highlight when current location starts with one of these prefixes. */
  matchPrefixes?: string[];
}

const STAFF_NAV: NavItem[] = [
  {
    href: "/support",
    label: "Inbox",
    icon: Inbox,
    matchPrefixes: ["/support/tickets", "/support/new"],
    testId: "nav-inbox",
  },
  {
    href: "/support/queues",
    label: "Queues",
    icon: Users,
    matchPrefixes: ["/support/queues"],
    testId: "nav-queues",
  },
];

const CUSTOMER_NAV: NavItem[] = [
  {
    href: "/support/portal",
    label: "My Tickets",
    icon: Ticket,
    matchPrefixes: ["/support/portal/tickets"],
    testId: "nav-portal-tickets",
  },
  {
    href: "/support/portal/new",
    label: "Submit Request",
    icon: FilePlus2,
    testId: "nav-portal-new",
  },
];

function isActive(location: string, item: NavItem): boolean {
  if (location === item.href) return true;
  if (item.matchPrefixes?.some((p) => location.startsWith(p))) return true;
  return false;
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const persona = useCurrentPersona();
  const customer = isCustomerPersona(persona);
  const navItems = customer ? CUSTOMER_NAV : STAFF_NAV;

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row w-full text-sm">
      {/* Sidebar for Desktop, Top Nav for Mobile */}
      <div className="w-full md:w-60 md:shrink-0 bg-sidebar border-b md:border-b-0 md:border-r border-sidebar-border text-sidebar-foreground flex flex-col">
        <div className="p-4 flex items-center gap-3 font-semibold text-lg border-b border-sidebar-border/50">
          <div className="bg-sidebar-primary text-sidebar-primary-foreground p-1.5 rounded-md flex items-center justify-center">
            <LifeBuoy className="h-5 w-5" />
          </div>
          <span className="tracking-tight">
            {customer ? "Help Center" : "Support Portal"}
          </span>
        </div>

        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-3" data-testid="primary-nav">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(location, item);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  data-testid={item.testId}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                    active
                      ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}

            {/* Decorative product context — staff view only. */}
            {!customer && (
              <>
                <div className="pt-4 pb-1 px-3 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider">
                  Products
                </div>
                <div className="flex items-center gap-3 px-3 py-2 rounded-md text-sidebar-foreground/50">
                  <Briefcase className="h-4 w-4" />
                  Vault
                </div>
                <div className="flex items-center gap-3 px-3 py-2 rounded-md text-sidebar-foreground/50">
                  <LayoutDashboard className="h-4 w-4" />
                  SignBoard
                </div>

                <div className="pt-4 pb-1 px-3 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider">
                  Administration
                </div>
                <div className="flex items-center gap-3 px-3 py-2 rounded-md text-sidebar-foreground/50">
                  <Settings className="h-4 w-4" />
                  Settings
                </div>
              </>
            )}
          </nav>
        </div>

        <div className="p-3 border-t border-sidebar-border/50">
          {import.meta.env.DEV ? (
            <RoleSwitcher basePath={BASE_PATH} />
          ) : (
            <div className="flex items-center gap-3 p-2">
              <div className="h-8 w-8 rounded-full bg-sidebar-accent flex items-center justify-center text-xs font-medium border border-sidebar-border">
                {persona.initials}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-medium leading-none mb-1 truncate">
                  {persona.displayName}
                </span>
                <span className="text-xs text-sidebar-foreground/60 leading-none truncate">
                  {persona.roleLabel}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden h-[100dvh]">
        <div className="flex-1 overflow-auto">{children}</div>
      </main>
    </div>
  );
}

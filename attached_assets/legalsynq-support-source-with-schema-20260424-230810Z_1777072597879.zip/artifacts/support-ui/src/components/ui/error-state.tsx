import React from "react";
import { AlertCircle, RefreshCw, LogIn, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { UnauthorizedError, ForbiddenError, NotFoundError } from "@/lib/api/client";

interface ErrorStateProps {
  error: Error | null;
  onRetry?: () => void;
}

export function ErrorState({ error, onRetry }: ErrorStateProps) {
  const isUnauthorized = error instanceof UnauthorizedError;
  const isForbidden = error instanceof ForbiddenError;
  const isNotFound = error instanceof NotFoundError;

  let icon = <AlertCircle className="h-10 w-10 text-destructive mb-4" />;
  let title = "Something went wrong";
  let message = error?.message || "An unexpected error occurred while loading data.";
  let action = onRetry && (
    <Button variant="outline" onClick={onRetry} className="mt-4 gap-2">
      <RefreshCw className="h-4 w-4" />
      Retry
    </Button>
  );

  if (isUnauthorized) {
    icon = <LogIn className="h-10 w-10 text-muted-foreground mb-4" />;
    title = "Session Expired";
    message = "Your session has expired. Please sign in again to continue.";
    action = (
      <Button onClick={() => window.location.reload()} className="mt-4 gap-2">
        <LogIn className="h-4 w-4" />
        Sign In
      </Button>
    );
  } else if (isForbidden) {
    icon = <Lock className="h-10 w-10 text-muted-foreground mb-4" />;
    title = "Access Denied";
    message = "You don't have permission to access this resource.";
    action = undefined;
  } else if (isNotFound) {
    icon = <AlertCircle className="h-10 w-10 text-muted-foreground mb-4" />;
    title = "Not Found";
    message = "The requested resource could not be found.";
    action = undefined;
  }

  return (
    <div className="flex-1 flex items-center justify-center p-6 h-full w-full bg-muted/20">
      <Card className="max-w-md w-full shadow-sm border-muted">
        <CardContent className="pt-6 flex flex-col items-center text-center">
          {icon}
          <h3 className="text-lg font-semibold tracking-tight text-foreground mb-1">{title}</h3>
          <p className="text-sm text-muted-foreground">{message}</p>
          {action}
        </CardContent>
      </Card>
    </div>
  );
}

import { describe, expect, it } from "vitest";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import { AssignmentPanel } from "../AssignmentPanel";
import { renderWithProviders } from "@/test/test-utils";
import { getTicket, listTickets } from "@/lib/api/support";

describe("<AssignmentPanel />", () => {
  it("renders user input + queue selector and assigns a queue", async () => {
    const user = userEvent.setup();
    const list = await listTickets({});
    const t = list.items[0];

    renderWithProviders(<AssignmentPanel ticket={t} />);

    const input = screen.getByTestId("assignment-user-input");
    expect(input).toBeInTheDocument();
    expect(screen.getByTestId("assignment-queue-trigger")).toBeInTheDocument();

    const newAssignee = "agent-test-" + Date.now();
    await user.clear(input);
    await user.type(input, newAssignee);

    const saveBtn = screen.getByTestId("assignment-save");
    await waitFor(() => expect(saveBtn).not.toBeDisabled());
    await user.click(saveBtn);

    await waitFor(async () => {
      const fresh = await getTicket(t.id);
      expect(fresh.assignedUserId).toBe(newAssignee);
    });
  });

  it("clear button disables when ticket is unassigned", async () => {
    const list = await listTickets({});
    const t = list.items.find(
      (x) => !x.assignedUserId && !x.assignedQueueId,
    );
    if (!t) return; // skip if seed data has no unassigned ticket
    renderWithProviders(<AssignmentPanel ticket={t} />);
    expect(screen.getByTestId("assignment-clear")).toBeDisabled();
  });
});

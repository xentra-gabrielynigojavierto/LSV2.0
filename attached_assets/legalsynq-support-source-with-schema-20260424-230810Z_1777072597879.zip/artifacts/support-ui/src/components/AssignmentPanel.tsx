import React, { useEffect, useState } from "react";
import { useAssignTicket, useQueues } from "@/lib/api/hooks";
import type { Ticket } from "@/lib/api/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { UserCheck, Users, X } from "lucide-react";
import { ApiError } from "@/lib/api/client";

const NO_QUEUE = "__none__";

interface AssignmentPanelProps {
  ticket: Ticket;
  disabled?: boolean;
}

export function AssignmentPanel({ ticket, disabled }: AssignmentPanelProps) {
  const { toast } = useToast();
  const queuesQ = useQueues({});
  const assignTicket = useAssignTicket(ticket.id);

  const [userId, setUserId] = useState(ticket.assignedUserId ?? "");
  const [queueId, setQueueId] = useState<string>(
    ticket.assignedQueueId ?? NO_QUEUE,
  );

  useEffect(() => {
    setUserId(ticket.assignedUserId ?? "");
    setQueueId(ticket.assignedQueueId ?? NO_QUEUE);
  }, [ticket.assignedUserId, ticket.assignedQueueId]);

  const dirty =
    userId !== (ticket.assignedUserId ?? "") ||
    queueId !== (ticket.assignedQueueId ?? NO_QUEUE);

  const handleAssign = () => {
    const trimmed = userId.trim();
    assignTicket.mutate(
      {
        assignedUserId: trimmed === "" ? null : trimmed,
        assignedQueueId: queueId === NO_QUEUE ? null : queueId,
      },
      {
        onSuccess: () => {
          toast({
            title: "Assignment updated",
            description: "Ticket assignment saved.",
          });
        },
        onError: (err) => {
          const description =
            err instanceof ApiError && err.status === 400
              ? "The selected queue is inactive or the request is invalid."
              : err.message;
          toast({
            title: "Failed to update assignment",
            description,
            variant: "destructive",
          });
        },
      },
    );
  };

  const handleClear = () => {
    assignTicket.mutate(
      { clearAssignment: true },
      {
        onSuccess: () => {
          setUserId("");
          setQueueId(NO_QUEUE);
          toast({
            title: "Assignment cleared",
            description: "This ticket is now unassigned.",
          });
        },
        onError: (err) => {
          toast({
            title: "Failed to clear assignment",
            description: err.message,
            variant: "destructive",
          });
        },
      },
    );
  };

  const queues = (queuesQ.data ?? []).filter(
    (q) => q.isActive || q.id === ticket.assignedQueueId,
  );

  const hasAssignment = !!ticket.assignedUserId || !!ticket.assignedQueueId;
  const busy = assignTicket.isPending || disabled;

  return (
    <div className="space-y-3" data-testid="assignment-panel">
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-medium text-foreground/80 flex items-center gap-1.5">
          <Users className="h-3 w-3" />
          Queue
        </label>
        <Select
          value={queueId}
          onValueChange={setQueueId}
          disabled={busy || queuesQ.isLoading}
        >
          <SelectTrigger
            className="h-8 text-sm"
            data-testid="assignment-queue-trigger"
          >
            <SelectValue
              placeholder={queuesQ.isLoading ? "Loading…" : "Unassigned"}
            />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={NO_QUEUE} className="italic text-muted-foreground">
              Unassigned
            </SelectItem>
            {queues.map((q) => (
              <SelectItem key={q.id} value={q.id}>
                {q.name}
                {!q.isActive && (
                  <span className="text-muted-foreground"> (inactive)</span>
                )}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label
          htmlFor="assignment-user-id"
          className="text-xs font-medium text-foreground/80 flex items-center gap-1.5"
        >
          <UserCheck className="h-3 w-3" />
          Assigned User ID
        </label>
        <Input
          id="assignment-user-id"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          placeholder="agent-okafor"
          maxLength={64}
          disabled={busy}
          className="h-8 text-sm"
          data-testid="assignment-user-input"
        />
        <p className="text-[11px] text-muted-foreground">
          Free-text user ID; identity lookup is out of scope for this release.
        </p>
      </div>

      <div className="flex gap-2 pt-1">
        <Button
          size="sm"
          className="flex-1 gap-2"
          onClick={handleAssign}
          disabled={busy || !dirty}
          data-testid="assignment-save"
        >
          {assignTicket.isPending ? "Saving…" : "Save assignment"}
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={handleClear}
          disabled={busy || !hasAssignment}
          data-testid="assignment-clear"
        >
          <X className="h-3.5 w-3.5" />
          <span className="sr-only">Clear assignment</span>
        </Button>
      </div>

      {queuesQ.error && (
        <div className="text-xs text-destructive" role="alert">
          Couldn't load queues. The selector may be stale.
        </div>
      )}
    </div>
  );
}

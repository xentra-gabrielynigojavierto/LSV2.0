import React, { useState } from "react";
import { Link } from "wouter";
import {
  Plus,
  Search,
  RefreshCw,
  Inbox,
  Clock,
  MessageSquare,
} from "lucide-react";
import { useTicketList } from "@/lib/api/hooks";
import { TicketStatus, TicketPriority } from "@/lib/api/types";
import {
  ticketStatusLabel,
  ticketPriorityLabel,
  ticketStatusOptions,
} from "@/lib/api/labels";
import { formatRelative } from "@/lib/format";
import { useCurrentPersona } from "@/hooks/useCurrentPersona";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ErrorState } from "@/components/ui/error-state";
import { LoadingState } from "@/components/ui/loading-state";

const PAGE_SIZE = 50;

type Scope = "mine" | "all";

export default function PortalMyTickets() {
  const persona = useCurrentPersona();
  const [scope, setScope] = useState<Scope>("mine");
  const [statusFilter, setStatusFilter] = useState<TicketStatus | "all">("all");
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");

  const filters = {
    page: 1,
    pageSize: PAGE_SIZE,
    ...(search ? { search } : {}),
    ...(statusFilter !== "all" ? { status: statusFilter } : {}),
  };

  const { data, isLoading, error, refetch, isRefetching } = useTicketList(
    filters,
    { placeholderData: (prev) => prev },
  );

  const all = data?.items ?? [];
  // Customer-side scoping: the backend returns every ticket in the persona's
  // tenant (TenantUser passes SupportRead). To produce a useful "My Tickets"
  // list we narrow client-side to the persona's email — the same email the
  // create form auto-fills as `requesterEmail`.
  const filtered =
    scope === "mine"
      ? all.filter(
          (t) =>
            t.requesterEmail &&
            persona.email &&
            t.requesterEmail.toLowerCase() === persona.email.toLowerCase(),
        )
      : all;

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(searchInput);
  };

  if (error) {
    return <ErrorState error={error} onRetry={() => refetch()} />;
  }

  return (
    <div className="flex flex-col h-full bg-muted/30">
      <div className="bg-card border-b px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shrink-0">
        <div>
          <h1
            className="text-2xl font-bold tracking-tight text-foreground"
            data-testid="portal-tickets-heading"
          >
            My Tickets
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Track requests you&rsquo;ve submitted to support.
          </p>
        </div>
        <Link href="/support/portal/new">
          <Button className="gap-2" data-testid="portal-new-ticket-cta">
            <Plus className="h-4 w-4" />
            Submit Request
          </Button>
        </Link>
      </div>

      <div className="px-6 py-3 border-b bg-card flex flex-col sm:flex-row gap-3 items-center shrink-0">
        <form onSubmit={onSearchSubmit} className="relative flex-1 max-w-md w-full">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search by ticket #, title, or description..."
            className="pl-9 bg-background h-9"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            data-testid="portal-search-input"
          />
        </form>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Select
            value={scope}
            onValueChange={(v) => setScope(v as Scope)}
          >
            <SelectTrigger
              className="h-9 w-[160px] bg-background"
              data-testid="portal-scope-trigger"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mine">My Tickets</SelectItem>
              <SelectItem value="all">All My Org&rsquo;s Tickets</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={statusFilter === "all" ? "all" : statusFilter.toString()}
            onValueChange={(v) =>
              setStatusFilter(v === "all" ? "all" : (Number(v) as TicketStatus))
            }
          >
            <SelectTrigger
              className="h-9 w-[140px] bg-background"
              data-testid="portal-status-trigger"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {ticketStatusOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value.toString()}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6">
        {isLoading && !data ? (
          <LoadingState message="Loading your tickets..." />
        ) : filtered.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-16 px-4 text-center border rounded-lg bg-card border-dashed"
            data-testid="portal-empty-state"
          >
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground">
              {scope === "mine"
                ? "You haven't submitted any requests yet."
                : "No tickets match your filters."}
            </h3>
            <p className="text-sm text-muted-foreground mt-1 max-w-sm">
              {scope === "mine"
                ? "When you submit a support request, it will show up here so you can track its progress."
                : "Try clearing the search or status filter."}
            </p>
            {scope === "mine" && (
              <Link href="/support/portal/new">
                <Button className="mt-4 gap-2" data-testid="portal-empty-cta">
                  <Plus className="h-4 w-4" />
                  Submit your first request
                </Button>
              </Link>
            )}
          </div>
        ) : (
          <div className="bg-card border rounded-lg shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left" data-testid="portal-tickets-table">
                <thead className="text-xs text-muted-foreground uppercase bg-muted/50 border-b">
                  <tr>
                    <th className="px-4 py-3 font-medium">Ticket</th>
                    <th className="px-4 py-3 font-medium">Subject</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 font-medium">Priority</th>
                    <th className="px-4 py-3 font-medium text-right">Updated</th>
                  </tr>
                </thead>
                <tbody className="divide-y relative">
                  {isRefetching && (
                    <tr className="absolute inset-0 bg-background/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <td
                        colSpan={5}
                        className="w-full h-full flex items-center justify-center"
                      >
                        <div className="flex items-center gap-2 text-primary font-medium bg-background px-4 py-2 rounded-full shadow-sm border">
                          <RefreshCw className="h-4 w-4 animate-spin" /> Updating...
                        </div>
                      </td>
                    </tr>
                  )}
                  {filtered.map((t) => (
                    <tr
                      key={t.id}
                      className="hover:bg-muted/30 transition-colors group"
                      data-testid={`portal-ticket-row-${t.id}`}
                    >
                      <td className="px-4 py-3 align-top">
                        <Link
                          href={`/support/portal/tickets/${t.id}`}
                          className="font-mono text-xs font-semibold text-primary hover:underline whitespace-nowrap"
                        >
                          {t.ticketNumber}
                        </Link>
                      </td>
                      <td className="px-4 py-3 align-top min-w-[280px]">
                        <Link
                          href={`/support/portal/tickets/${t.id}`}
                          className="font-medium text-foreground hover:text-primary transition-colors line-clamp-1 block"
                        >
                          {t.title}
                        </Link>
                        {t.category && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                            <MessageSquare className="h-3 w-3" />
                            {t.category}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 align-top">
                        <Badge
                          variant="outline"
                          className={
                            t.status === TicketStatus.Open ||
                            t.status === TicketStatus.InProgress
                              ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800"
                              : t.status === TicketStatus.Resolved ||
                                  t.status === TicketStatus.Closed
                                ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800"
                                : "bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"
                          }
                        >
                          {ticketStatusLabel[t.status]}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 align-top">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`h-2 w-2 rounded-full ${
                              t.priority === TicketPriority.Urgent
                                ? "bg-red-500"
                                : t.priority === TicketPriority.High
                                  ? "bg-orange-500"
                                  : t.priority === TicketPriority.Normal
                                    ? "bg-blue-500"
                                    : "bg-gray-400"
                            }`}
                          />
                          <span className="text-xs text-muted-foreground font-medium">
                            {ticketPriorityLabel[t.priority]}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 align-top text-right text-muted-foreground">
                        <div className="flex items-center justify-end gap-1.5 text-xs whitespace-nowrap">
                          <Clock className="h-3 w-3" />
                          {formatRelative(t.updatedAt)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

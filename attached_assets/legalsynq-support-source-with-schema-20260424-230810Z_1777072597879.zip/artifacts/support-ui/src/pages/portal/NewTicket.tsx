import React from "react";
import { Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  ChevronLeft,
  Send,
  AlertCircle,
  LifeBuoy,
} from "lucide-react";
import { useCreateTicket } from "@/lib/api/hooks";
import {
  TicketPriority,
  TicketSource,
  type CreateTicketRequest,
  type TicketSeverity,
} from "@/lib/api/types";
import { ValidationError } from "@/lib/api/client";
import { ticketPriorityOptions } from "@/lib/api/labels";
import { useCurrentPersona } from "@/hooks/useCurrentPersona";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  title: z
    .string()
    .min(5, "Please give your request a short summary (at least 5 characters)")
    .max(200, "Summary is too long"),
  description: z.string().optional(),
  priority: z.coerce.number().int(),
});

type FormValues = z.infer<typeof formSchema>;

export default function PortalNewTicket() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const persona = useCurrentPersona();
  const createTicket = useCreateTicket();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      priority: TicketPriority.Normal,
    },
  });

  const onSubmit = (data: FormValues) => {
    const payload: CreateTicketRequest = {
      title: data.title,
      description: data.description || null,
      priority: data.priority as TicketPriority,
      severity: null as TicketSeverity | null,
      source: TicketSource.Portal,
      category: null,
      productCode: null,
      requesterName: persona.displayName,
      requesterEmail: persona.email,
    };

    createTicket.mutate(payload, {
      onSuccess: (ticket) => {
        toast({
          title: "Request submitted",
          description: `Ticket ${ticket.ticketNumber} has been opened — we'll be in touch shortly.`,
        });
        setLocation(`/support/portal/tickets/${ticket.id}`);
      },
      onError: (error) => {
        if (error instanceof ValidationError) {
          Object.entries(error.errors).forEach(([field, messages]) => {
            const fieldName = (field.charAt(0).toLowerCase() +
              field.slice(1)) as keyof FormValues;
            if (fieldName in form.getValues()) {
              form.setError(fieldName, { type: "server", message: messages[0] });
            }
          });
          toast({
            title: "Please review your request",
            description: "Some fields need attention.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "We couldn't submit your request",
            description: error.message || "An unexpected error occurred.",
            variant: "destructive",
          });
        }
      },
    });
  };

  const isError =
    createTicket.isError && !(createTicket.error instanceof ValidationError);

  return (
    <div className="flex flex-col h-full bg-muted/20">
      <div className="bg-card border-b px-6 py-4 flex items-center gap-4 shrink-0 sticky top-0 z-10">
        <Button
          variant="ghost"
          size="icon"
          asChild
          className="shrink-0 h-8 w-8"
        >
          <Link href="/support/portal">
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <LifeBuoy className="h-5 w-5 text-primary" />
            Submit a Request
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Tell us what&rsquo;s happening and our team will follow up.
          </p>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
        <div className="max-w-2xl mx-auto">
          {isError && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Submission failed</AlertTitle>
              <AlertDescription>
                {createTicket.error?.message ||
                  "There was a problem reaching the support service. Please try again."}
              </AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="space-y-6"
              data-testid="portal-new-ticket-form"
            >
              <Card className="shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">Submitting as</CardTitle>
                  <CardDescription>
                    We&rsquo;ll attach this contact info to the request.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div
                    className="flex items-center gap-3 p-3 rounded-md bg-muted/40 border"
                    data-testid="portal-submitter"
                  >
                    <div className="h-9 w-9 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold border border-primary/20">
                      {persona.initials}
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="text-sm font-medium text-foreground truncate">
                        {persona.displayName}
                      </span>
                      <span className="text-xs text-muted-foreground truncate">
                        {persona.email}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">What can we help with?</CardTitle>
                  <CardDescription>
                    The more detail you give, the faster we can help.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          Summary{" "}
                          <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g. Trust ledger export is missing transactions"
                            data-testid="portal-title-input"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Details</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="What were you trying to do? What did you expect to happen, and what happened instead?"
                            className="min-h-[140px] resize-y"
                            data-testid="portal-description-input"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Steps to reproduce, error messages, and context all help.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="priority"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How urgent is this?</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value?.toString()}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="portal-priority-trigger">
                              <SelectValue placeholder="Select urgency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {ticketPriorityOptions.map((opt) => (
                              <SelectItem
                                key={opt.value}
                                value={opt.value.toString()}
                              >
                                {opt.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <div className="flex justify-end gap-3 pb-8">
                <Button variant="outline" type="button" asChild>
                  <Link href="/support/portal">Cancel</Link>
                </Button>
                <Button
                  type="submit"
                  disabled={createTicket.isPending}
                  className="gap-2"
                  data-testid="portal-submit-button"
                >
                  {createTicket.isPending ? (
                    "Submitting..."
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Submit Request
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}

import React from "react";
import { useParams, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  ChevronLeft,
  Clock,
  User,
  Send,
  MessageSquare,
} from "lucide-react";
import {
  useTicket,
  useTicketComments,
  useAddComment,
} from "@/lib/api/hooks";
import {
  CommentType,
  CommentVisibility,
  TicketStatus,
  type CreateCommentRequest,
} from "@/lib/api/types";
import {
  ticketStatusLabel,
  ticketPriorityLabel,
} from "@/lib/api/labels";
import { formatRelative, formatDateTime } from "@/lib/format";

import { ErrorState } from "@/components/ui/error-state";
import { LoadingState, SkeletonList } from "@/components/ui/loading-state";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const replySchema = z.object({
  body: z.string().min(1, "Reply cannot be empty"),
});

type ReplyValues = z.infer<typeof replySchema>;

/**
 * Customer reply box. Visibility is locked to CustomerVisible and the type
 * to CustomerReply — the customer UI never exposes internal-note affordances.
 * The backend currently allows any authenticated user to write any visibility
 * (see services/support/Support.Api/Endpoints/CommentEndpoints.cs SupportWrite
 * policy), so this lock is enforced UI-side; tightening server-side filtering
 * for tenant roles is tracked separately.
 */
function CustomerReplyBox({ ticketId }: { ticketId: string }) {
  const { toast } = useToast();
  const addComment = useAddComment(ticketId);

  const form = useForm<ReplyValues>({
    resolver: zodResolver(replySchema),
    defaultValues: { body: "" },
  });

  const onSubmit = (data: ReplyValues) => {
    const payload: CreateCommentRequest = {
      body: data.body,
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
    };
    addComment.mutate(payload, {
      onSuccess: () => {
        form.reset();
        toast({
          title: "Reply sent",
          description: "Your reply has been added to the ticket.",
        });
      },
      onError: (err) => {
        toast({
          title: "Couldn't send reply",
          description: err.message,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <Card className="border shadow-sm overflow-hidden">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} data-testid="portal-reply-form">
          <FormField
            control={form.control}
            name="body"
            render={({ field }) => (
              <FormItem className="space-y-0 border-none">
                <FormControl>
                  <Textarea
                    placeholder="Reply to the support team..."
                    className="min-h-[110px] resize-y border-0 focus-visible:ring-0 rounded-none p-4"
                    data-testid="portal-reply-input"
                    {...field}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <div className="p-3 bg-muted/20 border-t flex justify-between items-center">
            <p className="px-2 text-xs text-destructive" role="alert">
              {form.formState.errors.body?.message ?? ""}
            </p>
            <Button
              type="submit"
              size="sm"
              disabled={addComment.isPending || !form.watch("body").trim()}
              className="gap-2 ml-auto"
              data-testid="portal-reply-submit"
            >
              {addComment.isPending ? "Sending..." : "Send Reply"}
              <Send className="h-3 w-3" />
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}

export default function PortalTicketDetail() {
  const params = useParams<{ id: string }>();
  const id = params.id;

  const {
    data: ticket,
    isLoading: ticketLoading,
    error: ticketError,
    refetch: refetchTicket,
  } = useTicket(id);
  const {
    data: comments,
    isLoading: commentsLoading,
    error: commentsError,
    refetch: refetchComments,
  } = useTicketComments(id);

  if (ticketError) {
    return <ErrorState error={ticketError} onRetry={() => refetchTicket()} />;
  }

  if (ticketLoading || !ticket) {
    return <LoadingState message="Loading your ticket..." />;
  }

  const isResolvedOrClosed =
    ticket.status === TicketStatus.Resolved ||
    ticket.status === TicketStatus.Closed;

  // Customer view: only show CustomerVisible comments. Internal notes never
  // surface in this UI even if the API returns them.
  const visibleComments = (comments ?? []).filter(
    (c) =>
      c.visibility === CommentVisibility.CustomerVisible &&
      c.commentType !== CommentType.SystemNote,
  );

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <div className="bg-card border-b px-4 py-3 flex items-center gap-4 shrink-0 shadow-sm z-10 sticky top-0">
        <Button
          variant="ghost"
          size="icon"
          asChild
          className="shrink-0 h-8 w-8"
        >
          <Link href="/support/portal">
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Back to my tickets</span>
          </Link>
        </Button>
        <div className="flex-1 min-w-0 flex items-center gap-3">
          <Badge
            variant="outline"
            className="font-mono bg-muted/50 text-foreground border-border shrink-0"
            data-testid="portal-ticket-number"
          >
            {ticket.ticketNumber}
          </Badge>
          <h1
            className="text-lg font-semibold truncate"
            title={ticket.title}
            data-testid="portal-ticket-title"
          >
            {ticket.title}
          </h1>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto p-4 md:p-6 lg:p-8 space-y-8">
          {/* Status row */}
          <div
            className="flex flex-wrap items-center gap-3"
            data-testid="portal-ticket-status-row"
          >
            <Badge
              variant="outline"
              className={
                ticket.status === TicketStatus.Open ||
                ticket.status === TicketStatus.InProgress
                  ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800"
                  : ticket.status === TicketStatus.Resolved ||
                      ticket.status === TicketStatus.Closed
                    ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800"
                    : "bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"
              }
            >
              {ticketStatusLabel[ticket.status]}
            </Badge>
            <span className="text-xs text-muted-foreground">
              Priority: {ticketPriorityLabel[ticket.priority]}
            </span>
            <span className="text-xs text-muted-foreground inline-flex items-center gap-1">
              <Clock className="h-3 w-3" />
              Updated {formatRelative(ticket.updatedAt)}
            </span>
          </div>

          {/* Original Request */}
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 border border-primary/20 font-bold shadow-sm">
                {ticket.requesterName?.charAt(0) || <User className="h-5 w-5" />}
              </div>
              <div className="flex-1 min-w-0 pt-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-foreground">
                    {ticket.requesterName || "You"}
                  </span>
                  {ticket.requesterEmail && (
                    <span className="text-xs text-muted-foreground">
                      &lt;{ticket.requesterEmail}&gt;
                    </span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground flex items-center gap-1.5 mb-4">
                  <Clock className="h-3 w-3" />
                  Opened {formatRelative(ticket.createdAt)} (
                  {formatDateTime(ticket.createdAt)})
                </div>
                <Card className="bg-card shadow-sm border-muted">
                  <CardContent
                    className="p-5 text-sm prose dark:prose-invert max-w-none text-foreground/90 whitespace-pre-wrap leading-relaxed"
                    data-testid="portal-ticket-description"
                  >
                    {ticket.description || (
                      <span className="italic text-muted-foreground">
                        No description provided.
                      </span>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          <Separator className="bg-border/60" />

          {/* Conversation */}
          <div className="space-y-6">
            <h3 className="text-sm font-semibold tracking-wide text-muted-foreground uppercase flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Conversation
            </h3>

            {commentsLoading ? (
              <SkeletonList count={2} />
            ) : commentsError ? (
              <ErrorState
                error={commentsError}
                onRetry={() => refetchComments()}
              />
            ) : visibleComments.length > 0 ? (
              <div className="space-y-6" data-testid="portal-comments-list">
                {visibleComments.map((comment) => {
                  const isOwn =
                    comment.authorEmail &&
                    ticket.requesterEmail &&
                    comment.authorEmail.toLowerCase() ===
                      ticket.requesterEmail.toLowerCase();
                  return (
                    <div
                      key={comment.id}
                      className={`flex gap-4 items-start ${isOwn ? "" : "pl-4 md:pl-12"}`}
                      data-testid={`portal-comment-${comment.id}`}
                    >
                      {!isOwn && (
                        <div className="h-8 w-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold shadow-sm bg-secondary text-secondary-foreground border">
                          {comment.authorName?.charAt(0) || "S"}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline justify-between gap-4 mb-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm text-foreground">
                              {comment.authorName || "Support team"}
                            </span>
                            {!isOwn && (
                              <Badge
                                variant="secondary"
                                className="text-[10px] h-4 px-1.5 bg-primary/10 text-primary border-transparent"
                              >
                                Support
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {formatRelative(comment.createdAt)}
                          </span>
                        </div>
                        <Card
                          className={`shadow-sm ${
                            isOwn ? "bg-card" : "bg-muted/30 border-muted"
                          }`}
                        >
                          <CardContent className="p-4 text-sm whitespace-pre-wrap leading-relaxed text-foreground/90">
                            {comment.body}
                          </CardContent>
                        </Card>
                      </div>
                      {isOwn && (
                        <div className="h-8 w-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 text-xs font-bold border border-primary/20 shadow-sm">
                          {comment.authorName?.charAt(0) || "C"}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-sm text-muted-foreground border border-dashed rounded-lg bg-background">
                No replies yet. The support team will respond here.
              </div>
            )}

            {!isResolvedOrClosed ? (
              <div className="pt-4">
                <CustomerReplyBox ticketId={ticket.id} />
              </div>
            ) : (
              <div
                className="text-center py-6 px-4 text-sm text-muted-foreground border border-dashed rounded-lg bg-muted/20"
                data-testid="portal-closed-notice"
              >
                This ticket is {ticketStatusLabel[ticket.status].toLowerCase()}.
                If you need further help, please submit a new request.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

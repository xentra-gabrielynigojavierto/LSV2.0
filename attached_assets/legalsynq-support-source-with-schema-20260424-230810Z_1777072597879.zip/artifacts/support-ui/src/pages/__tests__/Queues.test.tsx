import { describe, expect, it } from "vitest";
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import QueuesPage from "../Queues";
import { renderWithProviders } from "@/test/test-utils";

describe("<QueuesPage />", () => {
  it("renders the seeded queue list", async () => {
    renderWithProviders(<QueuesPage />);

    await waitFor(() => {
      expect(screen.getByTestId("queue-item-queue-tier2")).toBeInTheDocument();
    });
    expect(
      screen.getByTestId("queue-item-queue-billing"),
    ).toBeInTheDocument();
  });

  it("creating a queue adds it to the list", async () => {
    const user = userEvent.setup();
    renderWithProviders(<QueuesPage />);
    await screen.findByTestId("queue-item-queue-tier2");

    await user.click(screen.getByTestId("queue-create-trigger"));
    const dialog = await screen.findByTestId("create-queue-dialog");

    const uniqueName = "QA Smoke " + Date.now();
    await user.type(
      within(dialog).getByTestId("queue-form-name"),
      uniqueName,
    );
    await user.click(within(dialog).getByTestId("queue-form-submit"));

    await waitFor(() => {
      expect(screen.getByText(uniqueName)).toBeInTheDocument();
    });
  });

  it("adds and removes a queue member", async () => {
    const user = userEvent.setup();
    renderWithProviders(<QueuesPage />);
    await screen.findByTestId("queue-item-queue-tier2");

    // pick the rules queue (smaller member list)
    await user.click(screen.getByTestId("queue-item-queue-rules"));

    const userId = "agent-test-" + Date.now();
    await user.type(screen.getByTestId("member-form-userid"), userId);
    await user.click(screen.getByTestId("member-form-submit"));

    await waitFor(() => {
      expect(screen.getByText(userId)).toBeInTheDocument();
    });

    // find that newly-added row in member-list and remove it
    const list = screen.getByTestId("member-list");
    const row = within(list)
      .getByText(userId)
      .closest("li");
    expect(row).toBeTruthy();
    const removeBtn = within(row as HTMLElement).getByRole("button", {
      name: new RegExp(`remove ${userId}`, "i"),
    });
    await user.click(removeBtn);

    await waitFor(() => {
      expect(screen.queryByText(userId)).not.toBeInTheDocument();
    });
  });
});

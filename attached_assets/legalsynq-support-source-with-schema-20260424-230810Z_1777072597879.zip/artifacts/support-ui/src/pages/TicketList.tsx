import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  formatRelative, 
} from "@/lib/format";
import { 
  ticketStatusLabel, 
  ticketPriorityLabel, 
  ticketSeverityLabel,
  ticketStatusOptions,
  ticketPriorityOptions,
} from "@/lib/api/labels";
import { TicketStatus, TicketPriority } from "@/lib/api/types";
import { useTicketList, useQueues } from "@/lib/api/hooks";
import { ErrorState } from "@/components/ui/error-state";
import { LoadingState } from "@/components/ui/loading-state";
import { 
  Plus, 
  Search, 
  Filter, 
  ChevronLeft, 
  ChevronRight,
  MessageSquare,
  Clock,
  User,
  MoreHorizontal,
  Inbox,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function TicketList() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [statusFilter, setStatusFilter] = useState<TicketStatus | "all">("all");
  const [priorityFilter, setPriorityFilter] = useState<TicketPriority | "all">("all");
  const [assignmentFilter, setAssignmentFilter] = useState<string>("all");
  const pageSize = 25;

  const queuesQ = useQueues({ isActive: true });
  const queues = queuesQ.data ?? [];
  const queueNameById = new Map(queues.map((q) => [q.id, q.name] as const));

  const assignmentParam: {
    unassigned?: boolean;
    assignedQueueId?: string;
  } = (() => {
    if (assignmentFilter === "all") return {};
    if (assignmentFilter === "unassigned") return { unassigned: true };
    if (assignmentFilter.startsWith("queue:"))
      return { assignedQueueId: assignmentFilter.slice("queue:".length) };
    return {};
  })();

  const filters = {
    page,
    pageSize,
    ...(search ? { search } : {}),
    ...(statusFilter !== "all" ? { status: statusFilter } : {}),
    ...(priorityFilter !== "all" ? { priority: priorityFilter } : {}),
    ...assignmentParam,
  };

  const { data, isLoading, error, refetch, isRefetching } = useTicketList(filters, {
    placeholderData: (prev) => prev,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(searchInput);
    setPage(1);
  };

  if (error) {
    return <ErrorState error={error} onRetry={() => refetch()} />;
  }

  return (
    <div className="flex flex-col h-full bg-muted/30">
      {/* Header */}
      <div className="bg-card border-b px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Support Inbox</h1>
          <p className="text-sm text-muted-foreground mt-1">Triage and manage tenant support tickets.</p>
        </div>
        <Link href="/support/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            New Ticket
          </Button>
        </Link>
      </div>

      {/* Filters Toolbar */}
      <div className="px-6 py-3 border-b bg-card flex flex-col sm:flex-row gap-3 items-center shrink-0">
        <form onSubmit={handleSearch} className="relative flex-1 max-w-md w-full">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            type="search" 
            placeholder="Search tickets by number, title, or requester..." 
            className="pl-9 bg-background h-9"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
        </form>
        
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground hidden sm:block" />
            <Select 
              value={statusFilter === "all" ? "all" : statusFilter.toString()} 
              onValueChange={(val) => {
                setStatusFilter(val === "all" ? "all" : Number(val) as TicketStatus);
                setPage(1);
              }}
            >
              <SelectTrigger className="h-9 w-[140px] bg-background">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {ticketStatusOptions.map(opt => (
                  <SelectItem key={opt.value} value={opt.value.toString()}>{opt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Select 
            value={priorityFilter === "all" ? "all" : priorityFilter.toString()} 
            onValueChange={(val) => {
              setPriorityFilter(val === "all" ? "all" : Number(val) as TicketPriority);
              setPage(1);
            }}
          >
            <SelectTrigger className="h-9 w-[140px] bg-background">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              {ticketPriorityOptions.map(opt => (
                <SelectItem key={opt.value} value={opt.value.toString()}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={assignmentFilter}
            onValueChange={(val) => {
              setAssignmentFilter(val);
              setPage(1);
            }}
          >
            <SelectTrigger
              className="h-9 w-[180px] bg-background"
              data-testid="filter-assignment-trigger"
            >
              <SelectValue placeholder="Assignment" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Assignments</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {queues.length > 0 && (
                <div className="px-2 pt-2 pb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                  Queues
                </div>
              )}
              {queues.map((q) => (
                <SelectItem key={q.id} value={`queue:${q.id}`}>
                  {q.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-6">
        {isLoading && !data ? (
          <LoadingState message="Loading tickets..." />
        ) : !data || data.items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 px-4 text-center border rounded-lg bg-card border-dashed">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground">No tickets found</h3>
            <p className="text-sm text-muted-foreground mt-1 max-w-sm">
              {search || statusFilter !== "all" || priorityFilter !== "all" || assignmentFilter !== "all"
                ? "Try adjusting your filters or search query to find what you're looking for." 
                : "Your inbox is clear. New tickets will appear here."}
            </p>
            {(search || statusFilter !== "all" || priorityFilter !== "all" || assignmentFilter !== "all") && (
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => {
                  setSearch("");
                  setSearchInput("");
                  setStatusFilter("all");
                  setPriorityFilter("all");
                  setAssignmentFilter("all");
                }}
              >
                Clear all filters
              </Button>
            )}
          </div>
        ) : (
          <div className="bg-card border rounded-lg shadow-sm overflow-hidden flex flex-col">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground uppercase bg-muted/50 border-b">
                  <tr>
                    <th className="px-4 py-3 font-medium">Ticket</th>
                    <th className="px-4 py-3 font-medium">Title & Context</th>
                    <th className="px-4 py-3 font-medium">Requester</th>
                    <th className="px-4 py-3 font-medium">Status / Priority</th>
                    <th className="px-4 py-3 font-medium">Assigned</th>
                    <th className="px-4 py-3 font-medium text-right">Updated</th>
                  </tr>
                </thead>
                <tbody className="divide-y relative">
                  {isRefetching && (
                    <tr className="absolute inset-0 bg-background/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <td colSpan={6} className="w-full h-full flex items-center justify-center">
                        <div className="flex items-center gap-2 text-primary font-medium bg-background px-4 py-2 rounded-full shadow-sm border">
                          <RefreshCw className="h-4 w-4 animate-spin" /> Updating...
                        </div>
                      </td>
                    </tr>
                  )}
                  {data.items.map((ticket) => (
                    <tr key={ticket.id} className="hover:bg-muted/30 transition-colors group">
                      <td className="px-4 py-3 align-top">
                        <Link href={`/support/tickets/${ticket.id}`} className="font-mono text-xs font-semibold text-primary hover:underline whitespace-nowrap block mb-1">
                          {ticket.ticketNumber}
                        </Link>
                        {ticket.productCode && (
                          <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                            {ticket.productCode}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 align-top min-w-[300px]">
                        <Link href={`/support/tickets/${ticket.id}`} className="font-medium text-foreground hover:text-primary transition-colors line-clamp-1 block mb-1">
                          {ticket.title}
                        </Link>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1.5">
                          {ticket.category && (
                            <span className="flex items-center gap-1">
                              <div className="w-1.5 h-1.5 rounded-full bg-primary/40" />
                              {ticket.category}
                            </span>
                          )}
                          <span className="flex items-center gap-1">
                            <MessageSquare className="h-3 w-3" />
                            {/* In a real app we might have comment count here, mocked for now */}
                            Reply
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 align-top">
                        <div className="flex items-center gap-2">
                          <div className="h-6 w-6 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center text-[10px] font-bold shrink-0">
                            {ticket.requesterName?.charAt(0) || <User className="h-3 w-3" />}
                          </div>
                          <div className="flex flex-col min-w-0">
                            <span className="text-sm font-medium truncate max-w-[120px]">{ticket.requesterName || "Unknown"}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 align-top">
                        <div className="flex flex-col gap-1.5 items-start">
                          <Badge variant="outline" className={
                            ticket.status === TicketStatus.Open || ticket.status === TicketStatus.InProgress 
                              ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800" 
                              : ticket.status === TicketStatus.Resolved || ticket.status === TicketStatus.Closed
                              ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800"
                              : "bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"
                          }>
                            {ticketStatusLabel[ticket.status]}
                          </Badge>
                          <div className="flex items-center gap-1">
                            <span className={`h-2 w-2 rounded-full ${
                              ticket.priority === TicketPriority.Urgent ? "bg-red-500" :
                              ticket.priority === TicketPriority.High ? "bg-orange-500" :
                              ticket.priority === TicketPriority.Normal ? "bg-blue-500" :
                              "bg-gray-400"
                            }`} />
                            <span className="text-xs text-muted-foreground font-medium">
                              {ticketPriorityLabel[ticket.priority]}
                            </span>
                            {ticket.severity != null && (
                              <span className="text-[10px] ml-1 px-1 py-0.5 rounded bg-muted text-muted-foreground border">
                                {ticketSeverityLabel[ticket.severity]}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 align-top">
                        {ticket.assignedUserId || ticket.assignedQueueId ? (
                          <div className="flex flex-col gap-0.5 text-xs">
                            {ticket.assignedUserId && (
                              <span
                                className="font-medium text-foreground truncate max-w-[140px]"
                                data-testid={`row-assigned-user-${ticket.id}`}
                              >
                                {ticket.assignedUserId}
                              </span>
                            )}
                            {ticket.assignedQueueId && (
                              <span
                                className="text-muted-foreground truncate max-w-[140px]"
                                data-testid={`row-assigned-queue-${ticket.id}`}
                              >
                                {queueNameById.get(ticket.assignedQueueId) ??
                                  ticket.assignedQueueId}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span
                            className="text-xs italic text-muted-foreground"
                            data-testid={`row-unassigned-${ticket.id}`}
                          >
                            Unassigned
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 align-top text-right text-muted-foreground">
                        <div className="flex items-center justify-end gap-1.5 text-xs whitespace-nowrap">
                          <Clock className="h-3 w-3" />
                          {formatRelative(ticket.updatedAt)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* Pagination */}
            <div className="border-t px-4 py-3 bg-muted/20 flex items-center justify-between">
              <div className="text-xs text-muted-foreground">
                Showing <span className="font-medium text-foreground">{(page - 1) * pageSize + 1}</span> to <span className="font-medium text-foreground">{Math.min(page * pageSize, data.total)}</span> of <span className="font-medium text-foreground">{data.total}</span> tickets
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  disabled={page === 1} 
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  className="h-8 w-8 p-0"
                >
                  <ChevronLeft className="h-4 w-4" />
                  <span className="sr-only">Previous Page</span>
                </Button>
                <div className="text-xs font-medium px-2">
                  Page {page} of {Math.ceil(data.total / pageSize) || 1}
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  disabled={page >= Math.ceil(data.total / pageSize)} 
                  onClick={() => setPage(p => p + 1)}
                  className="h-8 w-8 p-0"
                >
                  <ChevronRight className="h-4 w-4" />
                  <span className="sr-only">Next Page</span>
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

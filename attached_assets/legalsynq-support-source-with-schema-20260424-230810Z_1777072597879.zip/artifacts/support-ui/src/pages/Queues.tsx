import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import {
  useQueues,
  useQueueMembers,
  useCreateQueue,
  useUpdateQueue,
  useAddQueueMember,
  useRemoveQueueMember,
} from "@/lib/api/hooks";
import {
  QueueMemberRole,
  queueMemberRoleLabel,
  queueMemberRoleOptions,
  type SupportQueue,
} from "@/lib/api/queues";
import { ApiError, ValidationError } from "@/lib/api/client";
import { formatRelative } from "@/lib/format";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ErrorState } from "@/components/ui/error-state";
import { LoadingState, SkeletonList } from "@/components/ui/loading-state";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import {
  Plus,
  Users,
  Trash2,
  PowerOff,
  Power,
} from "lucide-react";

const queueFormSchema = z.object({
  name: z
    .string()
    .min(1, "Name is required")
    .max(120, "Name must be 120 characters or less"),
  description: z.string().max(1000).optional(),
  productCode: z
    .string()
    .max(64)
    .regex(/^[A-Z0-9-]*$/i, "Letters, numbers, and dashes only")
    .optional(),
  isActive: z.boolean(),
});

type QueueFormValues = z.infer<typeof queueFormSchema>;

const memberFormSchema = z.object({
  userId: z
    .string()
    .min(1, "User id is required")
    .max(64, "Max 64 characters"),
  role: z.coerce.number().int().min(0).max(2),
});

type MemberFormValues = z.infer<typeof memberFormSchema>;

export default function QueuesPage() {
  const { toast } = useToast();
  const queuesQ = useQueues({});
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  const queues = queuesQ.data ?? [];
  React.useEffect(() => {
    if (!selectedId && queues.length > 0) setSelectedId(queues[0].id);
  }, [selectedId, queues]);

  const selected = queues.find((q) => q.id === selectedId) ?? null;

  if (queuesQ.error) {
    return (
      <ErrorState
        error={queuesQ.error as Error}
        onRetry={() => queuesQ.refetch()}
      />
    );
  }

  return (
    <div className="flex flex-col h-full bg-muted/30">
      {/* Header */}
      <div className="bg-card border-b px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Queues
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Operational routing queues and the agents who staff them.
          </p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" data-testid="queue-create-trigger">
              <Plus className="h-4 w-4" />
              New Queue
            </Button>
          </DialogTrigger>
          <CreateQueueDialog onClose={() => setCreateOpen(false)} />
        </Dialog>
      </div>

      <div className="flex-1 grid grid-cols-1 md:grid-cols-[280px_1fr] overflow-hidden">
        {/* Left: queues list */}
        <div className="border-r bg-card overflow-y-auto">
          {queuesQ.isLoading ? (
            <div className="p-4">
              <SkeletonList count={4} />
            </div>
          ) : queues.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              No queues yet. Create one to get started.
            </div>
          ) : (
            <ul className="divide-y" data-testid="queue-list">
              {queues.map((q) => (
                <li key={q.id}>
                  <button
                    type="button"
                    onClick={() => setSelectedId(q.id)}
                    className={`w-full text-left p-3 hover:bg-muted/40 transition-colors ${
                      q.id === selectedId ? "bg-muted/60" : ""
                    }`}
                    data-testid={`queue-item-${q.id}`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium text-sm text-foreground truncate">
                        {q.name}
                      </span>
                      {!q.isActive && (
                        <Badge variant="outline" className="text-[10px]">
                          inactive
                        </Badge>
                      )}
                    </div>
                    {q.productCode && (
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mt-1 font-semibold">
                        {q.productCode}
                      </div>
                    )}
                    {q.description && (
                      <div className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {q.description}
                      </div>
                    )}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Right: detail */}
        <div className="overflow-y-auto p-6">
          {selected ? (
            <QueueDetail queue={selected} />
          ) : queuesQ.isLoading ? (
            <LoadingState message="Loading queues…" />
          ) : (
            <div className="text-sm text-muted-foreground">
              Select a queue to manage its members.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CreateQueueDialog({ onClose }: { onClose: () => void }) {
  const { toast } = useToast();
  const create = useCreateQueue();
  const form = useForm<QueueFormValues>({
    resolver: zodResolver(queueFormSchema),
    defaultValues: {
      name: "",
      description: "",
      productCode: "",
      isActive: true,
    },
  });

  const onSubmit = (values: QueueFormValues) => {
    create.mutate(
      {
        name: values.name,
        description: values.description?.trim() || null,
        productCode: values.productCode?.trim() || null,
        isActive: values.isActive,
      },
      {
        onSuccess: () => {
          toast({
            title: "Queue created",
            description: `'${values.name}' is ready to receive tickets.`,
          });
          form.reset();
          onClose();
        },
        onError: (err) => {
          if (err instanceof ValidationError) {
            for (const [field, msgs] of Object.entries(err.errors)) {
              form.setError(field.toLowerCase() as keyof QueueFormValues, {
                message: msgs.join(" "),
              });
            }
          }
          toast({
            title: "Failed to create queue",
            description:
              err instanceof ApiError && err.status === 409
                ? "A queue with that name already exists."
                : err.message,
            variant: "destructive",
          });
        },
      },
    );
  };

  return (
    <DialogContent data-testid="create-queue-dialog">
      <DialogHeader>
        <DialogTitle>New Queue</DialogTitle>
        <DialogDescription>
          Create a routing queue. Members can be added once the queue exists.
        </DialogDescription>
      </DialogHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Name</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    placeholder="Tier 2 Support"
                    data-testid="queue-form-name"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="productCode"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Product Code</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    placeholder="MATTER-MGMT"
                    data-testid="queue-form-product"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    rows={3}
                    placeholder="What kinds of tickets land here?"
                    data-testid="queue-form-description"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-md border p-3">
                <div>
                  <FormLabel className="text-sm">Active</FormLabel>
                  <p className="text-xs text-muted-foreground">
                    Inactive queues can't be selected when assigning tickets.
                  </p>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={create.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={create.isPending}
              data-testid="queue-form-submit"
            >
              {create.isPending ? "Creating…" : "Create queue"}
            </Button>
          </DialogFooter>
        </form>
      </Form>
    </DialogContent>
  );
}

function QueueDetail({ queue }: { queue: SupportQueue }) {
  const { toast } = useToast();
  const updateQueue = useUpdateQueue(queue.id);
  const membersQ = useQueueMembers(queue.id);
  const addMember = useAddQueueMember(queue.id);
  const removeMember = useRemoveQueueMember(queue.id);

  const memberForm = useForm<MemberFormValues>({
    resolver: zodResolver(memberFormSchema),
    defaultValues: { userId: "", role: QueueMemberRole.Agent },
  });

  const handleToggleActive = () => {
    updateQueue.mutate(
      { isActive: !queue.isActive },
      {
        onSuccess: () => {
          toast({
            title: queue.isActive ? "Queue deactivated" : "Queue activated",
            description: queue.isActive
              ? "It will no longer be selectable for new assignments."
              : "It can now receive new ticket assignments.",
          });
        },
        onError: (err) => {
          toast({
            title: "Failed to update queue",
            description: err.message,
            variant: "destructive",
          });
        },
      },
    );
  };

  const onAddMember = (values: MemberFormValues) => {
    addMember.mutate(
      { userId: values.userId.trim(), role: values.role as QueueMemberRole },
      {
        onSuccess: () => {
          memberForm.reset({ userId: "", role: QueueMemberRole.Agent });
          toast({
            title: "Member added",
            description: `${values.userId} added to ${queue.name}.`,
          });
        },
        onError: (err) => {
          toast({
            title: "Failed to add member",
            description:
              err instanceof ApiError && err.status === 409
                ? "That user is already a member of this queue."
                : err.message,
            variant: "destructive",
          });
        },
      },
    );
  };

  const handleRemove = (memberId: string, userId: string) => {
    removeMember.mutate(memberId, {
      onSuccess: () => {
        toast({
          title: "Member removed",
          description: `${userId} removed from ${queue.name}.`,
        });
      },
      onError: (err) => {
        toast({
          title: "Failed to remove member",
          description: err.message,
          variant: "destructive",
        });
      },
    });
  };

  const activeMembers = (membersQ.data ?? []).filter((m) => m.isActive);

  return (
    <div className="space-y-6" data-testid="queue-detail">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-xl font-semibold text-foreground">
              {queue.name}
            </h2>
            {queue.isActive ? (
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900/40 dark:text-green-300">
                Active
              </Badge>
            ) : (
              <Badge variant="outline">Inactive</Badge>
            )}
            {queue.productCode && (
              <Badge variant="outline" className="font-mono">
                {queue.productCode}
              </Badge>
            )}
          </div>
          {queue.description && (
            <p className="text-sm text-muted-foreground mt-2 max-w-2xl">
              {queue.description}
            </p>
          )}
          <div className="text-xs text-muted-foreground mt-2">
            Updated {formatRelative(queue.updatedAt)}
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleToggleActive}
          disabled={updateQueue.isPending}
          className="gap-2"
          data-testid="queue-toggle-active"
        >
          {queue.isActive ? (
            <>
              <PowerOff className="h-3.5 w-3.5" />
              Deactivate
            </>
          ) : (
            <>
              <Power className="h-3.5 w-3.5" />
              Activate
            </>
          )}
        </Button>
      </div>

      <div className="bg-card border rounded-lg p-5">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-4">
          <Users className="h-4 w-4 text-muted-foreground" />
          Members
        </h3>

        <Form {...memberForm}>
          <form
            onSubmit={memberForm.handleSubmit(onAddMember)}
            className="flex flex-col sm:flex-row gap-2 mb-5"
          >
            <FormField
              control={memberForm.control}
              name="userId"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="user id (e.g. agent-okafor)"
                      data-testid="member-form-userid"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={memberForm.control}
              name="role"
              render={({ field }) => (
                <FormItem className="w-full sm:w-[160px]">
                  <Select
                    value={String(field.value)}
                    onValueChange={(v) => field.onChange(Number(v))}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="member-form-role">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {queueMemberRoleOptions.map((opt) => (
                        <SelectItem
                          key={opt.value}
                          value={String(opt.value)}
                        >
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button
              type="submit"
              disabled={addMember.isPending}
              data-testid="member-form-submit"
            >
              {addMember.isPending ? "Adding…" : "Add"}
            </Button>
          </form>
        </Form>

        {membersQ.isLoading ? (
          <SkeletonList count={2} />
        ) : activeMembers.length === 0 ? (
          <div className="text-sm text-muted-foreground italic py-4">
            No members yet. Add agents above to staff this queue.
          </div>
        ) : (
          <ul className="divide-y" data-testid="member-list">
            {activeMembers.map((m) => (
              <li
                key={m.id}
                className="py-3 flex items-center justify-between gap-3"
                data-testid={`member-row-${m.id}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-8 w-8 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center text-xs font-bold shrink-0">
                    {m.userId.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="font-medium text-sm text-foreground truncate">
                      {m.userId}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {queueMemberRoleLabel[m.role]} · added{" "}
                      {formatRelative(m.createdAt)}
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRemove(m.id, m.userId)}
                  disabled={removeMember.isPending}
                  data-testid={`member-remove-${m.id}`}
                  aria-label={`Remove ${m.userId}`}
                >
                  <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

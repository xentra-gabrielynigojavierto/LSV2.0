import React from "react";
import { Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { 
  ChevronLeft, 
  Save, 
  AlertCircle,
  Ticket as TicketIcon
} from "lucide-react";
import { useCreateTicket } from "@/lib/api/hooks";
import { 
  TicketPriority, 
  TicketSeverity, 
  TicketSource,
  CreateTicketRequest 
} from "@/lib/api/types";
import { ValidationError } from "@/lib/api/client";
import { 
  ticketPriorityOptions, 
  ticketSeverityOptions, 
  ticketSourceOptions 
} from "@/lib/api/labels";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters").max(200, "Title is too long"),
  description: z.string().optional(),
  priority: z.coerce.number().int(),
  severity: z.coerce.number().int().optional().nullable(),
  source: z.coerce.number().int(),
  category: z.string().max(50).optional().nullable(),
  productCode: z.string().max(50).optional().nullable(),
  requesterName: z.string().min(2, "Name is required").max(100),
  requesterEmail: z.string().email("Invalid email address"),
});

type FormValues = z.infer<typeof formSchema>;

export default function TicketCreate() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createTicket = useCreateTicket();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      priority: TicketPriority.Normal,
      severity: undefined,
      source: TicketSource.Portal,
      category: "",
      productCode: "",
      requesterName: "",
      requesterEmail: "",
    },
  });

  const onSubmit = (data: FormValues) => {
    const payload: CreateTicketRequest = {
      title: data.title,
      description: data.description || null,
      priority: data.priority as TicketPriority,
      severity: data.severity != null ? data.severity as TicketSeverity : null,
      source: data.source as TicketSource,
      category: data.category || null,
      productCode: data.productCode || null,
      requesterName: data.requesterName,
      requesterEmail: data.requesterEmail,
    };

    createTicket.mutate(payload, {
      onSuccess: (ticket) => {
        toast({
          title: "Ticket created successfully",
          description: `Ticket ${ticket.ticketNumber} has been created.`,
        });
        setLocation(`/support/tickets/${ticket.id}`);
      },
      onError: (error) => {
        if (error instanceof ValidationError) {
          // Map server validation errors to form fields
          Object.entries(error.errors).forEach(([field, messages]) => {
            // Convert PascalCase from API to camelCase for form fields
            const fieldName = field.charAt(0).toLowerCase() + field.slice(1) as keyof FormValues;
            if (fieldName in form.getValues()) {
              form.setError(fieldName, { type: "server", message: messages[0] });
            }
          });
          
          toast({
            title: "Validation Error",
            description: "Please check the form for errors.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Failed to create ticket",
            description: error.message || "An unexpected error occurred.",
            variant: "destructive",
          });
        }
      }
    });
  };

  const isError = createTicket.isError && !(createTicket.error instanceof ValidationError);

  return (
    <div className="flex flex-col h-full bg-muted/20">
      {/* Header */}
      <div className="bg-card border-b px-6 py-4 flex items-center gap-4 shrink-0 sticky top-0 z-10">
        <Button variant="ghost" size="icon" asChild className="shrink-0 h-8 w-8">
          <Link href="/support">
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <TicketIcon className="h-5 w-5 text-primary" />
            New Support Ticket
          </h1>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
        <div className="max-w-3xl mx-auto">
          {isError && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error creating ticket</AlertTitle>
              <AlertDescription>
                {createTicket.error?.message || "There was a problem communicating with the server. Please try again."}
              </AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <Card className="shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">Requester Information</CardTitle>
                  <CardDescription>Who is reporting this issue?</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="requesterName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name <span className="text-destructive">*</span></FormLabel>
                          <FormControl>
                            <Input placeholder="Jane Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="requesterEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address <span className="text-destructive">*</span></FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="jane@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">Ticket Details</CardTitle>
                  <CardDescription>Provide a clear, concise description of the issue.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Summary / Subject <span className="text-destructive">*</span></FormLabel>
                        <FormControl>
                          <Input placeholder="Cannot access billing exports..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Detailed Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Please provide steps to reproduce, error messages, and context..." 
                            className="min-h-[120px] resize-y"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                    <FormField
                      control={form.control}
                      name="priority"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Priority</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select priority" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {ticketPriorityOptions.map((opt) => (
                                <SelectItem key={opt.value} value={opt.value.toString()}>{opt.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="severity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Severity (Optional)</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select severity" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="undefined" className="text-muted-foreground italic">None</SelectItem>
                              {ticketSeverityOptions.map((opt) => (
                                <SelectItem key={opt.value} value={opt.value.toString()}>{opt.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="source"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Source</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select source" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {ticketSourceOptions.map((opt) => (
                                <SelectItem key={opt.value} value={opt.value.toString()}>{opt.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="productCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Code</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. matter-mgmt" {...field} value={field.value || ''} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. documents" {...field} value={field.value || ''} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-end gap-3 pb-8">
                <Button variant="outline" type="button" asChild>
                  <Link href="/support">Cancel</Link>
                </Button>
                <Button type="submit" disabled={createTicket.isPending} className="gap-2 w-32">
                  {createTicket.isPending ? (
                    <span className="flex items-center gap-2">Saving...</span>
                  ) : (
                    <>
                      <Save className="h-4 w-4" />
                      Create Ticket
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}

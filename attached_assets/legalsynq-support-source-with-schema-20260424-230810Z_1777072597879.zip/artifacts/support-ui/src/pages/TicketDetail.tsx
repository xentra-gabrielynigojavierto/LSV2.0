import React, { useState } from "react";
import { useParams, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { 
  useTicket, 
  useUpdateTicket, 
  useTicketComments, 
  useTicketTimeline, 
  useTicketAttachments, 
  useTicketProductRefs,
  useAddComment,
  useUploadAttachment
} from "@/lib/api/hooks";
import { 
  CommentType, 
  CommentVisibility,
  TicketStatus,
  TicketPriority,
  TicketSeverity,
  CreateCommentRequest
} from "@/lib/api/types";
import { 
  ticketStatusLabel, 
  ticketPriorityLabel, 
  ticketSeverityLabel,
  commentTypeLabel,
  commentVisibilityLabel,
  ticketStatusOptions,
  ticketPriorityOptions,
  ticketSeverityOptions
} from "@/lib/api/labels";
import { formatRelative, formatDateTime, formatBytes } from "@/lib/format";
import { NotFoundError } from "@/lib/api/client";

import { ErrorState } from "@/components/ui/error-state";
import { LoadingState, SkeletonList } from "@/components/ui/loading-state";
import { AssignmentPanel } from "@/components/AssignmentPanel";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import {
  ChevronLeft,
  Paperclip,
  FileText,
  Clock,
  User,
  Send,
  MessageSquare,
  Activity,
  Box,
  Save,
  Tag,
  Upload,
  Loader2
} from "lucide-react";

import { ValidationError, ApiError } from "@/lib/api/client";

// --- Attachment uploader (SUP-INT-08) ---

interface AttachmentUploaderProps {
  ticketId: string;
}

function AttachmentUploader({ ticketId }: AttachmentUploaderProps) {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const { toast } = useToast();
  const upload = useUploadAttachment(ticketId);

  function handlePick() {
    setErrorMessage(null);
    fileInputRef.current?.click();
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    // Always reset the input so the same file can be picked twice in a row.
    e.target.value = "";
    if (!file) return;
    setErrorMessage(null);

    upload.mutate(
      { file },
      {
        onSuccess: (att) => {
          toast({
            title: "Uploaded",
            description: `${att.fileName} attached to this ticket.`,
          });
        },
        onError: (err) => {
          if (err instanceof ValidationError) {
            const firstField = Object.keys(err.errors)[0];
            const firstMsg = firstField ? err.errors[firstField]?.[0] : null;
            setErrorMessage(firstMsg ?? err.message);
          } else if (err instanceof ApiError) {
            setErrorMessage(err.message);
          } else {
            setErrorMessage(err.message ?? "Upload failed.");
          }
        },
      },
    );
  }

  return (
    <div className="mb-3">
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={handleChange}
        data-testid="attachment-file-input"
        aria-hidden="true"
        tabIndex={-1}
      />
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="w-full"
        onClick={handlePick}
        disabled={upload.isPending}
        data-testid="button-upload-attachment"
      >
        {upload.isPending ? (
          <>
            <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />
            Uploading…
          </>
        ) : (
          <>
            <Upload className="mr-2 h-3.5 w-3.5" />
            Upload file
          </>
        )}
      </Button>
      {errorMessage ? (
        <div
          className="mt-2 text-xs text-destructive"
          role="alert"
          data-testid="text-upload-error"
        >
          {errorMessage}
        </div>
      ) : null}
    </div>
  );
}

// --- Comment Form ---

const commentSchema = z.object({
  body: z.string().min(1, "Comment cannot be empty"),
  commentType: z.coerce.number().int(),
  visibility: z.coerce.number().int(),
});

type CommentFormValues = z.infer<typeof commentSchema>;

function CommentComposer({ ticketId }: { ticketId: string }) {
  const { toast } = useToast();
  const addComment = useAddComment(ticketId);

  const form = useForm<CommentFormValues>({
    resolver: zodResolver(commentSchema),
    defaultValues: {
      body: "",
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
    },
  });

  const onSubmit = (data: CommentFormValues) => {
    addComment.mutate(data as CreateCommentRequest, {
      onSuccess: () => {
        form.reset();
        toast({
          title: "Comment added",
          description: "Your comment has been posted.",
        });
      },
      onError: (err) => {
        toast({
          title: "Failed to add comment",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  const isInternal = form.watch("visibility") == CommentVisibility.Internal;

  return (
    <Card className={`border shadow-sm overflow-hidden transition-colors ${isInternal ? 'border-amber-200/50 bg-amber-50/10 dark:border-amber-900/30 dark:bg-amber-950/10' : ''}`}>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="p-3 bg-muted/40 border-b flex flex-wrap gap-3 items-center justify-between">
            <div className="flex gap-2">
              <FormField
                control={form.control}
                name="commentType"
                render={({ field }) => (
                  <FormItem className="space-y-0">
                    <Select onValueChange={field.onChange} defaultValue={field.value.toString()}>
                      <FormControl>
                        <SelectTrigger className="h-8 text-xs bg-background w-[140px]">
                          <SelectValue placeholder="Type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value={CommentType.CustomerReply.toString()}>Agent Reply</SelectItem>
                        <SelectItem value={CommentType.InternalNote.toString()}>Internal Note</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="visibility"
                render={({ field }) => (
                  <FormItem className="space-y-0">
                    <Select onValueChange={field.onChange} defaultValue={field.value.toString()}>
                      <FormControl>
                        <SelectTrigger className={`h-8 text-xs w-[140px] ${
                          field.value == CommentVisibility.Internal 
                            ? 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/50 dark:text-amber-200 dark:border-amber-800' 
                            : 'bg-background'
                        }`}>
                          <SelectValue placeholder="Visibility" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value={CommentVisibility.CustomerVisible.toString()}>Public to Customer</SelectItem>
                        <SelectItem value={CommentVisibility.Internal.toString()}>Internal Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </div>
          </div>
          <div className="p-0">
            <FormField
              control={form.control}
              name="body"
              render={({ field }) => (
                <FormItem className="space-y-0 border-none">
                  <FormControl>
                    <Textarea 
                      placeholder="Type your response here..." 
                      className={`min-h-[100px] resize-y border-0 focus-visible:ring-0 rounded-none p-4 ${
                        isInternal ? 'bg-transparent placeholder:text-amber-700/40 dark:placeholder:text-amber-400/40 text-amber-900 dark:text-amber-100' : ''
                      }`}
                      {...field} 
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div className="p-3 bg-muted/20 border-t flex justify-between items-center">
            <p className="px-2 text-xs text-destructive" role="alert">
              {form.formState.errors.body?.message ?? ""}
            </p>
            <Button 
              type="submit" 
              size="sm" 
              disabled={addComment.isPending || !form.watch("body").trim()} 
              className={`gap-2 ml-auto ${isInternal ? 'bg-amber-600 hover:bg-amber-700 text-white' : ''}`}
            >
              {addComment.isPending ? "Sending..." : "Post Comment"}
              <Send className="h-3 w-3" />
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}

// --- Main Component ---

export default function TicketDetail() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const { toast } = useToast();

  const { data: ticket, isLoading: ticketLoading, error: ticketError, refetch: refetchTicket } = useTicket(id);
  const commentsQ = useTicketComments(id);
  const timelineQ = useTicketTimeline(id);
  const attachmentsQ = useTicketAttachments(id);
  const productRefsQ = useTicketProductRefs(id);
  const { data: comments, isLoading: commentsLoading, error: commentsError, refetch: refetchComments } = commentsQ;
  const { data: timeline, isLoading: timelineLoading, error: timelineError, refetch: refetchTimeline } = timelineQ;
  const { data: attachments, isLoading: attachmentsLoading, error: attachmentsError, refetch: refetchAttachments } = attachmentsQ;
  const { data: productRefs, isLoading: refsLoading, error: refsError, refetch: refetchRefs } = productRefsQ;

  const updateTicket = useUpdateTicket(id || "");

  // Update handlers
  const handlePropertyChange = (field: string, value: any) => {
    updateTicket.mutate({ [field]: value }, {
      onSuccess: () => {
        toast({ title: "Ticket updated successfully" });
      },
      onError: (err) => {
        toast({ 
          title: "Update failed", 
          description: err.message, 
          variant: "destructive" 
        });
      }
    });
  };

  if (ticketError) {
    return <ErrorState error={ticketError} onRetry={() => refetchTicket()} />;
  }

  if (ticketLoading || !ticket) {
    return <LoadingState message="Loading ticket details..." />;
  }

  const isResolvedOrClosed = ticket.status === TicketStatus.Resolved || ticket.status === TicketStatus.Closed;

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* Header Bar */}
      <div className="bg-card border-b px-4 py-3 flex items-center gap-4 shrink-0 shadow-sm z-10 sticky top-0">
        <Button variant="ghost" size="icon" asChild className="shrink-0 h-8 w-8">
          <Link href="/support">
            <ChevronLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div className="flex-1 min-w-0 flex items-center gap-3">
          <Badge variant="outline" className="font-mono bg-muted/50 text-foreground border-border shrink-0">
            {ticket.ticketNumber}
          </Badge>
          <h1 className="text-lg font-semibold truncate" title={ticket.title}>{ticket.title}</h1>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
        {/* Main Left Column */}
        <div className="flex-1 overflow-y-auto min-w-0 border-r bg-muted/10">
          <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 space-y-8">
            
            {/* Original Request */}
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 border border-primary/20 font-bold shadow-sm">
                  {ticket.requesterName?.charAt(0) || <User className="h-5 w-5" />}
                </div>
                <div className="flex-1 min-w-0 pt-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold text-foreground">{ticket.requesterName || "Unknown Requester"}</span>
                    <span className="text-xs text-muted-foreground">&lt;{ticket.requesterEmail || "no email"}&gt;</span>
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1.5 mb-4">
                    <Clock className="h-3 w-3" />
                    Opened {formatRelative(ticket.createdAt)} ({formatDateTime(ticket.createdAt)})
                  </div>
                  <Card className="bg-card shadow-sm border-muted">
                    <CardContent className="p-5 text-sm prose dark:prose-invert max-w-none text-foreground/90 whitespace-pre-wrap leading-relaxed">
                      {ticket.description || <span className="italic text-muted-foreground">No description provided.</span>}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>

            <Separator className="bg-border/60" />

            {/* Comments Stream */}
            <div className="space-y-6">
              <h3 className="text-sm font-semibold tracking-wide text-muted-foreground uppercase flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Conversation
              </h3>
              
              {commentsLoading ? (
                <SkeletonList count={2} />
              ) : commentsError ? (
                <ErrorState error={commentsError} onRetry={() => refetchComments()} />
              ) : comments && comments.length > 0 ? (
                <div className="space-y-6">
                  {comments.map((comment) => {
                    const isInternal = comment.visibility === CommentVisibility.Internal;
                    const isSystem = comment.commentType === CommentType.SystemNote;
                    const isCustomer = comment.commentType === CommentType.CustomerReply;
                    
                    if (isSystem) return null; // We might want to render these differently or rely on timeline

                    return (
                      <div key={comment.id} className={`flex gap-4 items-start ${isCustomer ? '' : 'pl-4 md:pl-12'}`}>
                        {!isCustomer && (
                          <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold shadow-sm ${
                            isInternal 
                              ? 'bg-amber-100 text-amber-700 border border-amber-200 dark:bg-amber-900/50 dark:text-amber-200' 
                              : 'bg-secondary text-secondary-foreground border'
                          }`}>
                            {comment.authorName?.charAt(0) || 'A'}
                          </div>
                        )}
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-baseline justify-between gap-4 mb-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-sm text-foreground">{comment.authorName || "Unknown"}</span>
                              {isInternal && (
                                <Badge variant="secondary" className="text-[10px] h-4 px-1.5 bg-amber-100 text-amber-800 hover:bg-amber-100 dark:bg-amber-900/50 dark:text-amber-200 border-transparent">Internal Note</Badge>
                              )}
                              {!isCustomer && !isInternal && (
                                <Badge variant="secondary" className="text-[10px] h-4 px-1.5 bg-primary/10 text-primary border-transparent">Agent</Badge>
                              )}
                            </div>
                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                              {formatRelative(comment.createdAt)}
                            </span>
                          </div>
                          <Card className={`shadow-sm ${
                            isInternal ? 'bg-amber-50/50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900/50' : 
                            isCustomer ? 'bg-card' : 'bg-muted/30 border-muted'
                          }`}>
                            <CardContent className="p-4 text-sm whitespace-pre-wrap leading-relaxed text-foreground/90">
                              {comment.body}
                            </CardContent>
                          </Card>
                        </div>

                        {isCustomer && (
                          <div className="h-8 w-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 text-xs font-bold border border-primary/20 shadow-sm">
                            {comment.authorName?.charAt(0) || 'C'}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 text-sm text-muted-foreground border border-dashed rounded-lg bg-background">
                  No replies yet.
                </div>
              )}

              {/* Reply Box */}
              {!isResolvedOrClosed && (
                <div className="pt-4">
                  <CommentComposer ticketId={ticket.id} />
                </div>
              )}
            </div>

          </div>
        </div>

        {/* Right Sidebar - Properties & Context */}
        <div className="w-full md:w-80 shrink-0 bg-card border-l overflow-y-auto flex flex-col shadow-[-4px_0_15px_-10px_rgba(0,0,0,0.1)]">
          
          <div className="p-5 border-b bg-muted/10">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">Properties</h3>
            <div className="space-y-4">
              
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-medium text-foreground/80">Status</label>
                <Select 
                  value={ticket.status.toString()} 
                  onValueChange={(v) => handlePropertyChange('status', Number(v))}
                  disabled={updateTicket.isPending}
                >
                  <SelectTrigger className={`h-8 text-sm font-medium ${
                    ticket.status === TicketStatus.Open || ticket.status === TicketStatus.InProgress 
                      ? "border-blue-200 bg-blue-50/50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-300 dark:border-blue-900" 
                      : ticket.status === TicketStatus.Resolved || ticket.status === TicketStatus.Closed
                      ? "border-green-200 bg-green-50/50 text-green-700 dark:bg-green-950/30 dark:text-green-300 dark:border-green-900"
                      : ""
                  }`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ticketStatusOptions.map(opt => (
                      <SelectItem key={opt.value} value={opt.value.toString()}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-medium text-foreground/80">Priority</label>
                <Select 
                  value={ticket.priority.toString()} 
                  onValueChange={(v) => handlePropertyChange('priority', Number(v))}
                  disabled={updateTicket.isPending}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ticketPriorityOptions.map(opt => (
                      <SelectItem key={opt.value} value={opt.value.toString()}>
                        <div className="flex items-center gap-2">
                          <span className={`h-2 w-2 rounded-full ${
                            opt.value === TicketPriority.Urgent ? "bg-red-500" :
                            opt.value === TicketPriority.High ? "bg-orange-500" :
                            opt.value === TicketPriority.Normal ? "bg-blue-500" :
                            "bg-gray-400"
                          }`} />
                          {opt.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-medium text-foreground/80">Severity</label>
                <Select 
                  value={ticket.severity?.toString() || "none"} 
                  onValueChange={(v) => handlePropertyChange('severity', v === "none" ? null : Number(v))}
                  disabled={updateTicket.isPending}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="None set" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none" className="italic text-muted-foreground">None</SelectItem>
                    {ticketSeverityOptions.map(opt => (
                      <SelectItem key={opt.value} value={opt.value.toString()}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

            </div>
          </div>

          <div className="p-5 border-b bg-muted/10">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">
              Assignment
            </h3>
            <AssignmentPanel
              ticket={ticket}
              disabled={isResolvedOrClosed}
            />
          </div>

          <div className="p-5 border-b">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2">
              <Box className="h-3.5 w-3.5" />
              Product Context
            </h3>
            
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-start gap-4">
                <span className="text-muted-foreground text-xs">Product Code</span>
                <span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded text-foreground">{ticket.productCode || "—"}</span>
              </div>
              <div className="flex justify-between items-start gap-4">
                <span className="text-muted-foreground text-xs">Category</span>
                <span className="text-foreground text-right">{ticket.category || "—"}</span>
              </div>
            </div>

            {refsLoading ? (
              <SkeletonList count={1} className="mt-4" />
            ) : refsError ? (
              <div className="mt-4 text-xs text-destructive" role="alert">
                Couldn't load product references.{" "}
                <button
                  onClick={() => refetchRefs()}
                  className="underline hover:no-underline"
                >
                  Retry
                </button>
              </div>
            ) : productRefs && productRefs.length > 0 ? (
              <div className="mt-4 space-y-2">
                <span className="text-xs text-muted-foreground mb-1 block">Linked Entities</span>
                {productRefs.map(ref => (
                  <div key={ref.id} className="flex items-start gap-2 p-2 rounded-md bg-muted/40 border text-xs group cursor-default">
                    <Tag className="h-3.5 w-3.5 text-muted-foreground shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <div className="font-medium text-foreground truncate">{ref.displayLabel || ref.entityId}</div>
                      <div className="text-muted-foreground truncate">{ref.entityType}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : null}
          </div>

          <div className="p-5 border-b">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2">
              <Paperclip className="h-3.5 w-3.5" />
              Attachments
            </h3>

            {id ? <AttachmentUploader ticketId={id} /> : null}

            {attachmentsLoading ? (
              <SkeletonList count={1} />
            ) : attachmentsError ? (
              <div className="text-xs text-destructive" role="alert">
                Couldn't load attachments.{" "}
                <button
                  onClick={() => refetchAttachments()}
                  className="underline hover:no-underline"
                >
                  Retry
                </button>
              </div>
            ) : attachments && attachments.length > 0 ? (
              <div className="space-y-2">
                {attachments.map(att => (
                  <a 
                    key={att.id} 
                    href="#" 
                    onClick={(e) => e.preventDefault()}
                    className="flex items-center gap-3 p-2 rounded-md hover:bg-muted border border-transparent hover:border-border transition-colors group text-sm"
                  >
                    <div className="h-8 w-8 rounded bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <FileText className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-foreground truncate group-hover:text-primary transition-colors">{att.fileName}</div>
                      <div className="text-xs text-muted-foreground">{formatBytes(att.fileSizeBytes)}</div>
                    </div>
                  </a>
                ))}
              </div>
            ) : (
              <div className="text-xs text-muted-foreground italic">No attachments</div>
            )}
          </div>

          <div className="p-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2">
              <Activity className="h-3.5 w-3.5" />
              Timeline
            </h3>
            
            {timelineLoading ? (
              <SkeletonList count={3} />
            ) : timelineError ? (
              <div className="text-xs text-destructive" role="alert">
                Couldn't load timeline.{" "}
                <button
                  onClick={() => refetchTimeline()}
                  className="underline hover:no-underline"
                >
                  Retry
                </button>
              </div>
            ) : timeline && timeline.length > 0 ? (
              <div className="relative pl-3 border-l-2 border-muted space-y-5 py-2">
                {timeline.filter(t => t.type === "event").map((event, i) => (
                  <div key={i} className="relative text-xs">
                    <div className="absolute -left-[17px] top-1 h-2 w-2 rounded-full bg-border border-2 border-background" />
                    <div className="text-muted-foreground mb-0.5">{formatDateTime(event.createdAt)}</div>
                    <div className="font-medium text-foreground">{event.summary || event.eventType}</div>
                    {event.actorName && (
                      <div className="text-muted-foreground">by {event.actorName}</div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
               <div className="text-xs text-muted-foreground italic">No events</div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}

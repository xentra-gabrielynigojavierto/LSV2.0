import { useSyncExternalStore } from "react";
import {
  getActivePersona,
  subscribeToPersonaChanges,
} from "@/lib/auth/devSession";
import type { DevPersona } from "@/lib/auth/personas";

/**
 * Reactive hook that returns the active dev persona.
 *
 * NOTE: This is dev-only scaffolding. In production the persona resolves to
 * the default agent persona (because `bootstrapDevSession` is a no-op outside
 * DEV) — callers that branch on persona role MUST gate that branch on
 * `import.meta.env.DEV` so production behaviour is not driven by a fake
 * persona. When real OIDC auth lands, this hook should be replaced with one
 * that derives from the real session.
 */
export function useCurrentPersona(): DevPersona {
  return useSyncExternalStore(
    subscribeToPersonaChanges,
    getActivePersona,
    getActivePersona,
  );
}

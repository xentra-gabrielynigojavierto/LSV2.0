import { http, HttpResponse } from "msw";

import type {
  Comment,
  CreateCommentRequest,
  CreateTicketRequest,
  PagedResponse,
  Ticket,
  TimelineItem,
  UpdateTicketRequest,
} from "../api/types";
import {
  CommentType,
  CommentVisibility,
  TicketStatus,
} from "../api/types";
import type {
  AddQueueMemberRequest,
  AssignTicketRequest,
  CreateQueueRequest,
  SupportQueue,
  SupportQueueMember,
  UpdateQueueRequest,
} from "../api/queues";
import { QueueMemberRole } from "../api/queues";
import { buildTimeline, mockDb } from "./data";

const BASE = "/support/api";

function nextTicketNumber(): string {
  const max = mockDb.tickets.reduce((acc, t) => {
    const m = /SUP-(\d+)/.exec(t.ticketNumber);
    if (!m || !m[1]) return acc;
    const n = Number(m[1]);
    return n > acc ? n : acc;
  }, 1000);
  return `SUP-${max + 1}`;
}

function uuid(prefix: string): string {
  // Not a real UUID, but stable enough for the mock world.
  return `${prefix}-${Math.random().toString(16).slice(2, 10)}-${Date.now().toString(16)}`;
}

function toBool(v: string | null | undefined): boolean {
  return v === "true" || v === "1" || v === "yes";
}

export const handlers = [
  http.get(`${BASE}/tickets`, ({ request }) => {
    const url = new URL(request.url);
    const sp = url.searchParams;
    const status = sp.get("status");
    const priority = sp.get("priority");
    const severity = sp.get("severity");
    const source = sp.get("source");
    const productCode = sp.get("productCode");
    const category = sp.get("category");
    const search = sp.get("search")?.toLowerCase() ?? "";
    const page = Math.max(1, Number(sp.get("page") ?? 1));
    const pageSize = Math.max(1, Math.min(100, Number(sp.get("pageSize") ?? 25)));

    const assignedUserId = sp.get("assignedUserId");
    const assignedQueueId = sp.get("assignedQueueId");
    const unassigned = toBool(sp.get("unassigned"));

    let items = [...mockDb.tickets];
    if (status !== null && status !== "") items = items.filter((t) => t.status === Number(status));
    if (priority !== null && priority !== "")
      items = items.filter((t) => t.priority === Number(priority));
    if (severity !== null && severity !== "")
      items = items.filter((t) => t.severity === Number(severity));
    if (source !== null && source !== "") items = items.filter((t) => t.source === Number(source));
    if (productCode) items = items.filter((t) => t.productCode === productCode);
    if (category) items = items.filter((t) => t.category === category);
    if (assignedUserId)
      items = items.filter((t) => t.assignedUserId === assignedUserId);
    if (assignedQueueId)
      items = items.filter((t) => t.assignedQueueId === assignedQueueId);
    if (unassigned)
      items = items.filter(
        (t) => t.assignedUserId == null && t.assignedQueueId == null,
      );
    if (search) {
      items = items.filter(
        (t) =>
          t.title.toLowerCase().includes(search) ||
          t.ticketNumber.toLowerCase().includes(search) ||
          (t.description ?? "").toLowerCase().includes(search) ||
          (t.requesterName ?? "").toLowerCase().includes(search),
      );
    }
    items.sort(
      (a, b) =>
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime(),
    );
    const total = items.length;
    const start = (page - 1) * pageSize;
    const paged = items.slice(start, start + pageSize);
    const body: PagedResponse<Ticket> = { items: paged, page, pageSize, total };
    return HttpResponse.json(body);
  }),

  http.get(`${BASE}/tickets/:id`, ({ params }) => {
    const t = mockDb.tickets.find((x) => x.id === params.id);
    if (!t) return new HttpResponse(null, { status: 404 });
    return HttpResponse.json(t);
  }),

  http.post(`${BASE}/tickets`, async ({ request }) => {
    const body = (await request.json()) as CreateTicketRequest;
    if (!body || typeof body.title !== "string" || body.title.trim() === "") {
      return HttpResponse.json(
        {
          type: "https://tools.ietf.org/html/rfc7231#section-6.5.1",
          title: "One or more validation errors occurred.",
          status: 400,
          errors: { Title: ["Title is required."] },
        },
        { status: 400 },
      );
    }
    const now = new Date().toISOString();
    const t: Ticket = {
      id: uuid("tkt"),
      tenantId: "tnt-demo-acme",
      productCode: body.productCode ?? null,
      ticketNumber: nextTicketNumber(),
      title: body.title.trim(),
      description: body.description ?? null,
      status: TicketStatus.Open,
      priority: body.priority ?? 1,
      severity: body.severity ?? null,
      category: body.category ?? null,
      source: body.source ?? 0,
      requesterUserId: body.requesterUserId ?? null,
      requesterName: body.requesterName ?? null,
      requesterEmail: body.requesterEmail ?? null,
      assignedUserId: null,
      assignedQueueId: null,
      dueAt: null,
      resolvedAt: null,
      closedAt: null,
      createdAt: now,
      updatedAt: now,
      createdByUserId: body.requesterUserId ?? "usr-mock-current",
      updatedByUserId: null,
    };
    mockDb.tickets.unshift(t);
    mockDb.commentsByTicket[t.id] = [];
    return HttpResponse.json(t, { status: 201 });
  }),

  http.put(`${BASE}/tickets/:id`, async ({ params, request }) => {
    const id = String(params.id);
    const t = mockDb.tickets.find((x) => x.id === id);
    if (!t) return new HttpResponse(null, { status: 404 });
    const body = (await request.json()) as UpdateTicketRequest;
    // Only validate the simplest forward transitions; the real backend has
    // a fuller state machine. UI exercises happy-path transitions.
    if (body.status != null) {
      const forbidden: Array<[TicketStatus, TicketStatus]> = [
        [TicketStatus.Closed, TicketStatus.Open],
        [TicketStatus.Cancelled, TicketStatus.InProgress],
      ];
      if (forbidden.some(([from, to]) => t.status === from && body.status === to)) {
        return HttpResponse.json(
          { error: `Cannot transition ticket from ${t.status} to ${body.status}.` },
          { status: 400 },
        );
      }
      t.status = body.status;
      if (body.status === TicketStatus.Resolved && !t.resolvedAt)
        t.resolvedAt = new Date().toISOString();
      if (body.status === TicketStatus.Closed && !t.closedAt)
        t.closedAt = new Date().toISOString();
    }
    if (body.priority != null) t.priority = body.priority;
    if (body.severity !== undefined) t.severity = body.severity ?? null;
    if (body.title != null) t.title = body.title;
    if (body.description !== undefined) t.description = body.description ?? null;
    if (body.category !== undefined) t.category = body.category ?? null;
    if (body.assignedUserId !== undefined)
      t.assignedUserId = body.assignedUserId ?? null;
    if (body.assignedQueueId !== undefined)
      t.assignedQueueId = body.assignedQueueId ?? null;
    if (body.dueAt !== undefined) t.dueAt = body.dueAt ?? null;
    if (body.requesterName !== undefined)
      t.requesterName = body.requesterName ?? null;
    if (body.requesterEmail !== undefined)
      t.requesterEmail = body.requesterEmail ?? null;
    t.updatedAt = new Date().toISOString();
    return HttpResponse.json(t);
  }),

  http.get(`${BASE}/tickets/:id/comments`, ({ params }) => {
    const id = String(params.id);
    const arr = mockDb.commentsByTicket[id] ?? [];
    return HttpResponse.json(arr);
  }),

  http.post(`${BASE}/tickets/:id/comments`, async ({ params, request }) => {
    const id = String(params.id);
    if (!mockDb.tickets.find((x) => x.id === id))
      return new HttpResponse(null, { status: 404 });
    const body = (await request.json()) as CreateCommentRequest;
    if (!body || typeof body.body !== "string" || body.body.trim() === "") {
      return HttpResponse.json(
        {
          type: "https://tools.ietf.org/html/rfc7231#section-6.5.1",
          title: "One or more validation errors occurred.",
          status: 400,
          errors: { Body: ["Body is required."] },
        },
        { status: 400 },
      );
    }
    const c: Comment = {
      id: uuid("cmt"),
      ticketId: id,
      commentType: body.commentType ?? CommentType.CustomerReply,
      visibility: body.visibility ?? CommentVisibility.CustomerVisible,
      body: body.body.trim(),
      authorUserId: body.authorUserId ?? "usr-mock-current",
      authorName: body.authorName ?? "Demo User",
      authorEmail: body.authorEmail ?? "demo.user@acmelaw.example",
      createdAt: new Date().toISOString(),
    };
    const list = mockDb.commentsByTicket[id] ?? [];
    list.push(c);
    mockDb.commentsByTicket[id] = list;
    const t = mockDb.tickets.find((x) => x.id === id);
    if (t) t.updatedAt = c.createdAt;
    return HttpResponse.json(c, { status: 201 });
  }),

  http.get(`${BASE}/tickets/:id/timeline`, ({ params }) => {
    const id = String(params.id);
    return HttpResponse.json(buildTimeline(id));
  }),

  http.get(`${BASE}/tickets/:id/attachments`, ({ params }) => {
    const id = String(params.id);
    return HttpResponse.json(mockDb.attachmentsByTicket[id] ?? []);
  }),

  // SUP-INT-08: simulate the multipart upload endpoint with the Local provider.
  http.post(`${BASE}/tickets/:id/attachments/upload`, async ({ params, request }) => {
    const id = String(params.id);
    const ticketExists = mockDb.tickets.some((t) => t.id === id);
    if (!ticketExists) return new HttpResponse(null, { status: 404 });

    let form: FormData;
    try {
      form = await request.formData();
    } catch {
      return HttpResponse.json(
        { title: "multipart/form-data required" },
        { status: 400 },
      );
    }

    const file = form.get("file");
    if (!(file instanceof File)) {
      return HttpResponse.json(
        { title: "Validation failed", errors: { file: ["A file is required."] } },
        { status: 400 },
      );
    }
    if (file.size === 0) {
      return HttpResponse.json(
        { title: "Validation failed", errors: { file: ["File is empty."] } },
        { status: 400 },
      );
    }
    const maxBytes = 25 * 1024 * 1024;
    if (file.size > maxBytes) {
      return HttpResponse.json(
        {
          title: "Validation failed",
          errors: { file: ["File exceeds the maximum allowed size of 25 MB."] },
        },
        { status: 400 },
      );
    }

    const displayName = (form.get("display_name") as string) || file.name;
    // Server-side: uploader identity is derived from the JWT subject, NOT
    // from the form. Mirror that here so dev mode behaves the same way.
    const uploadedByUserId = "usr-mock-current";

    const documentId = `local-${crypto.randomUUID().replace(/-/g, "")}`;
    const attachment = {
      id: crypto.randomUUID(),
      ticketId: id,
      documentId,
      fileName: displayName,
      contentType: file.type || null,
      fileSizeBytes: file.size,
      uploadedByUserId,
      createdAt: new Date().toISOString(),
    };
    const list = mockDb.attachmentsByTicket[id] ?? [];
    list.push(attachment);
    mockDb.attachmentsByTicket[id] = list;
    const t = mockDb.tickets.find((x) => x.id === id);
    if (t) t.updatedAt = attachment.createdAt;
    return HttpResponse.json(attachment, { status: 201 });
  }),

  http.get(`${BASE}/tickets/:id/product-refs`, ({ params }) => {
    const id = String(params.id);
    return HttpResponse.json(mockDb.productRefsByTicket[id] ?? []);
  }),

  // --- Queues ---

  http.get(`${BASE}/queues`, ({ request }) => {
    const url = new URL(request.url);
    const sp = url.searchParams;
    const productCode = sp.get("productCode");
    const isActive = sp.get("isActive");
    const search = sp.get("search")?.toLowerCase() ?? "";

    let items = [...mockDb.queues];
    if (productCode) items = items.filter((q) => q.productCode === productCode);
    if (isActive !== null && isActive !== "")
      items = items.filter((q) => q.isActive === toBool(isActive));
    if (search)
      items = items.filter(
        (q) =>
          q.name.toLowerCase().includes(search) ||
          (q.description ?? "").toLowerCase().includes(search),
      );
    items.sort((a, b) => a.name.localeCompare(b.name));
    return HttpResponse.json(items);
  }),

  http.get(`${BASE}/queues/:queueId`, ({ params }) => {
    const q = mockDb.queues.find((x) => x.id === params.queueId);
    if (!q) return new HttpResponse(null, { status: 404 });
    return HttpResponse.json(q);
  }),

  http.post(`${BASE}/queues`, async ({ request }) => {
    const body = (await request.json()) as CreateQueueRequest;
    if (!body || typeof body.name !== "string" || body.name.trim() === "") {
      return HttpResponse.json(
        {
          type: "https://tools.ietf.org/html/rfc7231#section-6.5.1",
          title: "One or more validation errors occurred.",
          status: 400,
          errors: { Name: ["Name is required."] },
        },
        { status: 400 },
      );
    }
    const name = body.name.trim();
    const dup = mockDb.queues.find(
      (q) => q.name.toLowerCase() === name.toLowerCase(),
    );
    if (dup) {
      return HttpResponse.json(
        {
          title: `A queue named '${name}' already exists.`,
          status: 409,
        },
        { status: 409 },
      );
    }
    const now = new Date().toISOString();
    const q: SupportQueue = {
      id: uuid("queue"),
      tenantId: "tnt-demo-acme",
      name,
      description: body.description?.trim() || null,
      productCode: body.productCode?.trim().toUpperCase() || null,
      isActive: body.isActive ?? true,
      createdAt: now,
      updatedAt: now,
      createdByUserId: "usr-mock-current",
      updatedByUserId: null,
    };
    mockDb.queues.push(q);
    mockDb.queueMembersByQueue[q.id] = [];
    return HttpResponse.json(q, { status: 201 });
  }),

  http.put(`${BASE}/queues/:queueId`, async ({ params, request }) => {
    const queueId = String(params.queueId);
    const q = mockDb.queues.find((x) => x.id === queueId);
    if (!q) return new HttpResponse(null, { status: 404 });
    const body = (await request.json()) as UpdateQueueRequest;
    if (body.name !== undefined && body.name !== null) {
      const newName = body.name.trim();
      if (newName === "") {
        return HttpResponse.json(
          {
            status: 400,
            errors: { Name: ["Name cannot be empty."] },
          },
          { status: 400 },
        );
      }
      const dup = mockDb.queues.find(
        (other) =>
          other.id !== queueId &&
          other.name.toLowerCase() === newName.toLowerCase(),
      );
      if (dup) {
        return HttpResponse.json(
          { title: `A queue named '${newName}' already exists.`, status: 409 },
          { status: 409 },
        );
      }
      q.name = newName;
    }
    if (body.description !== undefined)
      q.description = body.description?.trim() || null;
    if (body.productCode !== undefined)
      q.productCode = body.productCode?.trim().toUpperCase() || null;
    if (body.isActive !== undefined && body.isActive !== null)
      q.isActive = body.isActive;
    q.updatedAt = new Date().toISOString();
    q.updatedByUserId = "usr-mock-current";
    return HttpResponse.json(q);
  }),

  http.get(`${BASE}/queues/:queueId/members`, ({ params }) => {
    const queueId = String(params.queueId);
    if (!mockDb.queues.find((q) => q.id === queueId))
      return new HttpResponse(null, { status: 404 });
    const members = mockDb.queueMembersByQueue[queueId] ?? [];
    const sorted = [...members].sort((a, b) => {
      if (a.role !== b.role) return b.role - a.role; // Manager first
      return a.userId.localeCompare(b.userId);
    });
    return HttpResponse.json(sorted);
  }),

  http.post(`${BASE}/queues/:queueId/members`, async ({ params, request }) => {
    const queueId = String(params.queueId);
    const q = mockDb.queues.find((x) => x.id === queueId);
    if (!q) return new HttpResponse(null, { status: 404 });
    const body = (await request.json()) as AddQueueMemberRequest;
    if (!body || typeof body.userId !== "string" || body.userId.trim() === "") {
      return HttpResponse.json(
        {
          status: 400,
          errors: { UserId: ["User id is required."] },
        },
        { status: 400 },
      );
    }
    const userId = body.userId.trim();
    const list = mockDb.queueMembersByQueue[queueId] ?? [];
    const existing = list.find((m) => m.userId === userId);
    if (existing && existing.isActive) {
      return HttpResponse.json(
        {
          title: `User '${userId}' is already an active member of this queue.`,
          status: 409,
        },
        { status: 409 },
      );
    }
    const now = new Date().toISOString();
    if (existing) {
      existing.isActive = true;
      existing.role = body.role ?? QueueMemberRole.Agent;
      existing.updatedAt = now;
      return HttpResponse.json(existing, { status: 201 });
    }
    const m: SupportQueueMember = {
      id: uuid("qm"),
      queueId,
      tenantId: q.tenantId,
      userId,
      role: body.role ?? QueueMemberRole.Agent,
      isActive: body.isActive ?? true,
      createdAt: now,
      updatedAt: now,
    };
    list.push(m);
    mockDb.queueMembersByQueue[queueId] = list;
    return HttpResponse.json(m, { status: 201 });
  }),

  http.delete(
    `${BASE}/queues/:queueId/members/:memberId`,
    ({ params }) => {
      const queueId = String(params.queueId);
      const memberId = String(params.memberId);
      const list = mockDb.queueMembersByQueue[queueId] ?? [];
      const m = list.find((x) => x.id === memberId);
      if (!m) return new HttpResponse(null, { status: 404 });
      m.isActive = false;
      m.updatedAt = new Date().toISOString();
      return new HttpResponse(null, { status: 204 });
    },
  ),

  // --- Ticket assignment ---

  http.put(`${BASE}/tickets/:id/assignment`, async ({ params, request }) => {
    const id = String(params.id);
    const t = mockDb.tickets.find((x) => x.id === id);
    if (!t) return new HttpResponse(null, { status: 404 });
    const body = (await request.json()) as AssignTicketRequest;
    const errors: Record<string, string[]> = {};
    const clear = body.clearAssignment === true;
    const hasUser =
      body.assignedUserId !== undefined && body.assignedUserId !== null;
    const hasQueue =
      body.assignedQueueId !== undefined && body.assignedQueueId !== null;
    if (clear && (hasUser || hasQueue)) {
      errors.ClearAssignment = [
        "clearAssignment cannot be combined with assignedUserId or assignedQueueId.",
      ];
    }
    if (!clear && !hasUser && !hasQueue) {
      errors.Request = [
        "At least one of assignedUserId, assignedQueueId, or clearAssignment must be provided.",
      ];
    }
    if (Object.keys(errors).length > 0) {
      return HttpResponse.json({ status: 400, errors }, { status: 400 });
    }

    const previousUser = t.assignedUserId;
    const previousQueue = t.assignedQueueId;

    if (clear) {
      t.assignedUserId = null;
      t.assignedQueueId = null;
    } else {
      if (hasQueue) {
        const qid = String(body.assignedQueueId);
        const q = mockDb.queues.find((x) => x.id === qid);
        if (!q) {
          return HttpResponse.json(
            { title: `Queue '${qid}' not found.`, status: 404 },
            { status: 404 },
          );
        }
        if (!q.isActive) {
          return HttpResponse.json(
            {
              status: 400,
              errors: {
                AssignedQueueId: [`Queue '${q.name}' is not active.`],
              },
            },
            { status: 400 },
          );
        }
        t.assignedQueueId = q.id;
      }
      if (hasUser) {
        t.assignedUserId = String(body.assignedUserId);
      }
    }
    t.updatedAt = new Date().toISOString();
    t.updatedByUserId = "usr-mock-current";

    const evt: TimelineItem = {
      type: "event",
      createdAt: t.updatedAt,
      summary: clear ? "Assignment cleared" : "Assignment changed",
      body: null,
      eventType: "assignment_changed",
      commentType: null,
      visibility: null,
      actorUserId: "usr-mock-current",
      actorName: "Demo User",
      actorEmail: "demo.user@acmelaw.example",
      metadataJson: JSON.stringify({
        previous_assigned_user_id: previousUser,
        previous_assigned_queue_id: previousQueue,
        assigned_user_id: t.assignedUserId,
        assigned_queue_id: t.assignedQueueId,
      }),
    };
    const evts = mockDb.assignmentEventsByTicket[id] ?? [];
    evts.push(evt);
    mockDb.assignmentEventsByTicket[id] = evts;

    return HttpResponse.json(t);
  }),
];

// Allow tests to opt into specific failure modes.
export const failureHandlers = {
  unauthorized: http.get(`${BASE}/tickets`, () =>
    new HttpResponse(null, { status: 401 }),
  ),
  forbidden: http.get(`${BASE}/tickets`, () =>
    new HttpResponse(null, { status: 403 }),
  ),
  notFound: http.get(`${BASE}/tickets/:id`, () =>
    new HttpResponse(null, { status: 404 }),
  ),
};
export { toBool };

// Seed data for the dev/preview MSW mock layer. Mirrors the .NET DTO shape.
//
// Stable IDs so reloading the page lands the user back on the same ticket.

import type {
  Comment,
  ProductReference,
  Ticket,
  TicketAttachment,
  TimelineItem,
} from "../api/types";
import {
  CommentType,
  CommentVisibility,
  TicketPriority,
  TicketSeverity,
  TicketSource,
  TicketStatus,
} from "../api/types";
import type { SupportQueue, SupportQueueMember } from "../api/queues";
import { QueueMemberRole } from "../api/queues";

const TENANT = "tnt-demo-acme";

const queues: SupportQueue[] = [
  {
    id: "queue-tier2",
    tenantId: TENANT,
    name: "Tier 2 Support",
    description: "Escalation queue for technical issues requiring deeper investigation.",
    productCode: "MATTER-MGMT",
    isActive: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 60).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(),
    createdByUserId: "agent-okafor",
    updatedByUserId: "agent-okafor",
  },
  {
    id: "queue-billing",
    tenantId: TENANT,
    name: "Billing & Trust",
    description: "Trust accounting, ledger exports, and disbursement issues.",
    productCode: "BILLING",
    isActive: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 60).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(),
    createdByUserId: "agent-okafor",
    updatedByUserId: null,
  },
  {
    id: "queue-rules",
    tenantId: TENANT,
    name: "Court Rules & Calendaring",
    description: "Calendar, deadlines, and jurisdictional rule update issues.",
    productCode: "CALENDARING",
    isActive: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 60).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(),
    createdByUserId: "agent-okafor",
    updatedByUserId: null,
  },
  {
    id: "queue-onboarding",
    tenantId: TENANT,
    name: "Onboarding (Inactive)",
    description: "Legacy queue, retained for historic ticket mapping.",
    productCode: null,
    isActive: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 180).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 90).toISOString(),
    createdByUserId: "agent-okafor",
    updatedByUserId: "agent-okafor",
  },
];

const queueMembersByQueue: Record<string, SupportQueueMember[]> = {
  "queue-tier2": [
    {
      id: "qm-t2-1",
      queueId: "queue-tier2",
      tenantId: TENANT,
      userId: "agent-marlowe",
      role: QueueMemberRole.Lead,
      isActive: true,
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 50).toISOString(),
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 50).toISOString(),
    },
    {
      id: "qm-t2-2",
      queueId: "queue-tier2",
      tenantId: TENANT,
      userId: "agent-okafor",
      role: QueueMemberRole.Agent,
      isActive: true,
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 45).toISOString(),
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 45).toISOString(),
    },
  ],
  "queue-billing": [
    {
      id: "qm-bl-1",
      queueId: "queue-billing",
      tenantId: TENANT,
      userId: "agent-okafor",
      role: QueueMemberRole.Manager,
      isActive: true,
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 50).toISOString(),
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 50).toISOString(),
    },
  ],
  "queue-rules": [
    {
      id: "qm-rl-1",
      queueId: "queue-rules",
      tenantId: TENANT,
      userId: "agent-okafor",
      role: QueueMemberRole.Lead,
      isActive: true,
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(),
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(),
    },
  ],
  "queue-onboarding": [],
};

const assignmentEventsByTicket: Record<string, TimelineItem[]> = {};

const tickets: Ticket[] = [
  {
    id: "11111111-1111-1111-1111-111111111101",
    tenantId: TENANT,
    productCode: "matter-mgmt",
    ticketNumber: "SUP-1001",
    title: "Cannot upload signed PDF to client matter",
    description:
      "Attempting to upload a 12 MB signed PDF to matter MTR-08213 returns a 500 after roughly 30 seconds. Smaller PDFs upload fine. Started this morning.",
    status: TicketStatus.InProgress,
    priority: TicketPriority.High,
    severity: TicketSeverity.Sev2,
    category: "documents",
    source: TicketSource.Portal,
    requesterUserId: "usr-acme-paralegal-3",
    requesterName: "Diane Marchetti",
    requesterEmail: "diane.marchetti@acmelaw.example",
    assignedUserId: "agent-marlowe",
    assignedQueueId: "queue-tier2",
    dueAt: new Date(Date.now() + 1000 * 60 * 60 * 6).toISOString(),
    resolvedAt: null,
    closedAt: null,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    createdByUserId: "usr-acme-paralegal-3",
    updatedByUserId: "agent-marlowe",
  },
  {
    id: "11111111-1111-1111-1111-111111111102",
    tenantId: TENANT,
    productCode: "billing",
    ticketNumber: "SUP-1002",
    title: "Trust ledger export missing two transactions",
    description:
      "Exporting Q1 trust ledger to CSV: two transactions from Feb 14 are missing. They appear in the UI ledger view but not the export.",
    status: TicketStatus.Open,
    priority: TicketPriority.Urgent,
    severity: TicketSeverity.Sev1,
    category: "exports",
    source: TicketSource.Email,
    requesterUserId: "usr-acme-finance-1",
    requesterName: "Marcus Lin",
    requesterEmail: "marcus.lin@acmelaw.example",
    assignedUserId: null,
    assignedQueueId: null,
    dueAt: new Date(Date.now() + 1000 * 60 * 60 * 2).toISOString(),
    resolvedAt: null,
    closedAt: null,
    createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    createdByUserId: "usr-acme-finance-1",
    updatedByUserId: null,
  },
  {
    id: "11111111-1111-1111-1111-111111111103",
    tenantId: TENANT,
    productCode: "calendaring",
    ticketNumber: "SUP-1003",
    title: "Court rules update for IL Cook County not applied",
    description:
      "Court rule update published April 2 has not propagated to deadlines created after that date. Cases in IL-COOK only.",
    status: TicketStatus.Pending,
    priority: TicketPriority.Normal,
    severity: TicketSeverity.Sev3,
    category: "rules",
    source: TicketSource.Portal,
    requesterUserId: "usr-acme-attorney-7",
    requesterName: "Priya Shah",
    requesterEmail: "priya.shah@acmelaw.example",
    assignedUserId: "agent-okafor",
    assignedQueueId: "queue-rules",
    dueAt: null,
    resolvedAt: null,
    closedAt: null,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 36).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
    createdByUserId: "usr-acme-attorney-7",
    updatedByUserId: "agent-okafor",
  },
  {
    id: "11111111-1111-1111-1111-111111111104",
    tenantId: TENANT,
    productCode: "matter-mgmt",
    ticketNumber: "SUP-1004",
    title: "Conflict check returns false positive on 'Smith v. Smith'",
    description:
      "Running a conflict check for new client 'Smith Industrial' returns hits on the unrelated 'Smith v. Smith' family matter from 2019.",
    status: TicketStatus.Resolved,
    priority: TicketPriority.Low,
    severity: TicketSeverity.Sev4,
    category: "intake",
    source: TicketSource.Phone,
    requesterUserId: "usr-acme-attorney-2",
    requesterName: "Joaquín Reyes",
    requesterEmail: "j.reyes@acmelaw.example",
    assignedUserId: "agent-marlowe",
    assignedQueueId: "queue-tier2",
    dueAt: null,
    resolvedAt: new Date(Date.now() - 1000 * 60 * 60 * 22).toISOString(),
    closedAt: null,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 22).toISOString(),
    createdByUserId: "usr-acme-attorney-2",
    updatedByUserId: "agent-marlowe",
  },
  {
    id: "11111111-1111-1111-1111-111111111105",
    tenantId: TENANT,
    productCode: "billing",
    ticketNumber: "SUP-1005",
    title: "ACH disbursement batch stuck in 'Submitted'",
    description:
      "Disbursement batch BAT-44193 has been in Submitted status for 48 hours. No webhook received from processor.",
    status: TicketStatus.Closed,
    priority: TicketPriority.Normal,
    severity: TicketSeverity.Sev3,
    category: "payments",
    source: TicketSource.Portal,
    requesterUserId: "usr-acme-finance-1",
    requesterName: "Marcus Lin",
    requesterEmail: "marcus.lin@acmelaw.example",
    assignedUserId: "agent-okafor",
    assignedQueueId: "queue-billing",
    dueAt: null,
    resolvedAt: new Date(Date.now() - 1000 * 60 * 60 * 96).toISOString(),
    closedAt: new Date(Date.now() - 1000 * 60 * 60 * 80).toISOString(),
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 120).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 80).toISOString(),
    createdByUserId: "usr-acme-finance-1",
    updatedByUserId: "agent-okafor",
  },
];

const commentsByTicket: Record<string, Comment[]> = {
  "11111111-1111-1111-1111-111111111101": [
    {
      id: "c1-1",
      ticketId: "11111111-1111-1111-1111-111111111101",
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
      body: "Original ticket: 12 MB signed PDF fails. Reproduces on Chrome 124 and Safari 17.",
      authorUserId: "usr-acme-paralegal-3",
      authorName: "Diane Marchetti",
      authorEmail: "diane.marchetti@acmelaw.example",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    },
    {
      id: "c1-2",
      ticketId: "11111111-1111-1111-1111-111111111101",
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
      body: "Thanks Diane. We can see the 500 in our logs at 09:14 UTC. Investigating the upload pipeline now — appears related to a virus-scan timeout for files over 10 MB.",
      authorUserId: "agent-marlowe",
      authorName: "Eli Marlowe",
      authorEmail: "e.marlowe@example.com",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
    },
    {
      id: "c1-3",
      ticketId: "11111111-1111-1111-1111-111111111101",
      commentType: CommentType.InternalNote,
      visibility: CommentVisibility.Internal,
      body: "Bumped scan timeout from 30s to 90s in staging — confirmed upload succeeds. Awaiting production rollout window.",
      authorUserId: "agent-marlowe",
      authorName: "Eli Marlowe",
      authorEmail: "e.marlowe@example.com",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 1).toISOString(),
    },
  ],
  "11111111-1111-1111-1111-111111111102": [
    {
      id: "c2-1",
      ticketId: "11111111-1111-1111-1111-111111111102",
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
      body: "Sending the export and the screenshot of the ledger view. Two missing transactions are TR-9921 and TR-9923.",
      authorUserId: "usr-acme-finance-1",
      authorName: "Marcus Lin",
      authorEmail: "marcus.lin@acmelaw.example",
      createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    },
  ],
  "11111111-1111-1111-1111-111111111103": [
    {
      id: "c3-1",
      ticketId: "11111111-1111-1111-1111-111111111103",
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
      body: "We've opened a sync ticket with the rules vendor. ETA 24-48h for the patched ruleset to land in calendaring.",
      authorUserId: "agent-okafor",
      authorName: "Ada Okafor",
      authorEmail: "a.okafor@example.com",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
    },
  ],
  "11111111-1111-1111-1111-111111111104": [
    {
      id: "c4-1",
      ticketId: "11111111-1111-1111-1111-111111111104",
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
      body: "Resolved by tightening the conflict-check name token threshold from 0.62 to 0.78. Smith Industrial no longer matches Smith v. Smith.",
      authorUserId: "agent-marlowe",
      authorName: "Eli Marlowe",
      authorEmail: "e.marlowe@example.com",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 22).toISOString(),
    },
  ],
  "11111111-1111-1111-1111-111111111105": [],
};

const attachmentsByTicket: Record<string, TicketAttachment[]> = {
  "11111111-1111-1111-1111-111111111101": [
    {
      id: "a1-1",
      ticketId: "11111111-1111-1111-1111-111111111101",
      documentId: "doc-7e2c11",
      fileName: "engagement-letter-signed.pdf",
      contentType: "application/pdf",
      fileSizeBytes: 12_318_904,
      uploadedByUserId: "usr-acme-paralegal-3",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    },
    {
      id: "a1-2",
      ticketId: "11111111-1111-1111-1111-111111111101",
      documentId: "doc-7e2c12",
      fileName: "browser-console.log",
      contentType: "text/plain",
      fileSizeBytes: 4_812,
      uploadedByUserId: "usr-acme-paralegal-3",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    },
  ],
  "11111111-1111-1111-1111-111111111102": [
    {
      id: "a2-1",
      ticketId: "11111111-1111-1111-1111-111111111102",
      documentId: "doc-9f3a01",
      fileName: "trust-ledger-q1-2026.csv",
      contentType: "text/csv",
      fileSizeBytes: 84_211,
      uploadedByUserId: "usr-acme-finance-1",
      createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    },
  ],
};

const productRefsByTicket: Record<string, ProductReference[]> = {
  "11111111-1111-1111-1111-111111111101": [
    {
      id: "p1-1",
      ticketId: "11111111-1111-1111-1111-111111111101",
      productCode: "matter-mgmt",
      entityType: "matter",
      entityId: "MTR-08213",
      displayLabel: "Acme Holdings — General Counsel Engagement",
      metadataJson: null,
      createdByUserId: "usr-acme-paralegal-3",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    },
  ],
  "11111111-1111-1111-1111-111111111102": [
    {
      id: "p2-1",
      ticketId: "11111111-1111-1111-1111-111111111102",
      productCode: "billing",
      entityType: "ledger",
      entityId: "LDG-Q1-2026",
      displayLabel: "Q1 2026 Trust Ledger",
      metadataJson: null,
      createdByUserId: "usr-acme-finance-1",
      createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    },
    {
      id: "p2-2",
      ticketId: "11111111-1111-1111-1111-111111111102",
      productCode: "billing",
      entityType: "transaction",
      entityId: "TR-9921",
      displayLabel: "Disbursement TR-9921 (Feb 14)",
      metadataJson: null,
      createdByUserId: "usr-acme-finance-1",
      createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    },
  ],
};

export const mockDb = {
  tickets,
  commentsByTicket,
  attachmentsByTicket,
  productRefsByTicket,
  queues,
  queueMembersByQueue,
  assignmentEventsByTicket,
};

export function buildTimeline(ticketId: string): TimelineItem[] {
  const t = tickets.find((x) => x.id === ticketId);
  if (!t) return [];
  const items: TimelineItem[] = [];
  items.push({
    type: "event",
    createdAt: t.createdAt,
    summary: `Ticket ${t.ticketNumber} created`,
    body: null,
    eventType: "TicketCreated",
    commentType: null,
    visibility: null,
    actorUserId: t.createdByUserId,
    actorName: t.requesterName,
    actorEmail: t.requesterEmail,
    metadataJson: null,
  });
  for (const c of commentsByTicket[ticketId] ?? []) {
    items.push({
      type: "comment",
      createdAt: c.createdAt,
      summary: null,
      body: c.body,
      eventType: null,
      commentType: Object.keys({
        CustomerReply: 0,
        AgentReply: 1,
        InternalNote: 2,
        System: 3,
      })[c.commentType] ?? String(c.commentType),
      visibility: c.visibility === 0 ? "CustomerVisible" : "Internal",
      actorUserId: c.authorUserId,
      actorName: c.authorName,
      actorEmail: c.authorEmail,
      metadataJson: null,
    });
  }
  if (t.updatedAt !== t.createdAt) {
    items.push({
      type: "event",
      createdAt: t.updatedAt,
      summary: "Ticket updated",
      body: null,
      eventType: "TicketUpdated",
      commentType: null,
      visibility: null,
      actorUserId: t.updatedByUserId,
      actorName: null,
      actorEmail: null,
      metadataJson: null,
    });
  }
  if (t.resolvedAt) {
    items.push({
      type: "event",
      createdAt: t.resolvedAt,
      summary: "Ticket resolved",
      body: null,
      eventType: "TicketResolved",
      commentType: null,
      visibility: null,
      actorUserId: t.updatedByUserId,
      actorName: null,
      actorEmail: null,
      metadataJson: null,
    });
  }
  if (t.closedAt) {
    items.push({
      type: "event",
      createdAt: t.closedAt,
      summary: "Ticket closed",
      body: null,
      eventType: "TicketClosed",
      commentType: null,
      visibility: null,
      actorUserId: t.updatedByUserId,
      actorName: null,
      actorEmail: null,
      metadataJson: null,
    });
  }
  for (const evt of assignmentEventsByTicket[ticketId] ?? []) {
    items.push(evt);
  }
  // newest first
  return items.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

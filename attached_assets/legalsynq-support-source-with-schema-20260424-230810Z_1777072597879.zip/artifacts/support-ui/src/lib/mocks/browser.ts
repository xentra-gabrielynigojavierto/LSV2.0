// MSW worker bootstrap for dev/preview mode. Disabled in production builds.

import { handlers } from "./handlers";

let started = false;

export async function startMocks(): Promise<void> {
  if (started || typeof window === "undefined") return;
  // Lazy-import so production bundles don't pull MSW in.
  const { setupWorker } = await import("msw/browser");
  const worker = setupWorker(...handlers);
  await worker.start({
    serviceWorker: {
      // BASE_URL ends with a trailing slash for this artifact (path-based router).
      url: `${import.meta.env.BASE_URL}mockServiceWorker.js`,
    },
    onUnhandledRequest: "bypass",
    quiet: true,
  });
  started = true;
}

/**
 * Decide whether mocks should run. Default: on in dev, off in production.
 * Set VITE_USE_MOCKS=0 to opt out in dev (e.g. when running against a real
 * .NET backend), or VITE_USE_MOCKS=1 to force them on in production.
 */
export function shouldUseMocks(): boolean {
  const flag = import.meta.env.VITE_USE_MOCKS;
  if (flag === "1" || flag === "true") return true;
  if (flag === "0" || flag === "false") return false;
  return import.meta.env.DEV;
}

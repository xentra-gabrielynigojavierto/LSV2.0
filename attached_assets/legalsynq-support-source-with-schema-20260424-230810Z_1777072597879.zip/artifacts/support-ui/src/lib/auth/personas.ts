// Curated set of personas for the dev/preview role switcher. These map onto
// the same role strings the API enforces (see Support.Api/Auth/SupportRoles.cs)
// so policies behave identically to a real JWT once a real OIDC flow is wired up.
//
// In production this file is dead code — the session is established by the
// platform's auth shell instead.

export interface DevPersona {
  /** Stable id used as the localStorage key for the active persona. */
  id: string;
  /** Human-friendly name shown in the sidebar. */
  displayName: string;
  /** Email used as `requesterEmail` for tickets a customer persona files. */
  email: string;
  /** Short label rendered under the name in the sidebar. */
  roleLabel: string;
  /** Role claims this persona will carry. */
  roles: string[];
  /** Where the role switcher should land this persona after a swap. */
  landingPath: "/support" | "/support/portal";
  /** Avatar initials. */
  initials: string;
}

export const DEV_PERSONAS: DevPersona[] = [
  {
    id: "agent-eli",
    displayName: "Eli Marlowe",
    email: "e.marlowe@example.com",
    roleLabel: "Support Agent",
    roles: ["SupportAgent"],
    landingPath: "/support",
    initials: "EM",
  },
  {
    id: "manager-ada",
    displayName: "Ada Okafor",
    email: "a.okafor@example.com",
    roleLabel: "Support Manager",
    roles: ["SupportManager", "SupportAgent"],
    landingPath: "/support",
    initials: "AO",
  },
  {
    id: "platform-admin",
    displayName: "Priya Khanna",
    email: "p.khanna@example.com",
    roleLabel: "Platform Admin",
    roles: ["PlatformAdmin", "SupportAdmin", "SupportManager", "SupportAgent"],
    landingPath: "/support",
    initials: "PK",
  },
  {
    id: "tenant-admin-acme",
    displayName: "Sloane Whitaker",
    email: "sloane.whitaker@acmelaw.example",
    roleLabel: "Tenant Admin · Acme Law",
    roles: ["TenantAdmin", "TenantUser"],
    landingPath: "/support/portal",
    initials: "SW",
  },
  {
    id: "tenant-user-diane",
    displayName: "Diane Marchetti",
    email: "diane.marchetti@acmelaw.example",
    roleLabel: "Customer · Acme Law",
    roles: ["TenantUser"],
    landingPath: "/support/portal",
    initials: "DM",
  },
];

export const DEFAULT_PERSONA_ID = "agent-eli";

export function findPersona(id: string | null | undefined): DevPersona | null {
  if (!id) return null;
  return DEV_PERSONAS.find((p) => p.id === id) ?? null;
}

/** True if the persona has no internal-staff role. Used to choose the customer UI. */
export function isCustomerPersona(p: DevPersona): boolean {
  return !p.roles.some((r) =>
    r === "SupportAgent" ||
    r === "SupportManager" ||
    r === "SupportAdmin" ||
    r === "PlatformAdmin",
  );
}

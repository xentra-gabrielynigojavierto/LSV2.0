// In dev/preview, seed a placeholder session so the API client can attach a
// bearer token and the UI shows author/role-aware affordances. In production
// this file does nothing — a real OIDC flow is expected to populate the
// session via setSession() from the platform auth shell.
//
// The active persona id is also stored in localStorage so the role switcher
// (only rendered in dev) can swap between curated personas without rebuilding.

import { setSession } from "../api/auth";
import {
  DEFAULT_PERSONA_ID,
  DEV_PERSONAS,
  findPersona,
  type DevPersona,
} from "./personas";

const PERSONA_STORAGE_KEY = "support.dev-persona";
const PERSONA_CHANGE_EVENT = "support:dev-persona-change";

export function getActivePersonaId(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(PERSONA_STORAGE_KEY);
}

export function getActivePersona(): DevPersona {
  const id = getActivePersonaId();
  return findPersona(id) ?? findPersona(DEFAULT_PERSONA_ID) ?? DEV_PERSONAS[0]!;
}

/** Persist the persona id and seed `support.session` from it. */
export function applyPersona(persona: DevPersona): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(PERSONA_STORAGE_KEY, persona.id);
  setSession({
    token: "dev-mock-token",
    displayName: persona.displayName,
    email: persona.email,
    roles: persona.roles,
  });
  // Notify in-page listeners (the useCurrentPersona hook) so the UI can
  // re-render without a full page reload when the caller chooses to soft-swap.
  window.dispatchEvent(new CustomEvent(PERSONA_CHANGE_EVENT));
}

/** Subscribe to persona changes (used by useCurrentPersona). */
export function subscribeToPersonaChanges(listener: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const handler = () => listener();
  window.addEventListener(PERSONA_CHANGE_EVENT, handler);
  // Cross-tab updates from localStorage:
  const storageHandler = (e: StorageEvent) => {
    if (e.key === PERSONA_STORAGE_KEY || e.key === "support.session") {
      listener();
    }
  };
  window.addEventListener("storage", storageHandler);
  return () => {
    window.removeEventListener(PERSONA_CHANGE_EVENT, handler);
    window.removeEventListener("storage", storageHandler);
  };
}

export function bootstrapDevSession(): void {
  if (!import.meta.env.DEV) return;
  const persona =
    findPersona(getActivePersonaId()) ??
    findPersona(DEFAULT_PERSONA_ID) ??
    DEV_PERSONAS[0]!;
  applyPersona(persona);
}

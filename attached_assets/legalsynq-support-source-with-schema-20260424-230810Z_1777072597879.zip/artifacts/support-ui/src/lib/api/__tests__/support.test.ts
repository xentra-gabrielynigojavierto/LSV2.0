import { describe, expect, it } from "vitest";

import {
  addComment,
  createTicket,
  getTicket,
  getTimeline,
  listAttachments,
  listComments,
  listProductRefs,
  listTickets,
  updateTicket,
} from "../support";
import {
  CommentType,
  CommentVisibility,
  TicketPriority,
  TicketSource,
  TicketStatus,
} from "../types";
import { ValidationError } from "../client";

describe("support API functions (against MSW seed data)", () => {
  it("listTickets returns a paged response", async () => {
    const res = await listTickets({ pageSize: 25 });
    expect(res.items.length).toBeGreaterThan(0);
    expect(res.page).toBe(1);
    expect(res.pageSize).toBe(25);
    expect(res.total).toBeGreaterThanOrEqual(res.items.length);
  });

  it("listTickets filters by status", async () => {
    const res = await listTickets({ status: TicketStatus.Open });
    for (const t of res.items) expect(t.status).toBe(TicketStatus.Open);
  });

  it("listTickets supports a search term", async () => {
    const all = await listTickets({});
    const target = all.items[0]!;
    const res = await listTickets({ search: target.ticketNumber });
    expect(res.items.some((t) => t.id === target.id)).toBe(true);
  });

  it("getTicket returns the same record by id", async () => {
    const all = await listTickets({});
    const id = all.items[0]!.id;
    const t = await getTicket(id);
    expect(t.id).toBe(id);
  });

  it("createTicket assigns a ticket number and Open status", async () => {
    const t = await createTicket({
      title: "Cannot reset MFA after device loss",
      description: "User lost phone, MFA reset link 404s.",
      priority: TicketPriority.High,
      source: TicketSource.Portal,
    });
    expect(t.id).toBeTruthy();
    expect(t.ticketNumber).toMatch(/^SUP-\d+$/);
    expect(t.status).toBe(TicketStatus.Open);
    expect(t.priority).toBe(TicketPriority.High);
  });

  it("createTicket rejects missing titles with a ValidationError", async () => {
    await expect(
      createTicket({
        title: "",
        priority: TicketPriority.Normal,
        source: TicketSource.Portal,
      }),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("updateTicket transitions status and stamps resolvedAt", async () => {
    const created = await createTicket({
      title: "Sample for transition test",
      priority: TicketPriority.Normal,
      source: TicketSource.Portal,
    });
    const updated = await updateTicket(created.id, {
      status: TicketStatus.Resolved,
    });
    expect(updated.status).toBe(TicketStatus.Resolved);
    expect(updated.resolvedAt).not.toBeNull();
  });

  it("listComments + addComment work end-to-end", async () => {
    const created = await createTicket({
      title: "Comment thread test",
      priority: TicketPriority.Normal,
      source: TicketSource.Portal,
    });
    const before = await listComments(created.id);
    expect(before).toHaveLength(0);

    const c = await addComment(created.id, {
      body: "First reply",
      commentType: CommentType.CustomerReply,
      visibility: CommentVisibility.CustomerVisible,
    });
    expect(c.body).toBe("First reply");

    const after = await listComments(created.id);
    expect(after).toHaveLength(1);
    expect(after[0]!.id).toBe(c.id);
  });

  it("addComment rejects empty bodies with a ValidationError", async () => {
    const created = await createTicket({
      title: "Empty comment validation test",
      priority: TicketPriority.Normal,
      source: TicketSource.Portal,
    });
    await expect(addComment(created.id, { body: "" })).rejects.toBeInstanceOf(
      ValidationError,
    );
  });

  it("getTimeline includes a TicketCreated event", async () => {
    const all = await listTickets({});
    const id = all.items[0]!.id;
    const timeline = await getTimeline(id);
    expect(timeline.length).toBeGreaterThan(0);
    expect(timeline.some((i) => i.eventType === "TicketCreated")).toBe(true);
  });

  it("listAttachments + listProductRefs return arrays for the seeded tickets", async () => {
    const all = await listTickets({});
    const withAttachments = all.items.find((t) => t.ticketNumber === "SUP-1001");
    expect(withAttachments).toBeDefined();
    const att = await listAttachments(withAttachments!.id);
    expect(att.length).toBeGreaterThan(0);
    const refs = await listProductRefs(withAttachments!.id);
    expect(refs.length).toBeGreaterThan(0);
  });
});

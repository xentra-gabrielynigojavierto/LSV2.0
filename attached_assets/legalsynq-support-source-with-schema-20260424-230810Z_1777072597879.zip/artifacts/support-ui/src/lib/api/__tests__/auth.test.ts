import { afterEach, beforeEach, describe, expect, it } from "vitest";

import {
  clearSession,
  getSession,
  hasRole,
  isInternalAgent,
  setSession,
} from "../auth";

describe("session helper", () => {
  beforeEach(() => clearSession());
  afterEach(() => clearSession());

  it("round-trips a session", () => {
    setSession({
      token: "abc",
      displayName: "Pat",
      email: "pat@example.com",
      roles: ["TenantUser"],
    });
    const s = getSession();
    expect(s).not.toBeNull();
    expect(s!.token).toBe("abc");
    expect(s!.displayName).toBe("Pat");
    expect(s!.roles).toEqual(["TenantUser"]);
  });

  it("returns null when nothing is stored", () => {
    expect(getSession()).toBeNull();
  });

  it("ignores junk in localStorage", () => {
    window.localStorage.setItem("support.session", "{not json");
    expect(getSession()).toBeNull();
    window.localStorage.setItem(
      "support.session",
      JSON.stringify({ token: "" }),
    );
    expect(getSession()).toBeNull();
  });

  it("reports roles via hasRole and isInternalAgent", () => {
    setSession({
      token: "t",
      displayName: null,
      email: null,
      roles: ["SupportAgent"],
    });
    expect(hasRole("SupportAgent")).toBe(true);
    expect(hasRole("PlatformAdmin")).toBe(false);
    expect(isInternalAgent()).toBe(true);

    setSession({
      token: "t2",
      displayName: null,
      email: null,
      roles: ["TenantUser"],
    });
    expect(isInternalAgent()).toBe(false);
  });
});

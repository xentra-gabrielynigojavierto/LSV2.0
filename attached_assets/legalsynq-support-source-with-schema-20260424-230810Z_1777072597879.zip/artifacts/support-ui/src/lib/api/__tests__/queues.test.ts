import { describe, expect, it } from "vitest";

import {
  addQueueMember,
  assignTicket,
  createQueue,
  getQueue,
  listQueueMembers,
  listQueues,
  QueueMemberRole,
  removeQueueMember,
  updateQueue,
} from "../queues";
import { listTickets, getTicket, getTimeline } from "../support";
import { ApiError, ValidationError } from "../client";

describe("queues API (against MSW seed data)", () => {
  it("listQueues returns seeded queues sorted by name", async () => {
    const res = await listQueues({});
    expect(res.length).toBeGreaterThanOrEqual(4);
    const names = res.map((q) => q.name);
    const sorted = [...names].sort();
    expect(names).toEqual(sorted);
  });

  it("listQueues filters by isActive=true", async () => {
    const res = await listQueues({ isActive: true });
    for (const q of res) expect(q.isActive).toBe(true);
  });

  it("getQueue returns a single queue", async () => {
    const q = await getQueue("queue-tier2");
    expect(q.id).toBe("queue-tier2");
    expect(q.name).toMatch(/Tier 2/);
  });

  it("createQueue + duplicate name fails with 409", async () => {
    const created = await createQueue({
      name: "Queue Test " + Date.now(),
      productCode: "vault",
    });
    expect(created.id).toBeTruthy();
    expect(created.productCode).toBe("VAULT");
    await expect(createQueue({ name: created.name })).rejects.toMatchObject({
      status: 409,
    });
  });

  it("updateQueue can rename + toggle active", async () => {
    const q = await createQueue({ name: "Rename Me " + Date.now() });
    const renamed = await updateQueue(q.id, {
      name: q.name + " v2",
      isActive: false,
    });
    expect(renamed.name).toBe(q.name + " v2");
    expect(renamed.isActive).toBe(false);
  });

  it("members lifecycle: add → list → remove → re-add", async () => {
    const q = await createQueue({ name: "Member Queue " + Date.now() });
    const m = await addQueueMember(q.id, {
      userId: "user-test-1",
      role: QueueMemberRole.Lead,
    });
    expect(m.userId).toBe("user-test-1");
    expect(m.role).toBe(QueueMemberRole.Lead);

    let members = await listQueueMembers(q.id);
    expect(members.find((x) => x.id === m.id)).toBeTruthy();

    // duplicate active membership rejected
    await expect(
      addQueueMember(q.id, {
        userId: "user-test-1",
        role: QueueMemberRole.Agent,
      }),
    ).rejects.toBeInstanceOf(ApiError);

    await removeQueueMember(q.id, m.id);
    members = await listQueueMembers(q.id);
    // soft-delete: row hidden from active listing
    expect(members.find((x) => x.id === m.id && x.isActive)).toBeUndefined();

    // can re-add after soft-delete; backend reactivates the existing row
    const m2 = await addQueueMember(q.id, {
      userId: "user-test-1",
      role: QueueMemberRole.Agent,
    });
    expect(m2.id).toBe(m.id);
    expect(m2.isActive).toBe(true);
    expect(m2.role).toBe(QueueMemberRole.Agent);
  });

  it("assignTicket: assigning to a queue updates ticket and emits timeline", async () => {
    const list = await listTickets({});
    const target = list.items.find(
      (t) => t.assignedQueueId !== "queue-tier2",
    )!;
    const updated = await assignTicket(target.id, {
      assignedQueueId: "queue-tier2",
      assignedUserId: "agent-test",
    });
    expect(updated.assignedQueueId).toBe("queue-tier2");
    expect(updated.assignedUserId).toBe("agent-test");

    const fresh = await getTicket(target.id);
    expect(fresh.assignedQueueId).toBe("queue-tier2");

    const timeline = await getTimeline(target.id);
    const evt = timeline.find(
      (e) => e.type === "event" && e.eventType === "assignment_changed",
    );
    expect(evt).toBeTruthy();
    expect(evt!.metadataJson).toContain("assigned_user_id");
  });

  it("assignTicket: clearAssignment empties both fields", async () => {
    const list = await listTickets({});
    const target = list.items[0];
    await assignTicket(target.id, {
      assignedQueueId: "queue-billing",
      assignedUserId: "agent-x",
    });
    const cleared = await assignTicket(target.id, { clearAssignment: true });
    expect(cleared.assignedQueueId).toBeNull();
    expect(cleared.assignedUserId).toBeNull();
  });

  it("assignTicket: clearAssignment + explicit fields rejected (400)", async () => {
    const list = await listTickets({});
    const target = list.items[0];
    await expect(
      assignTicket(target.id, {
        clearAssignment: true,
        assignedUserId: "x",
      }),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("assignTicket: assigning to inactive queue rejected (400)", async () => {
    const list = await listTickets({});
    const target = list.items[0];
    await expect(
      assignTicket(target.id, { assignedQueueId: "queue-onboarding" }),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("listTickets supports unassigned filter", async () => {
    const list = await listTickets({});
    const target = list.items[0];
    await assignTicket(target.id, { clearAssignment: true });
    const unassigned = await listTickets({ unassigned: true });
    expect(unassigned.items.length).toBeGreaterThan(0);
    for (const t of unassigned.items) {
      expect(t.assignedUserId).toBeNull();
      expect(t.assignedQueueId).toBeNull();
    }
  });

  it("listTickets supports assignedQueueId filter", async () => {
    const list = await listTickets({});
    const target = list.items[0];
    await assignTicket(target.id, { assignedQueueId: "queue-tier2" });
    const filtered = await listTickets({ assignedQueueId: "queue-tier2" });
    for (const t of filtered.items) {
      expect(t.assignedQueueId).toBe("queue-tier2");
    }
  });
});

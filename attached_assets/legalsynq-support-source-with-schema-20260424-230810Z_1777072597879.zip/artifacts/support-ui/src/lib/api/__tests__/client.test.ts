import { describe, expect, it } from "vitest";
import { http, HttpResponse } from "msw";

import { server } from "../../../test/setup";
import {
  ApiError,
  ForbiddenError,
  NetworkError,
  NotFoundError,
  request,
  UnauthorizedError,
  ValidationError,
} from "../client";

describe("api client", () => {
  it("attaches a Bearer token from session storage", async () => {
    let received: string | null = null;
    server.use(
      http.get("/support/api/_probe", ({ request: req }) => {
        received = req.headers.get("authorization");
        return HttpResponse.json({ ok: true });
      }),
    );
    await request<{ ok: boolean }>("/_probe");
    expect(received).toBe("Bearer test-token");
  });

  it("surfaces 401 as UnauthorizedError", async () => {
    server.use(
      http.get("/support/api/tickets", () =>
        new HttpResponse(null, { status: 401 }),
      ),
    );
    await expect(request("/tickets")).rejects.toBeInstanceOf(UnauthorizedError);
  });

  it("surfaces 403 as ForbiddenError, distinct from 401", async () => {
    server.use(
      http.get("/support/api/tickets", () =>
        new HttpResponse(null, { status: 403 }),
      ),
    );
    let caught: unknown;
    try {
      await request("/tickets");
    } catch (e) {
      caught = e;
    }
    expect(caught).toBeInstanceOf(ForbiddenError);
    expect(caught).not.toBeInstanceOf(UnauthorizedError);
  });

  it("surfaces 404 as NotFoundError", async () => {
    server.use(
      http.get("/support/api/tickets/missing", () =>
        new HttpResponse(null, { status: 404 }),
      ),
    );
    await expect(request("/tickets/missing")).rejects.toBeInstanceOf(
      NotFoundError,
    );
  });

  it("parses RFC 7807 problem+json validation errors", async () => {
    server.use(
      http.post("/support/api/tickets", () =>
        HttpResponse.json(
          {
            title: "One or more validation errors occurred.",
            status: 400,
            errors: { Title: ["Title is required."] },
          },
          { status: 400 },
        ),
      ),
    );
    let caught: unknown;
    try {
      await request("/tickets", {
        method: "POST",
        body: { title: "" },
      });
    } catch (e) {
      caught = e;
    }
    expect(caught).toBeInstanceOf(ValidationError);
    const v = caught as ValidationError;
    expect(v.errors.Title).toContain("Title is required.");
    expect(v.message).toBe("One or more validation errors occurred.");
  });

  it("wraps network failures as NetworkError", async () => {
    server.use(
      http.get("/support/api/boom", () => HttpResponse.error()),
    );
    await expect(request("/boom")).rejects.toBeInstanceOf(NetworkError);
  });

  it("treats unexpected 5xx responses as ApiError", async () => {
    server.use(
      http.get("/support/api/boom", () =>
        HttpResponse.json({ title: "Database unreachable" }, { status: 503 }),
      ),
    );
    let caught: unknown;
    try {
      await request("/boom");
    } catch (e) {
      caught = e;
    }
    expect(caught).toBeInstanceOf(ApiError);
    const a = caught as ApiError;
    expect(a.status).toBe(503);
    expect(a.message).toBe("Database unreachable");
  });
});

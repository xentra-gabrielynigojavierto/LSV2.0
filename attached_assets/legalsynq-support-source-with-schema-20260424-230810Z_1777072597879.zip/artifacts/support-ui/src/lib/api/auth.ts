// Auth/session helper for the Support UI.
//
// In production, this token will be issued by the platform's identity provider
// (OIDC) and injected into the SPA via the existing portal auth flow. SUP-B05
// is the first UI block — there is no portal auth shell yet — so for now the
// token is read from localStorage. A dev-mode bootstrap (see lib/auth/devSession.ts)
// seeds a placeholder token + roles so the UI can be exercised end-to-end.

const STORAGE_KEY = "support.session";

export interface SupportSession {
  /** Bearer token. In dev/preview this is a placeholder; in prod, a real JWT. */
  token: string;
  /** Display name for the current user, used in author fields on new comments. */
  displayName: string | null;
  /** Email for the current user. */
  email: string | null;
  /** Roles claimed by the JWT (e.g. SupportAgent, TenantUser). Used to gate UI affordances. */
  roles: string[];
}

export function getSession(): SupportSession | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<SupportSession>;
    if (typeof parsed.token !== "string" || parsed.token.length === 0)
      return null;
    return {
      token: parsed.token,
      displayName: parsed.displayName ?? null,
      email: parsed.email ?? null,
      roles: Array.isArray(parsed.roles) ? parsed.roles : [],
    };
  } catch {
    return null;
  }
}

export function setSession(session: SupportSession): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
}

export function clearSession(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(STORAGE_KEY);
}

export function hasRole(role: string): boolean {
  const s = getSession();
  return s?.roles.includes(role) ?? false;
}

export function isInternalAgent(): boolean {
  return (
    hasRole("SupportAgent") ||
    hasRole("SupportManager") ||
    hasRole("PlatformAdmin")
  );
}

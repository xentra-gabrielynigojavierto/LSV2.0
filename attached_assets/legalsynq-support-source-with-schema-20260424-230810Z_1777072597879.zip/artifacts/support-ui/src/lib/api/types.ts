// Mirror of the .NET DTO contracts in services/support/Support.Api/Dtos/.
// Enums are numeric on the wire (System.Text.Json default — see SUP-B04 60/60 tests).

export const TicketStatus = {
  Open: 0,
  Pending: 1,
  InProgress: 2,
  Resolved: 3,
  Closed: 4,
  Cancelled: 5,
} as const;
export type TicketStatus = (typeof TicketStatus)[keyof typeof TicketStatus];

export const TicketPriority = {
  Low: 0,
  Normal: 1,
  High: 2,
  Urgent: 3,
} as const;
export type TicketPriority = (typeof TicketPriority)[keyof typeof TicketPriority];

export const TicketSeverity = {
  Sev4: 0,
  Sev3: 1,
  Sev2: 2,
  Sev1: 3,
} as const;
export type TicketSeverity = (typeof TicketSeverity)[keyof typeof TicketSeverity];

export const TicketSource = {
  Portal: 0,
  Email: 1,
  Chat: 2,
  Phone: 3,
  Monitoring: 4,
  External: 5,
} as const;
export type TicketSource = (typeof TicketSource)[keyof typeof TicketSource];

// IMPORTANT: numeric values mirror services/support/.../Domain/SupportTicketComment.cs
// (System.Text.Json default — alphabetic-by-declaration ordinal).
export const CommentType = {
  InternalNote: 0,
  CustomerReply: 1,
  SystemNote: 2,
} as const;
export type CommentType = (typeof CommentType)[keyof typeof CommentType];

// IMPORTANT: Internal=0, CustomerVisible=1 — matches the .NET backend exactly.
// Inverting these would cause internal notes to leak to customers (or vice versa).
export const CommentVisibility = {
  Internal: 0,
  CustomerVisible: 1,
} as const;
export type CommentVisibility =
  (typeof CommentVisibility)[keyof typeof CommentVisibility];

export interface Ticket {
  id: string;
  tenantId: string;
  productCode: string | null;
  ticketNumber: string;
  title: string;
  description: string | null;
  status: TicketStatus;
  priority: TicketPriority;
  severity: TicketSeverity | null;
  category: string | null;
  source: TicketSource;
  requesterUserId: string | null;
  requesterName: string | null;
  requesterEmail: string | null;
  assignedUserId: string | null;
  assignedQueueId: string | null;
  dueAt: string | null;
  resolvedAt: string | null;
  closedAt: string | null;
  createdAt: string;
  updatedAt: string;
  createdByUserId: string | null;
  updatedByUserId: string | null;
}

export interface CreateTicketRequest {
  productCode?: string | null;
  title: string;
  description?: string | null;
  priority: TicketPriority;
  severity?: TicketSeverity | null;
  category?: string | null;
  source: TicketSource;
  requesterUserId?: string | null;
  requesterName?: string | null;
  requesterEmail?: string | null;
}

export interface UpdateTicketRequest {
  title?: string | null;
  description?: string | null;
  status?: TicketStatus | null;
  priority?: TicketPriority | null;
  severity?: TicketSeverity | null;
  category?: string | null;
  assignedUserId?: string | null;
  assignedQueueId?: string | null;
  dueAt?: string | null;
  requesterName?: string | null;
  requesterEmail?: string | null;
}

export interface PagedResponse<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
}

export interface TicketListFilters {
  status?: TicketStatus;
  priority?: TicketPriority;
  severity?: TicketSeverity;
  source?: TicketSource;
  productCode?: string;
  category?: string;
  search?: string;
  assignedUserId?: string;
  assignedQueueId?: string;
  unassigned?: boolean;
  page?: number;
  pageSize?: number;
}

export interface Comment {
  id: string;
  ticketId: string;
  commentType: CommentType;
  visibility: CommentVisibility;
  body: string;
  authorUserId: string | null;
  authorName: string | null;
  authorEmail: string | null;
  createdAt: string;
}

export interface CreateCommentRequest {
  body: string;
  commentType?: CommentType | null;
  visibility?: CommentVisibility | null;
  authorUserId?: string | null;
  authorName?: string | null;
  authorEmail?: string | null;
}

export interface TimelineItem {
  type: "comment" | "event";
  createdAt: string;
  summary: string | null;
  body: string | null;
  eventType: string | null;
  commentType: string | null;
  visibility: string | null;
  actorUserId: string | null;
  actorName: string | null;
  actorEmail: string | null;
  metadataJson: string | null;
}

export interface TicketAttachment {
  id: string;
  ticketId: string;
  documentId: string;
  fileName: string;
  contentType: string | null;
  fileSizeBytes: number | null;
  uploadedByUserId: string | null;
  createdAt: string;
}

export interface ProductReference {
  id: string;
  ticketId: string;
  productCode: string;
  entityType: string;
  entityId: string;
  displayLabel: string | null;
  metadataJson: string | null;
  createdByUserId: string | null;
  createdAt: string;
}

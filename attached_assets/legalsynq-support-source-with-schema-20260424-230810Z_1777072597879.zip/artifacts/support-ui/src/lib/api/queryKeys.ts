import type { TicketListFilters } from "./types";
import type { QueueListFilters } from "./queues";

export const ticketsListKey = (filters: TicketListFilters) =>
  ["support", "tickets", "list", filters] as const;

export const ticketKey = (id: string) =>
  ["support", "tickets", id] as const;

export const ticketCommentsKey = (id: string) =>
  ["support", "tickets", id, "comments"] as const;

export const ticketTimelineKey = (id: string) =>
  ["support", "tickets", id, "timeline"] as const;

export const ticketAttachmentsKey = (id: string) =>
  ["support", "tickets", id, "attachments"] as const;

export const ticketProductRefsKey = (id: string) =>
  ["support", "tickets", id, "product-refs"] as const;

export const queuesListKey = (filters: QueueListFilters = {}) =>
  ["support", "queues", "list", filters] as const;

export const queueKey = (id: string) =>
  ["support", "queues", id] as const;

export const queueMembersKey = (id: string) =>
  ["support", "queues", id, "members"] as const;

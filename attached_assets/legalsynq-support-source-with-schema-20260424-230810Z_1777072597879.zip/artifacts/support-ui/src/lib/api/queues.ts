import { request } from "./client";

export const QueueMemberRole = {
  Agent: 0,
  Lead: 1,
  Manager: 2,
} as const;
export type QueueMemberRole =
  (typeof QueueMemberRole)[keyof typeof QueueMemberRole];

export interface SupportQueue {
  id: string;
  tenantId: string;
  name: string;
  description: string | null;
  productCode: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  createdByUserId: string | null;
  updatedByUserId: string | null;
}

export interface SupportQueueMember {
  id: string;
  queueId: string;
  tenantId: string;
  userId: string;
  role: QueueMemberRole;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateQueueRequest {
  name: string;
  description?: string | null;
  productCode?: string | null;
  isActive?: boolean | null;
}

export interface UpdateQueueRequest {
  name?: string | null;
  description?: string | null;
  productCode?: string | null;
  isActive?: boolean | null;
}

export interface AddQueueMemberRequest {
  userId: string;
  role: QueueMemberRole;
  isActive?: boolean | null;
}

export interface AssignTicketRequest {
  assignedUserId?: string | null;
  assignedQueueId?: string | null;
  clearAssignment?: boolean;
}

export interface QueueListFilters {
  productCode?: string;
  isActive?: boolean;
  search?: string;
}

import type { Ticket } from "./types";

export function listQueues(
  filters: QueueListFilters = {},
  signal?: AbortSignal,
): Promise<SupportQueue[]> {
  return request<SupportQueue[]>("/queues", {
    query: filters as Record<string, string | number | boolean | null | undefined>,
    signal,
  });
}

export function getQueue(
  queueId: string,
  signal?: AbortSignal,
): Promise<SupportQueue> {
  return request<SupportQueue>(`/queues/${queueId}`, { signal });
}

export function createQueue(
  payload: CreateQueueRequest,
): Promise<SupportQueue> {
  return request<SupportQueue>("/queues", { method: "POST", body: payload });
}

export function updateQueue(
  queueId: string,
  payload: UpdateQueueRequest,
): Promise<SupportQueue> {
  return request<SupportQueue>(`/queues/${queueId}`, {
    method: "PUT",
    body: payload,
  });
}

export function listQueueMembers(
  queueId: string,
  signal?: AbortSignal,
): Promise<SupportQueueMember[]> {
  return request<SupportQueueMember[]>(`/queues/${queueId}/members`, { signal });
}

export function addQueueMember(
  queueId: string,
  payload: AddQueueMemberRequest,
): Promise<SupportQueueMember> {
  return request<SupportQueueMember>(`/queues/${queueId}/members`, {
    method: "POST",
    body: payload,
  });
}

export function removeQueueMember(
  queueId: string,
  memberId: string,
): Promise<void> {
  return request<void>(`/queues/${queueId}/members/${memberId}`, {
    method: "DELETE",
  });
}

export function assignTicket(
  ticketId: string,
  payload: AssignTicketRequest,
): Promise<Ticket> {
  return request<Ticket>(`/tickets/${ticketId}/assignment`, {
    method: "PUT",
    body: payload,
  });
}

export const queueMemberRoleLabel: Record<QueueMemberRole, string> = {
  [QueueMemberRole.Agent]: "Agent",
  [QueueMemberRole.Lead]: "Lead",
  [QueueMemberRole.Manager]: "Manager",
};

export const queueMemberRoleOptions = (
  Object.entries(queueMemberRoleLabel) as [string, string][]
).map(([value, label]) => ({
  value: Number(value) as QueueMemberRole,
  label,
}));

import {
  CommentType,
  CommentVisibility,
  TicketPriority,
  TicketSeverity,
  TicketSource,
  TicketStatus,
} from "./types";

export const ticketStatusLabel: Record<TicketStatus, string> = {
  [TicketStatus.Open]: "Open",
  [TicketStatus.Pending]: "Pending",
  [TicketStatus.InProgress]: "In progress",
  [TicketStatus.Resolved]: "Resolved",
  [TicketStatus.Closed]: "Closed",
  [TicketStatus.Cancelled]: "Cancelled",
};

export const ticketPriorityLabel: Record<TicketPriority, string> = {
  [TicketPriority.Low]: "Low",
  [TicketPriority.Normal]: "Normal",
  [TicketPriority.High]: "High",
  [TicketPriority.Urgent]: "Urgent",
};

export const ticketSeverityLabel: Record<TicketSeverity, string> = {
  [TicketSeverity.Sev4]: "Sev4",
  [TicketSeverity.Sev3]: "Sev3",
  [TicketSeverity.Sev2]: "Sev2",
  [TicketSeverity.Sev1]: "Sev1",
};

export const ticketSourceLabel: Record<TicketSource, string> = {
  [TicketSource.Portal]: "Portal",
  [TicketSource.Email]: "Email",
  [TicketSource.Chat]: "Chat",
  [TicketSource.Phone]: "Phone",
  [TicketSource.Monitoring]: "Monitoring",
  [TicketSource.External]: "External",
};

export const commentTypeLabel: Record<CommentType, string> = {
  [CommentType.InternalNote]: "Internal note",
  [CommentType.CustomerReply]: "Reply",
  [CommentType.SystemNote]: "System",
};

export const commentVisibilityLabel: Record<CommentVisibility, string> = {
  [CommentVisibility.Internal]: "Internal",
  [CommentVisibility.CustomerVisible]: "Customer visible",
};

export const ticketStatusOptions = (
  Object.entries(ticketStatusLabel) as [string, string][]
).map(([value, label]) => ({ value: Number(value) as TicketStatus, label }));

export const ticketPriorityOptions = (
  Object.entries(ticketPriorityLabel) as [string, string][]
).map(([value, label]) => ({ value: Number(value) as TicketPriority, label }));

export const ticketSeverityOptions = (
  Object.entries(ticketSeverityLabel) as [string, string][]
).map(([value, label]) => ({ value: Number(value) as TicketSeverity, label }));

export const ticketSourceOptions = (
  Object.entries(ticketSourceLabel) as [string, string][]
).map(([value, label]) => ({ value: Number(value) as TicketSource, label }));

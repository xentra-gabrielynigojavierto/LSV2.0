// Authenticated fetch wrapper for the Support API.
//
// - Always attaches `Authorization: Bearer <token>` from the session store.
// - Surfaces 401/403/404/400 as distinct typed errors so the UI can react.
// - Parses RFC 7807 problem+json bodies for validation errors.
// - Does NOT send X-Tenant-Id; tenant is resolved from the JWT in production
//   (see SUP-B04). Dev-mode mocks ignore tenancy.

import { getSession } from "./auth";

const DEFAULT_BASE_URL = "/support/api";

/** Override via VITE_SUPPORT_API_BASE_URL if the API is hosted elsewhere. */
export const API_BASE_URL: string =
  (import.meta.env.VITE_SUPPORT_API_BASE_URL as string | undefined) ??
  DEFAULT_BASE_URL;

export class ApiError extends Error {
  status: number;
  body: unknown;
  constructor(message: string, status: number, body: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.body = body;
  }
}

export class UnauthorizedError extends ApiError {
  constructor(body: unknown) {
    super("You are not signed in.", 401, body);
    this.name = "UnauthorizedError";
  }
}

export class ForbiddenError extends ApiError {
  constructor(body: unknown) {
    super(
      "You don't have permission to perform this action.",
      403,
      body,
    );
    this.name = "ForbiddenError";
  }
}

export class NotFoundError extends ApiError {
  constructor(body: unknown) {
    super("Not found.", 404, body);
    this.name = "NotFoundError";
  }
}

/**
 * Validation/business-rule failure (400). `errors` is the RFC 7807
 * `errors` map when present, e.g. `{ Title: ["Title is required"] }`.
 */
export class ValidationError extends ApiError {
  errors: Record<string, string[]>;
  constructor(message: string, body: unknown, errors: Record<string, string[]>) {
    super(message, 400, body);
    this.name = "ValidationError";
    this.errors = errors;
  }
}

export class NetworkError extends Error {
  cause?: unknown;
  constructor(message: string, cause?: unknown) {
    super(message);
    this.name = "NetworkError";
    this.cause = cause;
  }
}

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  query?: Record<string, string | number | boolean | undefined | null>;
  body?: unknown;
  signal?: AbortSignal;
}

function buildUrl(
  path: string,
  query?: RequestOptions["query"],
): string {
  let url = `${API_BASE_URL}${path}`;
  if (query) {
    const sp = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) {
      if (value === undefined || value === null || value === "") continue;
      sp.append(key, String(value));
    }
    const qs = sp.toString();
    if (qs) url += `?${qs}`;
  }
  return url;
}

function buildHeaders(hasBody: boolean): HeadersInit {
  const headers: Record<string, string> = {
    Accept: "application/json",
  };
  if (hasBody) headers["Content-Type"] = "application/json";
  const session = getSession();
  if (session?.token) {
    headers["Authorization"] = `Bearer ${session.token}`;
  }
  return headers;
}

async function parseProblem(res: Response): Promise<unknown> {
  const text = await res.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function extractValidationErrors(body: unknown): Record<string, string[]> {
  if (
    body &&
    typeof body === "object" &&
    "errors" in body &&
    body.errors &&
    typeof body.errors === "object"
  ) {
    const out: Record<string, string[]> = {};
    for (const [k, v] of Object.entries(body.errors as Record<string, unknown>)) {
      if (Array.isArray(v)) out[k] = v.map(String);
      else if (typeof v === "string") out[k] = [v];
    }
    return out;
  }
  return {};
}

function extractMessage(body: unknown, fallback: string): string {
  if (body && typeof body === "object") {
    const b = body as Record<string, unknown>;
    if (typeof b.title === "string") return b.title;
    if (typeof b.detail === "string") return b.detail;
    if (typeof b.error === "string") return b.error;
    if (typeof b.message === "string") return b.message;
  }
  return fallback;
}

/**
 * Multipart upload helper. The browser must set the multipart boundary in the
 * Content-Type header itself, so we deliberately do NOT pass a Content-Type —
 * `fetch` will derive it from the FormData. Auth + error handling mirror
 * <see cref="request"/> so callers get the same typed error surface
 * (Validation/Unauthorized/Forbidden/NotFound/ApiError).
 */
export async function uploadMultipart<T>(
  path: string,
  form: FormData,
  options: { signal?: AbortSignal } = {},
): Promise<T> {
  const url = buildUrl(path);
  const headers: Record<string, string> = { Accept: "application/json" };
  const session = getSession();
  if (session?.token) headers["Authorization"] = `Bearer ${session.token}`;

  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers,
      body: form,
      signal: options.signal,
    });
  } catch (err) {
    throw new NetworkError(
      "Network error — could not reach the Support service.",
      err,
    );
  }

  if (res.ok) {
    const text = await res.text();
    if (!text) return undefined as T;
    try {
      return JSON.parse(text) as T;
    } catch (err) {
      throw new ApiError("Server returned malformed JSON.", res.status, err);
    }
  }

  const problem = await parseProblem(res);
  switch (res.status) {
    case 401:
      throw new UnauthorizedError(problem);
    case 403:
      throw new ForbiddenError(problem);
    case 404:
      throw new NotFoundError(problem);
    case 400:
    case 422:
      throw new ValidationError(
        extractMessage(problem, "The upload was invalid."),
        problem,
        extractValidationErrors(problem),
      );
    default:
      throw new ApiError(
        extractMessage(problem, `Upload failed with ${res.status}.`),
        res.status,
        problem,
      );
  }
}

export async function request<T>(
  path: string,
  options: RequestOptions = {},
): Promise<T> {
  const { method = "GET", query, body, signal } = options;
  const url = buildUrl(path, query);
  const init: RequestInit = {
    method,
    headers: buildHeaders(body !== undefined),
    signal,
  };
  if (body !== undefined) init.body = JSON.stringify(body);

  let res: Response;
  try {
    res = await fetch(url, init);
  } catch (err) {
    throw new NetworkError(
      "Network error — could not reach the Support service.",
      err,
    );
  }

  if (res.status === 204) {
    return undefined as T;
  }

  if (res.ok) {
    const text = await res.text();
    if (!text) return undefined as T;
    try {
      return JSON.parse(text) as T;
    } catch (err) {
      throw new ApiError("Server returned malformed JSON.", res.status, err);
    }
  }

  const problem = await parseProblem(res);
  switch (res.status) {
    case 401:
      throw new UnauthorizedError(problem);
    case 403:
      throw new ForbiddenError(problem);
    case 404:
      throw new NotFoundError(problem);
    case 400:
    case 422:
      throw new ValidationError(
        extractMessage(problem, "The request was invalid."),
        problem,
        extractValidationErrors(problem),
      );
    default:
      throw new ApiError(
        extractMessage(problem, `Request failed with ${res.status}.`),
        res.status,
        problem,
      );
  }
}

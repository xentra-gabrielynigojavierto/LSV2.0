import {
  useMutation,
  useQuery,
  useQueryClient,
  type UseMutationOptions,
  type UseQueryOptions,
} from "@tanstack/react-query";

import * as api from "./support";
import * as queuesApi from "./queues";
import {
  queueKey,
  queueMembersKey,
  queuesListKey,
  ticketAttachmentsKey,
  ticketCommentsKey,
  ticketKey,
  ticketProductRefsKey,
  ticketTimelineKey,
  ticketsListKey,
} from "./queryKeys";
import type {
  Comment,
  CreateCommentRequest,
  CreateTicketRequest,
  PagedResponse,
  ProductReference,
  Ticket,
  TicketAttachment,
  TicketListFilters,
  TimelineItem,
  UpdateTicketRequest,
} from "./types";
import type {
  AddQueueMemberRequest,
  AssignTicketRequest,
  CreateQueueRequest,
  QueueListFilters,
  SupportQueue,
  SupportQueueMember,
  UpdateQueueRequest,
} from "./queues";

export function useTicketList(
  filters: TicketListFilters = {},
  options?: Omit<
    UseQueryOptions<PagedResponse<Ticket>>,
    "queryKey" | "queryFn"
  >,
) {
  return useQuery<PagedResponse<Ticket>>({
    queryKey: ticketsListKey(filters),
    queryFn: ({ signal }) => api.listTickets(filters, signal),
    ...options,
  });
}

export function useTicket(
  id: string | undefined,
  options?: Omit<UseQueryOptions<Ticket>, "queryKey" | "queryFn" | "enabled">,
) {
  return useQuery<Ticket>({
    queryKey: ticketKey(id ?? ""),
    queryFn: ({ signal }) => api.getTicket(id as string, signal),
    enabled: !!id,
    ...options,
  });
}

export function useTicketComments(
  id: string | undefined,
  options?: Omit<UseQueryOptions<Comment[]>, "queryKey" | "queryFn" | "enabled">,
) {
  return useQuery<Comment[]>({
    queryKey: ticketCommentsKey(id ?? ""),
    queryFn: ({ signal }) => api.listComments(id as string, signal),
    enabled: !!id,
    ...options,
  });
}

export function useTicketTimeline(
  id: string | undefined,
  options?: Omit<
    UseQueryOptions<TimelineItem[]>,
    "queryKey" | "queryFn" | "enabled"
  >,
) {
  return useQuery<TimelineItem[]>({
    queryKey: ticketTimelineKey(id ?? ""),
    queryFn: ({ signal }) => api.getTimeline(id as string, signal),
    enabled: !!id,
    ...options,
  });
}

export function useTicketAttachments(
  id: string | undefined,
  options?: Omit<
    UseQueryOptions<TicketAttachment[]>,
    "queryKey" | "queryFn" | "enabled"
  >,
) {
  return useQuery<TicketAttachment[]>({
    queryKey: ticketAttachmentsKey(id ?? ""),
    queryFn: ({ signal }) => api.listAttachments(id as string, signal),
    enabled: !!id,
    ...options,
  });
}

export function useTicketProductRefs(
  id: string | undefined,
  options?: Omit<
    UseQueryOptions<ProductReference[]>,
    "queryKey" | "queryFn" | "enabled"
  >,
) {
  return useQuery<ProductReference[]>({
    queryKey: ticketProductRefsKey(id ?? ""),
    queryFn: ({ signal }) => api.listProductRefs(id as string, signal),
    enabled: !!id,
    ...options,
  });
}

export function useCreateTicket(
  options?: UseMutationOptions<Ticket, Error, CreateTicketRequest>,
) {
  const qc = useQueryClient();
  return useMutation<Ticket, Error, CreateTicketRequest>({
    mutationFn: (payload) => api.createTicket(payload),
    ...options,
    onSuccess: (...args) => {
      qc.invalidateQueries({ queryKey: ["support", "tickets", "list"] });

      return options?.onSuccess?.(...args);
    },
  });
}

export function useUpdateTicket(
  id: string,
  options?: UseMutationOptions<Ticket, Error, UpdateTicketRequest>,
) {
  const qc = useQueryClient();
  return useMutation<Ticket, Error, UpdateTicketRequest>({
    mutationFn: (payload) => api.updateTicket(id, payload),
    ...options,
    onSuccess: (...args) => {
      const [data] = args;
      qc.setQueryData(ticketKey(id), data);
      qc.invalidateQueries({ queryKey: ["support", "tickets", "list"] });
      qc.invalidateQueries({ queryKey: ticketTimelineKey(id) });

      return options?.onSuccess?.(...args);
    },
  });
}

export function useUploadAttachment(
  ticketId: string,
  options?: UseMutationOptions<
    TicketAttachment,
    Error,
    { file: File; displayName?: string }
  >,
) {
  const qc = useQueryClient();
  return useMutation<
    TicketAttachment,
    Error,
    { file: File; displayName?: string }
  >({
    mutationFn: ({ file, displayName }) =>
      api.uploadAttachment(ticketId, file, { displayName }),
    ...options,
    onSuccess: (...args) => {
      qc.invalidateQueries({ queryKey: ticketAttachmentsKey(ticketId) });
      qc.invalidateQueries({ queryKey: ticketTimelineKey(ticketId) });
      qc.invalidateQueries({ queryKey: ticketKey(ticketId) });
      return options?.onSuccess?.(...args);
    },
  });
}

export function useAddComment(
  ticketId: string,
  options?: UseMutationOptions<Comment, Error, CreateCommentRequest>,
) {
  const qc = useQueryClient();
  return useMutation<Comment, Error, CreateCommentRequest>({
    mutationFn: (payload) => api.addComment(ticketId, payload),
    ...options,
    onSuccess: (...args) => {
      qc.invalidateQueries({ queryKey: ticketCommentsKey(ticketId) });
      qc.invalidateQueries({ queryKey: ticketTimelineKey(ticketId) });

      return options?.onSuccess?.(...args);
    },
  });
}

// --- Queues ---

export function useQueues(
  filters: QueueListFilters = {},
  options?: Omit<UseQueryOptions<SupportQueue[]>, "queryKey" | "queryFn">,
) {
  return useQuery<SupportQueue[]>({
    queryKey: queuesListKey(filters),
    queryFn: ({ signal }) => queuesApi.listQueues(filters, signal),
    ...options,
  });
}

export function useQueue(
  id: string | undefined,
  options?: Omit<
    UseQueryOptions<SupportQueue>,
    "queryKey" | "queryFn" | "enabled"
  >,
) {
  return useQuery<SupportQueue>({
    queryKey: queueKey(id ?? ""),
    queryFn: ({ signal }) => queuesApi.getQueue(id as string, signal),
    enabled: !!id,
    ...options,
  });
}

export function useQueueMembers(
  id: string | undefined,
  options?: Omit<
    UseQueryOptions<SupportQueueMember[]>,
    "queryKey" | "queryFn" | "enabled"
  >,
) {
  return useQuery<SupportQueueMember[]>({
    queryKey: queueMembersKey(id ?? ""),
    queryFn: ({ signal }) => queuesApi.listQueueMembers(id as string, signal),
    enabled: !!id,
    ...options,
  });
}

export function useCreateQueue(
  options?: UseMutationOptions<SupportQueue, Error, CreateQueueRequest>,
) {
  const qc = useQueryClient();
  return useMutation<SupportQueue, Error, CreateQueueRequest>({
    mutationFn: (payload) => queuesApi.createQueue(payload),
    ...options,
    onSuccess: (...args) => {
      qc.invalidateQueries({ queryKey: ["support", "queues", "list"] });
      return options?.onSuccess?.(...args);
    },
  });
}

export function useUpdateQueue(
  id: string,
  options?: UseMutationOptions<SupportQueue, Error, UpdateQueueRequest>,
) {
  const qc = useQueryClient();
  return useMutation<SupportQueue, Error, UpdateQueueRequest>({
    mutationFn: (payload) => queuesApi.updateQueue(id, payload),
    ...options,
    onSuccess: (...args) => {
      const [data] = args;
      qc.setQueryData(queueKey(id), data);
      qc.invalidateQueries({ queryKey: ["support", "queues", "list"] });
      return options?.onSuccess?.(...args);
    },
  });
}

export function useAddQueueMember(
  queueId: string,
  options?: UseMutationOptions<
    SupportQueueMember,
    Error,
    AddQueueMemberRequest
  >,
) {
  const qc = useQueryClient();
  return useMutation<SupportQueueMember, Error, AddQueueMemberRequest>({
    mutationFn: (payload) => queuesApi.addQueueMember(queueId, payload),
    ...options,
    onSuccess: (...args) => {
      qc.invalidateQueries({ queryKey: queueMembersKey(queueId) });
      return options?.onSuccess?.(...args);
    },
  });
}

export function useRemoveQueueMember(
  queueId: string,
  options?: UseMutationOptions<void, Error, string>,
) {
  const qc = useQueryClient();
  return useMutation<void, Error, string>({
    mutationFn: (memberId) => queuesApi.removeQueueMember(queueId, memberId),
    ...options,
    onSuccess: (...args) => {
      qc.invalidateQueries({ queryKey: queueMembersKey(queueId) });
      return options?.onSuccess?.(...args);
    },
  });
}

export function useAssignTicket(
  ticketId: string,
  options?: UseMutationOptions<Ticket, Error, AssignTicketRequest>,
) {
  const qc = useQueryClient();
  return useMutation<Ticket, Error, AssignTicketRequest>({
    mutationFn: (payload) => queuesApi.assignTicket(ticketId, payload),
    ...options,
    onSuccess: (...args) => {
      const [data] = args;
      qc.setQueryData(ticketKey(ticketId), data);
      qc.invalidateQueries({ queryKey: ["support", "tickets", "list"] });
      qc.invalidateQueries({ queryKey: ticketTimelineKey(ticketId) });
      return options?.onSuccess?.(...args);
    },
  });
}

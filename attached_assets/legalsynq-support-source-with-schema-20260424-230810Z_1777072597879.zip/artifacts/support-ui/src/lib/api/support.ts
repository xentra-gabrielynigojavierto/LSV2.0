// Support API client functions — one per spec endpoint.

import { request, uploadMultipart } from "./client";
import type {
  Comment,
  CreateCommentRequest,
  CreateTicketRequest,
  PagedResponse,
  ProductReference,
  Ticket,
  TicketAttachment,
  TicketListFilters,
  TimelineItem,
  UpdateTicketRequest,
} from "./types";

export function listTickets(
  filters: TicketListFilters = {},
  signal?: AbortSignal,
): Promise<PagedResponse<Ticket>> {
  return request<PagedResponse<Ticket>>("/tickets", {
    query: filters as Record<string, string | number | boolean | null | undefined>,
    signal,
  });
}

export function getTicket(id: string, signal?: AbortSignal): Promise<Ticket> {
  return request<Ticket>(`/tickets/${id}`, { signal });
}

export function createTicket(payload: CreateTicketRequest): Promise<Ticket> {
  return request<Ticket>("/tickets", { method: "POST", body: payload });
}

export function updateTicket(
  id: string,
  payload: UpdateTicketRequest,
): Promise<Ticket> {
  return request<Ticket>(`/tickets/${id}`, { method: "PUT", body: payload });
}

export function listComments(
  ticketId: string,
  signal?: AbortSignal,
): Promise<Comment[]> {
  return request<Comment[]>(`/tickets/${ticketId}/comments`, { signal });
}

export function addComment(
  ticketId: string,
  payload: CreateCommentRequest,
): Promise<Comment> {
  return request<Comment>(`/tickets/${ticketId}/comments`, {
    method: "POST",
    body: payload,
  });
}

export function getTimeline(
  ticketId: string,
  signal?: AbortSignal,
): Promise<TimelineItem[]> {
  return request<TimelineItem[]>(`/tickets/${ticketId}/timeline`, { signal });
}

export function listAttachments(
  ticketId: string,
  signal?: AbortSignal,
): Promise<TicketAttachment[]> {
  return request<TicketAttachment[]>(`/tickets/${ticketId}/attachments`, {
    signal,
  });
}

export interface UploadAttachmentOptions {
  /** Optional override for the stored file name. Defaults to file.name. */
  displayName?: string;
  signal?: AbortSignal;
}

/**
 * Multipart upload to the Support upload endpoint (SUP-INT-08). The selected
 * file is streamed to the configured storage provider (Local or
 * DocumentsService) and an attachment row is created on success.
 *
 * Uploader identity is derived server-side from the JWT subject; the client
 * cannot supply it (any `uploaded_by_user_id` form field would be ignored).
 */
export function uploadAttachment(
  ticketId: string,
  file: File,
  options: UploadAttachmentOptions = {},
): Promise<TicketAttachment> {
  const form = new FormData();
  form.append("file", file, file.name);
  if (options.displayName) form.append("display_name", options.displayName);
  return uploadMultipart<TicketAttachment>(
    `/tickets/${ticketId}/attachments/upload`,
    form,
    { signal: options.signal },
  );
}

export function listProductRefs(
  ticketId: string,
  signal?: AbortSignal,
): Promise<ProductReference[]> {
  return request<ProductReference[]>(`/tickets/${ticketId}/product-refs`, {
    signal,
  });
}

import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppShell } from "@/components/layout/AppShell";
import NotFound from "@/pages/not-found";
import TicketList from "@/pages/TicketList";
import TicketCreate from "@/pages/TicketCreate";
import TicketDetail from "@/pages/TicketDetail";
import Queues from "@/pages/Queues";
import PortalMyTickets from "@/pages/portal/MyTickets";
import PortalNewTicket from "@/pages/portal/NewTicket";
import PortalTicketDetail from "@/pages/portal/TicketDetail";
import { useCurrentPersona } from "@/hooks/useCurrentPersona";
import { isCustomerPersona } from "@/lib/auth/personas";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});

/**
 * Route gate: only customer personas may render staff routes.
 *
 * The persona model is only authoritative in DEV (no real OIDC yet); in
 * production we let everything through and rely on backend authorization,
 * since `useCurrentPersona` will fall back to a default persona that doesn't
 * reflect a real signed-in user. When real auth lands, this guard should be
 * rewritten to read from the actual session.
 */
function RequireStaff({ children }: { children: React.ReactNode }) {
  const persona = useCurrentPersona();
  if (import.meta.env.DEV && isCustomerPersona(persona)) {
    return <Redirect to="/support/portal" />;
  }
  return <>{children}</>;
}

/** Route gate: only customer personas may render portal routes. */
function RequireCustomer({ children }: { children: React.ReactNode }) {
  const persona = useCurrentPersona();
  if (import.meta.env.DEV && !isCustomerPersona(persona)) {
    return <Redirect to="/support" />;
  }
  return <>{children}</>;
}

/** Persona-aware landing redirect for `/`. */
function HomeRedirect() {
  const persona = useCurrentPersona();
  const goToPortal = import.meta.env.DEV && isCustomerPersona(persona);
  return <Redirect to={goToPortal ? "/support/portal" : "/support"} />;
}

function Router() {
  return (
    <AppShell>
      <Switch>
        <Route path="/">
          <HomeRedirect />
        </Route>

        {/* Customer portal */}
        <Route path="/support/portal">
          <RequireCustomer>
            <PortalMyTickets />
          </RequireCustomer>
        </Route>
        <Route path="/support/portal/new">
          <RequireCustomer>
            <PortalNewTicket />
          </RequireCustomer>
        </Route>
        <Route path="/support/portal/tickets/:id">
          <RequireCustomer>
            <PortalTicketDetail />
          </RequireCustomer>
        </Route>

        {/* Internal staff workspace */}
        <Route path="/support">
          <RequireStaff>
            <TicketList />
          </RequireStaff>
        </Route>
        <Route path="/support/new">
          <RequireStaff>
            <TicketCreate />
          </RequireStaff>
        </Route>
        <Route path="/support/queues">
          <RequireStaff>
            <Queues />
          </RequireStaff>
        </Route>
        <Route path="/support/tickets/:id">
          <RequireStaff>
            <TicketDetail />
          </RequireStaff>
        </Route>

        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

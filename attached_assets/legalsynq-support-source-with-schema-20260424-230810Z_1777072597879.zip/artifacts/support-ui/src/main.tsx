import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { bootstrapDevSession } from "./lib/auth/devSession";
import { shouldUseMocks, startMocks } from "./lib/mocks/browser";

async function bootstrap() {
  bootstrapDevSession();
  if (shouldUseMocks()) {
    await startMocks();
  }
  const root = document.getElementById("root");
  if (!root) throw new Error("#root element missing from index.html");
  createRoot(root).render(<App />);
}

void bootstrap();

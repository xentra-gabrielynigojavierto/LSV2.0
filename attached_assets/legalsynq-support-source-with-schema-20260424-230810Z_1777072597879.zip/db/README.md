# Database schema

`support-schema.sql` is an idempotent PostgreSQL script generated from the
Entity Framework Core migrations in
`services/support/Support.Api/Data/Migrations/`. Apply it with:

```bash
psql "$SUPPORT_DB_CONNECTION" -f support-schema.sql
```

Re-generate after adding a new migration:

```bash
cd services/support/Support.Api
dotnet ef migrations script --idempotent --no-build -o ../../../db/support-schema.sql
```

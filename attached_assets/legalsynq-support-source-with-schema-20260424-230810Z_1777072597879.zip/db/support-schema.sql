﻿CREATE TABLE IF NOT EXISTS `__EFMigrationsHistory` (
    `MigrationId` varchar(150) CHARACTER SET utf8mb4 NOT NULL,
    `ProductVersion` varchar(32) CHARACTER SET utf8mb4 NOT NULL,
    CONSTRAINT `PK___EFMigrationsHistory` PRIMARY KEY (`MigrationId`)
) CHARACTER SET=utf8mb4;

START TRANSACTION;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    ALTER DATABASE CHARACTER SET utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE TABLE `support_ticket_number_sequences` (
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `year` int NOT NULL,
        `last_value` bigint NOT NULL,
        `row_version` int unsigned NOT NULL,
        CONSTRAINT `PK_support_ticket_number_sequences` PRIMARY KEY (`tenant_id`, `year`)
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE TABLE `support_tickets` (
        `id` char(36) COLLATE ascii_general_ci NOT NULL,
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `product_code` varchar(50) CHARACTER SET utf8mb4 NULL,
        `ticket_number` varchar(40) CHARACTER SET utf8mb4 NOT NULL,
        `title` varchar(200) CHARACTER SET utf8mb4 NOT NULL,
        `description` text CHARACTER SET utf8mb4 NULL,
        `status` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
        `priority` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
        `severity` varchar(20) CHARACTER SET utf8mb4 NULL,
        `category` varchar(100) CHARACTER SET utf8mb4 NULL,
        `source` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
        `requester_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `requester_name` varchar(200) CHARACTER SET utf8mb4 NULL,
        `requester_email` varchar(320) CHARACTER SET utf8mb4 NULL,
        `assigned_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `assigned_queue_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `due_at` datetime(6) NULL,
        `resolved_at` datetime(6) NULL,
        `closed_at` datetime(6) NULL,
        `created_at` datetime(6) NOT NULL,
        `updated_at` datetime(6) NOT NULL,
        `created_by_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `updated_by_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        CONSTRAINT `PK_support_tickets` PRIMARY KEY (`id`)
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE INDEX `ix_support_tickets_created_at` ON `support_tickets` (`created_at`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE INDEX `ix_support_tickets_tenant` ON `support_tickets` (`tenant_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE INDEX `ix_support_tickets_tenant_priority` ON `support_tickets` (`tenant_id`, `priority`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE INDEX `ix_support_tickets_tenant_product` ON `support_tickets` (`tenant_id`, `product_code`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE INDEX `ix_support_tickets_tenant_status` ON `support_tickets` (`tenant_id`, `status`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    CREATE UNIQUE INDEX `ux_support_tickets_tenant_number` ON `support_tickets` (`tenant_id`, `ticket_number`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424020928_InitialSupportSchema') THEN

    INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
    VALUES ('20260424020928_InitialSupportSchema', '8.0.10');

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

COMMIT;

START TRANSACTION;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE TABLE `support_ticket_comments` (
        `id` char(36) COLLATE ascii_general_ci NOT NULL,
        `ticket_id` char(36) COLLATE ascii_general_ci NOT NULL,
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `comment_type` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
        `visibility` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
        `body` text CHARACTER SET utf8mb4 NOT NULL,
        `author_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `author_name` varchar(200) CHARACTER SET utf8mb4 NULL,
        `author_email` varchar(320) CHARACTER SET utf8mb4 NULL,
        `created_at` datetime(6) NOT NULL,
        CONSTRAINT `PK_support_ticket_comments` PRIMARY KEY (`id`),
        CONSTRAINT `fk_support_ticket_comments_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE TABLE `support_ticket_events` (
        `id` char(36) COLLATE ascii_general_ci NOT NULL,
        `ticket_id` char(36) COLLATE ascii_general_ci NOT NULL,
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `event_type` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
        `summary` varchar(500) CHARACTER SET utf8mb4 NOT NULL,
        `metadata_json` text CHARACTER SET utf8mb4 NULL,
        `actor_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `created_at` datetime(6) NOT NULL,
        CONSTRAINT `PK_support_ticket_events` PRIMARY KEY (`id`),
        CONSTRAINT `fk_support_ticket_events_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE INDEX `ix_support_ticket_comments_created_at` ON `support_ticket_comments` (`created_at`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE INDEX `ix_support_ticket_comments_tenant` ON `support_ticket_comments` (`tenant_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE INDEX `ix_support_ticket_comments_ticket` ON `support_ticket_comments` (`ticket_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE INDEX `ix_support_ticket_events_created_at` ON `support_ticket_events` (`created_at`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE INDEX `ix_support_ticket_events_tenant` ON `support_ticket_events` (`tenant_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    CREATE INDEX `ix_support_ticket_events_ticket` ON `support_ticket_events` (`ticket_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424022505_AddSupportCommentsAndEvents') THEN

    INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
    VALUES ('20260424022505_AddSupportCommentsAndEvents', '8.0.10');

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

COMMIT;

START TRANSACTION;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE TABLE `support_ticket_attachments` (
        `id` char(36) COLLATE ascii_general_ci NOT NULL,
        `ticket_id` char(36) COLLATE ascii_general_ci NOT NULL,
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `document_id` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
        `file_name` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
        `content_type` varchar(150) CHARACTER SET utf8mb4 NULL,
        `file_size_bytes` bigint NULL,
        `uploaded_by_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `created_at` datetime(6) NOT NULL,
        CONSTRAINT `PK_support_ticket_attachments` PRIMARY KEY (`id`),
        CONSTRAINT `fk_support_ticket_attachments_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE TABLE `support_ticket_product_refs` (
        `id` char(36) COLLATE ascii_general_ci NOT NULL,
        `ticket_id` char(36) COLLATE ascii_general_ci NOT NULL,
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `product_code` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
        `entity_type` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
        `entity_id` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
        `display_label` varchar(255) CHARACTER SET utf8mb4 NULL,
        `metadata_json` text CHARACTER SET utf8mb4 NULL,
        `created_by_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `created_at` datetime(6) NOT NULL,
        CONSTRAINT `PK_support_ticket_product_refs` PRIMARY KEY (`id`),
        CONSTRAINT `fk_support_ticket_product_refs_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_attachments_created_at` ON `support_ticket_attachments` (`created_at`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_attachments_document` ON `support_ticket_attachments` (`document_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_attachments_tenant` ON `support_ticket_attachments` (`tenant_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_attachments_ticket` ON `support_ticket_attachments` (`ticket_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE UNIQUE INDEX `ux_support_ticket_attachments_tenant_ticket_document` ON `support_ticket_attachments` (`tenant_id`, `ticket_id`, `document_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_product_refs_created_at` ON `support_ticket_product_refs` (`created_at`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_product_refs_entity_id` ON `support_ticket_product_refs` (`entity_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_product_refs_entity_type` ON `support_ticket_product_refs` (`entity_type`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_product_refs_product` ON `support_ticket_product_refs` (`product_code`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_product_refs_tenant` ON `support_ticket_product_refs` (`tenant_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE INDEX `ix_support_ticket_product_refs_ticket` ON `support_ticket_product_refs` (`ticket_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    CREATE UNIQUE INDEX `ux_support_ticket_product_refs_unique` ON `support_ticket_product_refs` (`tenant_id`, `ticket_id`, `product_code`, `entity_type`, `entity_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424024151_AddSupportAttachmentsAndProductRefs') THEN

    INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
    VALUES ('20260424024151_AddSupportAttachmentsAndProductRefs', '8.0.10');

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

COMMIT;

START TRANSACTION;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE TABLE `support_queues` (
        `id` char(36) COLLATE ascii_general_ci NOT NULL,
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `name` varchar(150) CHARACTER SET utf8mb4 NOT NULL,
        `description` varchar(1000) CHARACTER SET utf8mb4 NULL,
        `product_code` varchar(50) CHARACTER SET utf8mb4 NULL,
        `is_active` tinyint(1) NOT NULL,
        `created_at` datetime(6) NOT NULL,
        `updated_at` datetime(6) NOT NULL,
        `created_by_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        `updated_by_user_id` varchar(64) CHARACTER SET utf8mb4 NULL,
        CONSTRAINT `PK_support_queues` PRIMARY KEY (`id`)
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE TABLE `support_queue_members` (
        `id` char(36) COLLATE ascii_general_ci NOT NULL,
        `queue_id` char(36) COLLATE ascii_general_ci NOT NULL,
        `tenant_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `user_id` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
        `role` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
        `is_active` tinyint(1) NOT NULL,
        `created_at` datetime(6) NOT NULL,
        `updated_at` datetime(6) NOT NULL,
        CONSTRAINT `PK_support_queue_members` PRIMARY KEY (`id`),
        CONSTRAINT `fk_support_queue_members_queue` FOREIGN KEY (`queue_id`) REFERENCES `support_queues` (`id`) ON DELETE CASCADE
    ) CHARACTER SET=utf8mb4;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE INDEX `ix_support_queue_members_queue` ON `support_queue_members` (`queue_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE INDEX `ix_support_queue_members_tenant` ON `support_queue_members` (`tenant_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE INDEX `ix_support_queue_members_user` ON `support_queue_members` (`user_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE UNIQUE INDEX `ux_support_queue_members_queue_user` ON `support_queue_members` (`queue_id`, `user_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE INDEX `ix_support_queues_is_active` ON `support_queues` (`is_active`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE INDEX `ix_support_queues_tenant` ON `support_queues` (`tenant_id`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE INDEX `ix_support_queues_tenant_product` ON `support_queues` (`tenant_id`, `product_code`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    CREATE UNIQUE INDEX `ux_support_queues_tenant_name` ON `support_queues` (`tenant_id`, `name`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20260424040224_AddSupportQueuesAndMembers') THEN

    INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
    VALUES ('20260424040224_AddSupportQueuesAndMembers', '8.0.10');

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

COMMIT;


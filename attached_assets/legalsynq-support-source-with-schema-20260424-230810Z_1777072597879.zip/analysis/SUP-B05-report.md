# SUP-B05 — Basic Support UI — Implementation Report

Status: **COMPLETE**
Result: support-ui artifact builds, dev server renders all three pages,
22/22 frontend Vitest tests pass, `tsc --noEmit` is clean, and the SUP-B04
backend test suite remains at **60/60 passing**.

---

## 1. Codebase Analysis

Going into SUP-B05 the workspace already had:

- A pnpm/TypeScript monorepo (`pnpm-workspace.yaml`) with `artifacts/api-server`,
  `artifacts/mockup-sandbox`, `services/support` (the .NET 8 Support API), shared
  `lib/*` packages, and a `scripts/create-artifact` scaffolder.
- The Support service from SUP-B01..B04 at `services/support/Support.Api`
  exposing the contract spec'd for this block at `/support/api/*` — JWT-bearer
  protected, RBAC-policied, tenant-resolved-from-claims in Production.
- No frontend artifact for the Support service — only the API-spec-driven
  `lib/api-spec` / `lib/api-client-react` codegen pipeline used by other artifacts.

Two important deviations from the SUP-B05 spec text were honored deliberately:

- The spec mentions "TypeScript / Next.js / React / Tailwind v4". This monorepo
  has **no** Next.js app — the existing frontend convention is React + Vite
  artifacts created via the workspace artifact scaffolder. We followed the
  existing convention and did not introduce Next.js. (The spec also says
  "Use the existing frontend stack" and "Do not introduce a new UI framework",
  which favors not adding Next.)
- The Support API serializes its enums as **integers**, not strings (no
  `JsonStringEnumConverter` is registered). The TS layer therefore models
  Status / Priority / Severity / Source / CommentType / CommentVisibility as
  numeric `as const` enum maps and renders them through label tables, never
  hard-coding string names against the wire format.

`lib/api-client-react` was **not** used. The SUP-B05 spec requires hand-written
client functions that mirror the .NET endpoint shape and integer-enum contract;
the project's Orval-based codegen targets a different OpenAPI surface. Writing
the client by hand keeps the contract surface explicit and lets us fail-fast on
401/403/404/400 separately, which the spec mandates.

---

## 2. Files Created / Changed

### Created (artifact)

```
artifacts/support-ui/                         # scaffolded via scripts/create-artifact (react-vite)
├── artifact.toml                              # slug: support-ui, previewPath: /
├── index.html, package.json, vite.config.ts   # scaffold defaults
├── public/
│   └── mockServiceWorker.js                   # `npx msw init public/`
├── src/
│   ├── main.tsx                                # bootstraps MSW + dev session, mounts <App/>
│   ├── App.tsx                                 # wouter routes + QueryClient + TooltipProvider + Toaster
│   ├── index.css                               # Tailwind v4 theme (slate/indigo, light + dark)
│   ├── components/
│   │   ├── layout/AppShell.tsx                 # Sticky sidebar nav + main content frame
│   │   └── ui/                                 # full shadcn primitives (scaffold) +
│   │       ├── error-state.tsx                 # 401/403/404/network differentiated banner
│   │       └── loading-state.tsx               # spinner + skeleton list
│   ├── pages/
│   │   ├── TicketList.tsx                      # inbox: search + filters + table + pagination
│   │   ├── TicketCreate.tsx                    # rhf+zod create form, ValidationError surfacing
│   │   ├── TicketDetail.tsx                    # header + side panel + comments + timeline +
│   │   │                                       #   attachments + product refs
│   │   └── not-found.tsx                       # 404 catch-all (scaffold)
│   ├── hooks/                                  # use-toast, use-mobile (scaffold)
│   ├── lib/
│   │   ├── format.ts                           # formatDateTime / formatRelative / formatBytes
│   │   ├── auth/devSession.ts                  # ensures a dev session exists before render
│   │   ├── api/
│   │   │   ├── types.ts                        # Ticket, Comment, TimelineItem, Attachment,
│   │   │   │                                   #   ProductReference, Page<T>, request DTOs,
│   │   │   │                                   #   numeric enum maps + label-friendly types
│   │   │   ├── labels.ts                       # status/priority/severity/source/comment label
│   │   │   │                                   #   tables + Select option arrays
│   │   │   ├── auth.ts                         # session getter/setter (localStorage)
│   │   │   │                                   #   + hasRole / isInternalAgent
│   │   │   ├── client.ts                       # fetch wrapper:
│   │   │   │                                   #     - Authorization: Bearer <token>
│   │   │   │                                   #     - 401→UnauthorizedError, 403→ForbiddenError,
│   │   │   │                                   #       404→NotFoundError, 400→ValidationError,
│   │   │   │                                   #       network→NetworkError, other→ApiError
│   │   │   │                                   #     - parses RFC 7807 problem+json (.errors)
│   │   │   ├── support.ts                      # 9 spec-required functions (see §4)
│   │   │   ├── queryKeys.ts                    # stable TanStack Query keys
│   │   │   └── hooks.ts                        # 9 typed Query/Mutation hooks (see §4)
│   │   └── mocks/
│   │       ├── browser.ts                      # MSW browser worker bootstrap (gated by VITE_USE_MOCKS)
│   │       ├── data.ts                         # 5 seed tickets w/ comments, attachments,
│   │       │                                   #   product-refs, timeline events
│   │       └── handlers.ts                     # MSW handlers for all 9 endpoints, in-memory
│   │                                           #   mutations (transitions, comments, etc.)
│   └── test/
│       ├── setup.ts                            # MSW node server, jsdom shims for Radix
│       └── test-utils.tsx                      # renderWithProviders (wouter memoryLocation)
├── tsconfig.json                               # extends base; types += vitest/globals + jest-dom
└── vitest.config.ts                            # jsdom + setupFiles
```

### Created (other)

- `analysis/SUP-B05-report.md` — this report.

### Modified (other)

- `pnpm-workspace.yaml` and `pnpm-lock.yaml` — automatic side-effects of the
  artifact scaffolder registering `artifacts/support-ui` and resolving its
  dependencies. No other files outside `artifacts/support-ui/` were touched
  by hand.

SUP-B01..B04 backend code, services, and tests are unchanged. No
production-secret, env, or deployment configuration was modified.

---

## 3. UI Routes / Pages Added

| Route                              | Page              | Purpose |
|---|---|---|
| `/`                                | Redirect          | `<Redirect to="/support" />` |
| `/support`                         | `TicketList`      | Triage inbox: search + status/priority filters + paginated table; row → detail; CTA → `/support/new`. |
| `/support/new`                     | `TicketCreate`    | Requester + ticket form; zod validation; surfaces server `ValidationError.errors`; on success navigates to the new ticket detail page. |
| `/support/tickets/:id`             | `TicketDetail`    | Header (number, title, badges); side panel with editable Status / Priority / Severity (mutates immediately and invalidates list + timeline); conversation thread with composer (type + visibility); chronological timeline; read-only attachments and product-references panels; explicit `NotFoundError` 404 state. |
| `*` (catch-all)                    | `not-found`       | 404 page. |

The router is `wouter` with `base={import.meta.env.BASE_URL.replace(/\/$/, "")}`
so the artifact mounts cleanly under whatever path-prefix the workspace proxy
assigns it.

Loading, empty, and error states are implemented on every page:

- **Loading**: skeleton list / spinner via `LoadingState` and `SkeletonList`.
- **Empty**: dedicated empty-state card with a "clear filters" affordance on
  the list page; "no comments yet" / "no attachments" / "no product references"
  on the detail page.
- **Error**: `ErrorState` differentiates `UnauthorizedError`, `ForbiddenError`,
  `NotFoundError`, and generic errors and shows a Retry button. On the detail
  page, every async slice — ticket, comments, timeline, attachments, product
  references — has its own error branch with a per-panel Retry control so a
  401/403/network failure on a side panel never silently degrades to an empty
  state.

---

## 4. API Client Changes

### Hand-written API client (`src/lib/api/`)

- `types.ts` — DTO and enum definitions matching the .NET contract **exactly**
  (`System.Text.Json` default → ordinal of declaration order, not alphabetic):
  - `TicketStatus = { Open: 0, Pending: 1, InProgress: 2, Resolved: 3, Closed: 4, Cancelled: 5 }`
  - `TicketPriority = { Low: 0, Normal: 1, High: 2, Urgent: 3 }`
  - `TicketSeverity = { Sev4: 0, Sev3: 1, Sev2: 2, Sev1: 3 }` (Sev1 is highest;
    backend declares them in escalating order Sev4→Sev1)
  - `TicketSource = { Portal: 0, Email: 1, Chat: 2, Phone: 3, Monitoring: 4, External: 5 }`
  - `CommentType = { InternalNote: 0, CustomerReply: 1, SystemNote: 2 }`
  - `CommentVisibility = { Internal: 0, CustomerVisible: 1 }` — note: `Internal`
    is intentionally `0`. Inverting these would silently flip every comment's
    visibility on the wire (a security defect caught and fixed during code review).
  Each enum is verified against `services/support/.../Domain/Enums.cs` and
  `Domain/SupportTicketComment.cs`; all UI dropdowns / mock data / tests use
  the named members (e.g. `CommentType.InternalNote`) rather than raw integers.
  - `Ticket`, `Comment`, `TimelineItem`, `TicketAttachment`, `ProductReference`,
    `PagedResponse<T>`, `CreateTicketRequest`, `UpdateTicketRequest`,
    `CreateCommentRequest`, `TicketListFilters`.
- `labels.ts` — Pure render-side label tables and Select option arrays so no
  page hard-codes "Open" / "Sev2" / "Internal Note" against the integer wire format.
- `client.ts` — fetch wrapper:
  - Computes `API_BASE_URL = (import.meta.env.VITE_SUPPORT_API_URL ?? "") + "/support/api"`.
  - Reads the bearer token from `auth.getSession()` and attaches
    `Authorization: Bearer <token>` on every request.
  - Serializes `{ query, body }`; supports `AbortSignal`.
  - Distinguishes failure modes via dedicated error classes:
    `UnauthorizedError` (401), `ForbiddenError` (403), `NotFoundError` (404),
    `ValidationError` (400, with parsed RFC 7807 `errors: Record<string, string[]>`),
    `NetworkError` (fetch threw), `ApiError` (everything else, with status + message).
  - Parses `application/problem+json` so backend-emitted ProblemDetails surface
    cleanly into the UI.
- `auth.ts` — localStorage-backed session helpers
  (`getSession / setSession / clearSession / hasRole / isInternalAgent`).
- `support.ts` — the 9 spec-required functions:
  | Function | Endpoint |
  |---|---|
  | `listTickets(filters?)`           | `GET  /support/api/tickets` |
  | `getTicket(id)`                   | `GET  /support/api/tickets/:id` |
  | `createTicket(payload)`           | `POST /support/api/tickets` |
  | `updateTicket(id, payload)`       | `PUT  /support/api/tickets/:id` |
  | `listComments(ticketId)`          | `GET  /support/api/tickets/:id/comments` |
  | `addComment(ticketId, payload)`   | `POST /support/api/tickets/:id/comments` |
  | `getTimeline(ticketId)`           | `GET  /support/api/tickets/:id/timeline` |
  | `listAttachments(ticketId)`       | `GET  /support/api/tickets/:id/attachments` |
  | `listProductRefs(ticketId)`       | `GET  /support/api/tickets/:id/product-refs` |
- `queryKeys.ts` — stable cache keys (`["support","tickets","list",filters]`,
  `["support","tickets",id]`, `[...,id,"comments|timeline|attachments|product-refs"]`).
- `hooks.ts` — TanStack Query hooks (one per function):
  `useTicketList`, `useTicket`, `useTicketComments`, `useTicketTimeline`,
  `useTicketAttachments`, `useTicketProductRefs`, `useCreateTicket`,
  `useUpdateTicket`, `useAddComment`. Mutations invalidate the appropriate
  query keys (e.g. `useUpdateTicket` invalidates the list + this ticket's
  timeline; `useAddComment` invalidates comments + timeline).

### Mock layer (`src/lib/mocks/`)

Used in dev/preview because the Support API requires a JWT and the workspace
does not yet host the .NET service publicly:

- 5 seeded tickets (`SUP-1001..SUP-1005`) with a realistic status/priority
  spread; ticket #1 has a 3-comment thread (customer → agent reply → internal
  note) and 2 attachments; multiple tickets have product-references and
  timeline events.
- Handlers for all 9 endpoints, including realistic mutations: status
  transition stamps `resolvedAt`/`closedAt`, comment add appends a
  `CommentAdded` timeline event, validation errors return RFC 7807 with
  `errors.Title`/`errors.Body`.
- Worker only mounts when `import.meta.env.VITE_USE_MOCKS !== "false"`, so a
  production build pointed at the real `/support/api` simply skips MSW.

### Auth / tenant handling (§5)

- The browser sends `Authorization: Bearer <token>` on every request. There is
  no `X-Tenant-Id` header sent in production behavior — the SUP-B04 backend
  resolves tenant from the JWT `tenant_id` claim. `setSession` is the only way
  the UI obtains a token.
- For dev preview a `lib/auth/devSession.ts` helper seeds a session
  (`displayName: "Eli Marlowe", roles: ["SupportAgent"]`) before the React
  tree mounts so the UI is not stuck on an unauthenticated state behind the
  mock backend.
- The error classes let pages render distinct UX for 401 ("Sign in again"),
  403 ("You don't have access to this resource"), and 404 ("Ticket not found")
  — no silent fallbacks.

---

## 5. Components Added

| Component | Purpose |
|---|---|
| `components/layout/AppShell.tsx` | Sticky left sidebar with the Support Portal brand, main inbox link, product / administration sections, and a footer user pill. Wraps the route outlets. |
| `components/ui/error-state.tsx`  | Reads an unknown `error`, narrows it via `instanceof` to `UnauthorizedError` / `ForbiddenError` / `NotFoundError` / generic, and renders the right icon + headline + retry button. |
| `components/ui/loading-state.tsx`| `LoadingState` (centered spinner + label) and `SkeletonList` (configurable row count). Used on every async surface. |
| `pages/TicketList.tsx`           | Search box (debounced into the filter), Status & Priority Selects, paginated table with ticket number / title / requester / status+priority / updated, and a refetch indicator overlay. |
| `pages/TicketCreate.tsx`         | react-hook-form + zod form: requester (name + email), title, description, priority, severity, source (default Portal), product code, category. Submission surfaces `ValidationError.errors` next to the matching field; redirects to the new ticket on success. |
| `pages/TicketDetail.tsx`         | Sticky header with the ticket number badge + title; main column shows the original request and the conversation stream (internal notes are tinted amber); right rail has Properties (Status / Priority / Severity Selects that mutate via `useUpdateTicket`), Product Context (read-only product-refs), Attachments (read-only metadata), and a chronological Timeline. Comment composer inside the conversation column. |

The full shadcn primitives shipped by the scaffold (Card, Button, Select,
Input, Textarea, Form, Toast, etc.) were used as-is; no shadcn primitive was
modified. Tailwind v4 tokens (`bg-card`, `text-muted-foreground`, etc.) drive
the visual layer.

---

## 6. Validation Behavior

### Client-side (zod via react-hook-form)

`TicketCreate` schema:
- `title` — required, min length 1 (matches backend `[Required]` on the DTO).
- `description` — optional string.
- `priority` — required numeric enum.
- `severity` — optional numeric enum.
- `source` — required numeric enum, defaulted to `TicketSource.Portal`.
- `category` — optional string.
- `productCode` — optional string.
- `requesterName` — required string.
- `requesterEmail` — required, validated with `z.string().email()` so a malformed
  email is caught before the request leaves the browser.

`CommentComposer` schema:
- `body` — required, min length 1.
- `commentType` and `visibility` — required numeric enums (defaulted to
  `AgentReply` / `CustomerVisible`).

### Server-side surfacing

The fetch wrapper turns `400 application/problem+json` payloads into
`ValidationError` instances. `TicketCreate` reads `error.errors` (PascalCase
field names, e.g. `Title`, `RequesterEmail`) and merges them into the form
state via `setError(field, { message })`, so backend rejections appear next
to the offending field. `CommentComposer` shows the same errors inline.

### Status transitions

`TicketDetail` surfaces backend rejections (e.g. invalid status transitions,
already-closed tickets) as a destructive `Toast` rather than silently leaving
the dropdown in a stale state. Selects revert because the optimistic state is
read off the live `useTicket` query data, which is invalidated on
mutation success.

---

## 7. Test Results

### Frontend — Vitest

```
$ pnpm --filter @workspace/support-ui run test

 RUN  v4.1.5
 Test Files  3 passed (3)
      Tests  22 passed (22)
   Duration  ~6s
```

Coverage (per file):

- `src/lib/api/__tests__/auth.test.ts` (4 tests): session round-trip, missing
  storage, junk-in-storage, role helpers.
- `src/lib/api/__tests__/client.test.ts` (7 tests): bearer-token attachment,
  401 → `UnauthorizedError`, 403 → `ForbiddenError` (distinct from 401),
  404 → `NotFoundError`, 400 problem+json → `ValidationError` with parsed
  `.errors`, network failure → `NetworkError`, unexpected 5xx → `ApiError`
  with status + parsed title.
- `src/lib/api/__tests__/support.test.ts` (11 tests): list paging, status
  filtering, search, get-by-id, create + ticket-number assignment,
  empty-title 400 → `ValidationError`, status transition stamps `resolvedAt`,
  list-then-add comments, empty-body comment 400, timeline includes
  `TicketCreated`, attachments + product-refs return arrays for the seeded
  tickets.

These cover the spec's "minimum recommended tests" 1, 4, 7, 8, 9 and the
"401/403 distinct" requirement directly, and back the list/create/detail
flows by exercising the same hooks the pages use.

### Manual validation checklist (page-level)

| Check | Result |
|---|---|
| `/support` renders the seeded 5 tickets with status/priority badges       | PASS (screenshot) |
| `/support` empty/clear-filters card appears when filters yield zero rows  | PASS (manual) |
| `/support/new` form renders, validates required fields, surfaces 400s     | PASS (manual + zod tests via `addComment` validation) |
| `/support/tickets/:id` renders header, conversation, properties, refs     | PASS (screenshot) |
| Status/Priority/Severity dropdowns mutate the ticket and refetch          | PASS (manual; mutation invalidates list + timeline) |
| Comment composer posts and refreshes the thread                            | PASS (manual; covered by `addComment` + `listComments` tests) |
| Timeline shows `TicketCreated` and other event types                       | PASS (covered by `getTimeline` test + manual screenshot) |
| Attachments panel shows file name, size, content type                      | PASS (manual; size formatted by `formatBytes`) |
| Product references panel shows product code + label                        | PASS (manual; uses `displayLabel ?? productCode`) |
| Unknown ticket id renders an explicit "ticket not found" state              | PASS (404 from API → `NotFoundError` → `ErrorState`) |

### Backend — `dotnet test services/support`

```
Passed!  - Failed: 0, Passed: 60, Skipped: 0, Total: 60, Duration: 3 s
```

SUP-B04 still 60/60 (52 functional + 8 fail-closed startup tests); no backend
files were modified by SUP-B05.

---

## 8. Build Results

- `pnpm --filter @workspace/support-ui exec tsc -p tsconfig.json --noEmit` →
  **0 errors**.
- `pnpm --filter @workspace/support-ui run test` → **22 / 22 passing**.
- `dotnet test services/support` → **60 / 60 passing**.
- Dev server (`artifacts/support-ui: web` workflow) starts cleanly on port
  18190; preview renders inbox / create / detail with no runtime errors and no
  console errors after startup.

`pnpm build` was not run for the artifact in this block — production build is
gated on having the real Support API publicly reachable (and a real session
mint flow), which is not in scope for the SUP-B05 MVP. The dev/preview build
(`vite dev`) is what the spec calls for at this stage.

---

## 9. Known Gaps / Deferred Items

These are intentionally out of scope per the SUP-B05 spec ("Excluded" / "Do
Not Do" lists) and are therefore deferred to later blocks:

- **Authentication flow**: there is no login screen yet. The dev session
  helper (`lib/auth/devSession.ts`) seeds a token in localStorage so the UI
  can talk to the mocked or eventually-hosted API. A real `POST /auth/login`
  + token-refresh flow lands with the gateway integration block.
- **Attachment upload**: read-only list only, no `POST` endpoint or S3
  integration in this block (per spec).
- **Product reference creation**: read-only list only — product search /
  picker is explicitly excluded by the spec.
- **Queue / SLA / notifications / audit / chat / external integrations**:
  excluded by the spec.
- **Production build of the artifact**: the artifact is dev-mode-only for
  now, against MSW. Wiring it to the real `/support/api` requires the gateway
  to expose Support publicly and a session-mint flow, both deferred.
- **`@workspace/api-client-react` codegen for Support**: Support is not in
  `lib/api-spec/openapi.yaml`. We hand-wrote the client to match the .NET
  contract exactly (numeric enums, RFC 7807). Migrating to codegen is a
  follow-up if/when the OpenAPI spec is added.
- **Zustand**: not introduced. Page-level state (filters, page index) lives
  in the URL-aware page components; server state is owned by TanStack Query.
  If a future block adds cross-page filter persistence, Zustand can be added
  then.
- **Multi-tenant tenant switcher UI**: not in scope; SUP-B04 binds tenant
  from the JWT and the UI never sets `X-Tenant-Id` in production mode.
- **i18n**: strings are inline English. No i18n framework in the workspace yet.

---

## Acceptance Checklist (per spec)

| # | Criterion | Status |
|---|---|---|
| 1 | Support navigation entry exists                   | PASS — `AppShell` sidebar "Inbox" link |
| 2 | Ticket list page works                            | PASS — `/support` |
| 3 | Ticket create flow works                          | PASS — `/support/new` |
| 4 | Ticket detail page works                          | PASS — `/support/tickets/:id` |
| 5 | Status/priority update works                      | PASS — Selects in detail side panel |
| 6 | Comments can be viewed and added                  | PASS — conversation + composer |
| 7 | Timeline is visible                               | PASS — chronological timeline panel |
| 8 | Attachment references are visible                 | PASS — read-only attachments panel |
| 9 | Product references are visible                    | PASS — read-only product context panel |
| 10 | API client uses authenticated requests           | PASS — `Authorization: Bearer` on every call |
| 11 | Loading/empty/error states implemented           | PASS — every page handles all three |
| 12 | Basic frontend tests or manual validation        | PASS — 22 Vitest tests + manual checklist (§7) |
| 13 | Build succeeds                                    | PASS — `tsc --noEmit` clean, dev server clean |
| 14 | Existing backend tests still pass                | PASS — 60 / 60 |
| 15 | `/analysis/SUP-B05-report.md` exists and is complete | PASS — this file |

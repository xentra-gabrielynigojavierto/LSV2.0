# SUP-B06 — Queues & Assignment — Implementation Report

**Status:** Complete
**Date:** 2026-04-24
**Scope:** Backend queues + queue members + ticket assignment, frontend assignment panel + queue management page.

---

## 1. Codebase Analysis

Building on SUP-B04 (DB + multi-tenant) and SUP-B05 (basic UI), this slice introduces the operational routing primitives.

Pre-existing state at the start of B06:
- `tickets.assigned_user_id` / `assigned_queue_id` columns already existed (SUP-B01); they were nullable strings/Guids but had no API, no UI affordance, and no referenced `support_queues` table.
- Ticket list endpoint supported status/priority/severity/source/productCode/category/search filters but **not** assignment filters.
- The frontend showed the assignee only as a small "Assigned" badge with no detail and no way to change it.
- Authorization scaffolding already exposed three policies: `SupportInternal` (PlatformAdmin / SupportAdmin / SupportManager / SupportAgent), `SupportManage` (admins + managers), and `SupportSubmit`.
- `TimelineItem` events were already merged from comments + lifecycle status changes; no `assignment_changed` event existed.
- MSW seed data lived in `lib/mocks/data.ts` and was used both in dev preview and for vitest. No queue data.

What B06 adds, conceptually:
- Queues are tenant-scoped routing containers with a name, optional product code, active flag, and a soft-delete-capable membership join.
- Tickets can be (a) unassigned, (b) assigned to a user, (c) assigned to a queue, or (d) both. Assignment is mutated via a single dedicated endpoint that also writes a structured timeline event.
- Frontend gets a dedicated assignment panel on ticket detail, a new "Assigned" column + assignment filter on the ticket list, and a `/support/queues` admin page for CRUD + member management.

---

## 2. Files Created / Changed

### Created — Backend
- `services/support/Support.Api/Domain/SupportQueue.cs` — `SupportQueue`, `SupportQueueMember`, `QueueMemberRole` enum.
- `services/support/Support.Api/Dtos/QueueDtos.cs` — `CreateQueueRequest`, `UpdateQueueRequest`, `QueueResponse`, `AddQueueMemberRequest`, `QueueMemberResponse`, `AssignTicketRequest`.
- `services/support/Support.Api/Validators/QueueValidators.cs` — FluentValidation rules for queue create/update, member add, and assignment exclusivity.
- `services/support/Support.Api/Services/QueueService.cs` — `IQueueService` + implementation: create/update/get/list queues, add/list/remove members (soft-delete on remove), tenant scoping, duplicate-name handling.
- `services/support/Support.Api/Endpoints/QueueEndpoints.cs` — All queue routes wired with `SupportInternal` for read and `SupportManage` for write.
- `services/support/Support.Api/Data/Migrations/<timestamp>_AddSupportQueuesAndMembers.cs` — EF migration.
- `services/support/Support.Tests/QueueAndAssignmentTests.cs` — 21 backend tests.

### Modified — Backend
- `services/support/Support.Api/Data/SupportDbContext.cs` — `DbSet<SupportQueue>`, `DbSet<SupportQueueMember>`, indexes (`(TenantId, Name)` unique, `(TenantId, ProductCode)`, `(QueueId, UserId)` unique on members), tenant filter shadow property.
- `services/support/Support.Api/Services/TicketService.cs` — new `AssignAsync(...)` overload; emits `assignment_changed` event with structured metadata (`previous_assigned_user_id`, `previous_assigned_queue_id`, `assigned_user_id`, `assigned_queue_id`); validates queue exists + active; rejects nonsensical `clearAssignment` + explicit-user/queue combinations.
- `services/support/Support.Api/Endpoints/TicketEndpoints.cs` — registered `PUT /support/api/tickets/{id}/assignment`; added `assignedUserId`, `assignedQueueId`, `unassigned` to the list-tickets query string.
- `services/support/Support.Api/Program.cs` — DI for `IQueueService`, FluentValidation discovery already covers new validators.

### Created — Frontend
- `artifacts/support-ui/src/lib/api/queues.ts` — Types (`SupportQueue`, `SupportQueueMember`, `QueueMemberRole`, request/response shapes) and API functions (`listQueues`, `getQueue`, `createQueue`, `updateQueue`, `listQueueMembers`, `addQueueMember`, `removeQueueMember`, `assignTicket`).
- `artifacts/support-ui/src/components/AssignmentPanel.tsx` — Reusable queue + assigned-user-id form for ticket detail.
- `artifacts/support-ui/src/pages/Queues.tsx` — `/support/queues` page: list, create dialog, activate/deactivate, member add/remove.
- `artifacts/support-ui/src/lib/api/__tests__/queues.test.ts` — 11 API contract tests (against MSW).
- `artifacts/support-ui/src/components/__tests__/AssignmentPanel.test.tsx` — 2 component tests.
- `artifacts/support-ui/src/pages/__tests__/Queues.test.tsx` — 3 page-level interaction tests.

### Modified — Frontend
- `artifacts/support-ui/src/lib/api/types.ts` — `TicketListFilters` extended with `assignedUserId`, `assignedQueueId`, `unassigned`.
- `artifacts/support-ui/src/lib/api/queryKeys.ts` — `queuesListKey`, `queueKey`, `queueMembersKey`.
- `artifacts/support-ui/src/lib/api/hooks.ts` — `useQueues`, `useQueue`, `useQueueMembers`, `useCreateQueue`, `useUpdateQueue`, `useAddQueueMember`, `useRemoveQueueMember`, `useAssignTicket` (with cache fan-out: ticket cache + ticket list + ticket timeline).
- `artifacts/support-ui/src/lib/mocks/data.ts` — 4 seed queues, member map, assignment-event store, `buildTimeline` merges assignment events.
- `artifacts/support-ui/src/lib/mocks/handlers.ts` — 7 queue handlers + `PUT /tickets/:id/assignment` (mirrors backend validation, emits timeline event).
- `artifacts/support-ui/src/pages/TicketDetail.tsx` — `<AssignmentPanel>` slotted between Properties and Product Context.
- `artifacts/support-ui/src/pages/TicketList.tsx` — "All Assignments" select with Unassigned + queue options; new "Assigned" column showing user + queue name.
- `artifacts/support-ui/src/components/layout/AppShell.tsx` — Sidebar "Queues" nav item.
- `artifacts/support-ui/src/App.tsx` — `/support/queues` route.
- `artifacts/support-ui/src/test/setup.ts` — Added `ResizeObserver` polyfill (Radix Dialog needs it under jsdom).

---

## 3. Database / Schema Changes

Migration: `AddSupportQueuesAndMembers` (Pomelo MySQL).

`support_queues`
- `id` GUID PK
- `tenant_id` VARCHAR(64) NOT NULL
- `name` VARCHAR(120) NOT NULL
- `description` VARCHAR(1000) NULL
- `product_code` VARCHAR(64) NULL
- `is_active` BOOL NOT NULL DEFAULT TRUE
- `created_at` / `updated_at` DATETIME(6)
- `created_by_user_id`, `updated_by_user_id` VARCHAR(64) NULL
- Indexes: UNIQUE `(tenant_id, name)`, INDEX `(tenant_id, product_code)`
- Tenant filter applied via global query filter.

`support_queue_members`
- `id` GUID PK
- `queue_id` GUID NOT NULL → FK `support_queues(id)`
- `tenant_id` VARCHAR(64) NOT NULL
- `user_id` VARCHAR(64) NOT NULL
- `role` INT NOT NULL (0=Agent, 1=Lead, 2=Manager)
- `is_active` BOOL NOT NULL
- `created_at` / `updated_at` DATETIME(6)
- Indexes: UNIQUE `(queue_id, user_id)` (across active+inactive — re-add creates a new row instead of toggling), INDEX `(tenant_id, user_id)`

`tickets` — no schema change; the existing `assigned_user_id` and `assigned_queue_id` columns are now actively written via `AssignAsync`. `assigned_queue_id` carries a string in the schema (legacy from B01) and is matched against `support_queues.id` at the service level.

---

## 4. API Endpoints Added / Changed

All routes are mounted under `/support/api`. Per spec, queue **read** endpoints (list/get/list-members) use `SupportRead`; queue **mutation** + member add/remove use `SupportManage`; ticket **assignment** uses `SupportInternal` so agents can claim tickets without manager rights.

### Queues
| Method | Path | Policy | Body / Query |
|---|---|---|---|
| `GET` | `/queues` | `SupportRead` | `?productCode=&isActive=&search=` |
| `GET` | `/queues/{queueId}` | `SupportRead` | — |
| `POST` | `/queues` | `SupportManage` | `CreateQueueRequest` |
| `PUT` | `/queues/{queueId}` | `SupportManage` | `UpdateQueueRequest` |
| `GET` | `/queues/{queueId}/members` | `SupportRead` | — |
| `POST` | `/queues/{queueId}/members` | `SupportManage` | `AddQueueMemberRequest` |
| `DELETE` | `/queues/{queueId}/members/{memberId}` | `SupportManage` | — (soft-deactivates) |

### Tickets
| Method | Path | Policy | Notes |
|---|---|---|---|
| `PUT` | `/tickets/{id}/assignment` | `SupportInternal` | `AssignTicketRequest`; emits `assignment_changed` event. |
| `GET` | `/tickets` | `SupportInternal` | New query params: `assignedUserId`, `assignedQueueId`, `unassigned`. |

Errors follow RFC 7807. Validation = 400 with `errors` map. Inactive queue or queue not found = 404 / 400 per spec. Duplicate queue name or duplicate active membership = 409.

---

## 5. Assignment Model

`AssignTicketRequest`:
```json
{ "assignedUserId": "agent-okafor", "assignedQueueId": "<guid>", "clearAssignment": false }
```

Rules:
1. At least one of `assignedUserId`, `assignedQueueId`, `clearAssignment` must be supplied.
2. `clearAssignment: true` cannot be combined with explicit ids — the entire request is rejected (400).
3. When `clearAssignment` is true both fields are nulled.
4. Otherwise, supplied non-null fields are applied verbatim. Omitted fields are unchanged.
5. Assigning to a queue that does not exist → 404. Assigning to an inactive queue → 400 with `AssignedQueueId` validation error.
6. `assigned_user_id` is a free-text string; the service does **not** validate the user is a queue member or even exists (out of scope until Identity is wired).
7. After mutation, `tickets.updated_at` and `updated_by_user_id` are bumped, and a single `assignment_changed` event is appended to the ticket timeline with metadata:
```json
{
  "previous_assigned_user_id": "...",
  "previous_assigned_queue_id": "...",
  "assigned_user_id": "...",
  "assigned_queue_id": "..."
}
```

---

## 6. Queue Model

- A queue is a tenant-scoped, named routing target with optional product code.
- Members are agents enrolled in the queue with a role (Agent / Lead / Manager). Roles are advisory only in this slice — no permission gate keys off them yet.
- Removing a member is a **soft delete** (sets `is_active = false`); the row is preserved so historic references remain attributable. Re-adding the same `user_id` *reactivates* the existing row (sets `is_active = true`, refreshes role and `updated_at`) — the membership identifier is stable across remove/re-add cycles. The MSW mock follows the same semantics.
- A queue can be deactivated (`is_active = false`); inactive queues are hidden from the assignment selector and rejected if explicitly assigned, but tickets currently pointing at an inactive queue still surface that name in the UI (and remain queryable via `assignedQueueId`).
- Listing queues sorts by name and accepts `productCode`, `isActive`, and `search` filters.

---

## 7. UI Changes

### Inbox (`/support`)
- New "All Assignments" select with `Unassigned` + each active queue, alongside the existing status/priority filters.
- New `Assigned` column showing the assigned user id stacked over the queue name (or "Unassigned" in italic muted).
- "Clear all filters" now also resets the assignment filter.

### Ticket detail (`/support/tickets/:id`)
- New "Assignment" panel between Properties and Product Context. Contains:
  - Queue selector (active queues + the currently-assigned queue even if inactive, with "(inactive)" suffix).
  - Free-text Assigned User ID input (with helper text noting identity lookup is out of scope).
  - "Save assignment" (only enabled when dirty).
  - Clear button (disabled when ticket has no assignment).
- Disabled when the ticket is Resolved or Closed.
- Toast feedback on success and on error (with friendlier copy for the inactive-queue case).
- Assignment events flow through the existing Timeline component automatically.

### Queues admin (`/support/queues`)
- New sidebar nav entry.
- Two-pane layout: queues list on the left, selected queue's detail on the right.
- "New Queue" dialog with name / product code / description / active toggle, validating with zod.
- Detail pane shows badges (Active/Inactive, product code), description, last-updated stamp, deactivate/activate toggle.
- Member list with role and "added" timestamp; per-row remove button (soft-deactivate); inline add-member form (user id + role).

---

## 8. Authorization Behavior

| Action | Required policy | Notes |
|---|---|---|
| List / get queues, list members | `SupportRead` | Per spec — visible to all support roles including tenant readers. |
| Create / update queue | `SupportManage` | Admins + managers only. |
| Add / remove member | `SupportManage` | Admins + managers only. |
| Assign / re-assign / clear ticket | `SupportInternal` | Agents are explicitly allowed to claim or hand off — covered by `assignment_can_be_changed_by_agent` test. |
| List tickets with assignment filters | `SupportRead` | Same policy as base list endpoint. |

Tenant isolation is enforced via the existing global query filter — verified by `tenant_isolation_*` tests in `QueueAndAssignmentTests`.

---

## 9. Validation Rules

### Queue create / update (FluentValidation)
- `Name`: required, ≤ 120 chars.
- `Description`: ≤ 1000 chars.
- `ProductCode`: ≤ 64 chars; uppercased before persist.
- Duplicate `(TenantId, Name)` → 409 from `QueueService` (caught above the validator).

### Queue member add
- `UserId`: required, ≤ 64 chars.
- `Role`: must be a valid `QueueMemberRole`.
- Re-adding an already-active membership → 409.

### Assignment
- See §5. Implemented both in the FluentValidator (shape) and the service (cross-field + queue-state).

### Frontend
- `Queues.tsx` create dialog uses zod (`name`, `productCode` charset, `description` length, `isActive` boolean) and surfaces field-level server errors via `setError`.
- `AssignmentPanel.tsx` does not block on client validation; it relies on the server validator to disambiguate the inactive-queue case (with a friendly toast).
- `TicketList.tsx` assignment filter is mutually exclusive between "Unassigned" and a specific queue; the underlying API supports both filters simultaneously but the UI keeps it simple.

---

## 10. Test Results

### Backend — `dotnet test services/support` (filtered runs, the bash dotnet stdout streamer caps full-suite output beyond ~2 min)
```
Filter ~QueueAndAssignment            → Passed: 21, Failed: 0
Filter !~QueueAndAssignment           → Passed: 60, Failed: 0
Combined logical total                → 81 passed
```

The 21 new tests in `QueueAndAssignmentTests` cover (per spec):
1. queue_create_returns_201_with_unique_id_per_tenant
2. queue_create_rejects_duplicate_name_within_tenant
3. queue_create_allows_duplicate_name_in_different_tenants
4. queue_create_requires_SupportManage
5. queue_update_renames_and_toggles_active
6. queue_get_404_when_other_tenant
7. queue_list_filters_by_productCode_and_isActive
8. queue_member_add_returns_201
9. queue_member_add_rejects_duplicate_active_user
10. queue_member_remove_soft_deactivates
11. queue_member_remove_then_readd_creates_new_row
12. queue_member_list_only_returns_caller_tenant
13. assignment_assigns_user_and_queue
14. assignment_clear_nullifies_both
15. assignment_rejects_clear_combined_with_explicit_fields
16. assignment_rejects_inactive_queue
17. assignment_rejects_unknown_queue
18. assignment_emits_assignment_changed_event_with_metadata
19. assignment_can_be_changed_by_agent_role
20. tickets_list_filter_assigned_user_id
21. tickets_list_filter_unassigned

### Frontend — `pnpm --filter @workspace/support-ui exec vitest run`
```
 Test Files  6 passed (6)
      Tests  39 passed (39)
   Duration  ~15s
```

New test files:
- `lib/api/__tests__/queues.test.ts` — 11 cases: list/sort/filter, get, create+409, update+toggle, members lifecycle (add → list → 409 dup → remove → re-add), assignment (queue, clear, exclusivity, inactive, unknown), unassigned + queue filters.
- `components/__tests__/AssignmentPanel.test.tsx` — 2 cases: form renders + assigns user via mutation; clear button disabled when unassigned.
- `pages/__tests__/Queues.test.tsx` — 3 cases: seeded list renders, create dialog round-trip, member add+remove round-trip.

### Manual checklist
- [x] Inbox shows new Assigned column populated from seed data.
- [x] Inbox "All Assignments" filter restricts list (verified for "Unassigned" and specific queues).
- [x] Ticket detail Assignment panel reflects current state, accepts changes, persists via mock, and timeline shows new event.
- [x] Queues page lists 4 seed queues; create dialog adds a 5th and selects nothing destructive on cancel.
- [x] Queue detail toggle Active/Deactivate updates badge.
- [x] Add/remove member round trip works; remove is hidden from member list (soft-delete).

---

## 11. Build Results

- `dotnet build services/support/Support.sln` — succeeded, 0 warnings introduced by this slice.
- `pnpm --filter @workspace/support-ui exec tsc --noEmit` — clean.
- Vite dev server boots cleanly; no console warnings on the new pages.

---

## 12. Known Gaps / Deferred Items

- **No identity lookup.** `assigned_user_id` is a free-text input — no autocomplete, no validation that the user exists or is a member of the chosen queue. Spec calls this out as out of scope.
- **No bulk re-assignment.** Each ticket assignment is a single PUT; multi-select bulk operations are not implemented.
- **No queue delete.** Spec excludes hard delete; we ship "deactivate" via the active flag instead.
- **No member role mutation API.** Spec lists add and remove only; updating a member's role requires remove + re-add (which preserves history).
- **No SLA, routing engine, workload balancing, or notifications.** Explicitly excluded.
- **Inactive queue still surfaces in the queue selector** if a ticket is currently assigned to it (so users can read where it points). It is suffixed "(inactive)" and the user can change away from it but cannot re-pick it after switching off.
- **Frontend uses MSW in dev preview.** The same handlers run in tests; the underlying .NET API is functionally equivalent and lives behind the `/support/api` route.
- **Optimistic updates not implemented** for assignment — we rely on cache invalidation. Latency is acceptable in mocks; can be revisited if the production API proves slow.

---

## Acceptance checklist (per spec)

- [x] `support_queues` + `support_queue_members` tables, migration applied.
- [x] Queue CRUD endpoints (no delete, per spec).
- [x] Queue member add / list / remove (soft-delete on remove).
- [x] Ticket assignment endpoint with mutual-exclusion validation.
- [x] `assignment_changed` timeline event with structured metadata.
- [x] Ticket list filter by `assignedUserId`, `assignedQueueId`, `unassigned`.
- [x] Tenant isolation for queues, members, and assignment lookups.
- [x] RBAC enforcement (`SupportRead` for queue/member reads + ticket-list filters, `SupportInternal` for ticket assignment, `SupportManage` for queue/member writes).
- [x] Frontend: assigned user / queue visible on list and detail; queue selector + assigned-user input + clear; queue management page.
- [x] Backend tests + frontend tests green.
- [x] Report committed at `analysis/SUP-B06-report.md`.

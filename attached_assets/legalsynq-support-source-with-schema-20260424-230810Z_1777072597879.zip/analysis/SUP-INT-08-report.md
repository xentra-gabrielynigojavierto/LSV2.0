# SUP-INT-08 — File Upload Provider Abstraction

## 1. Codebase analysis

Going into SUP-INT-08, the Support Service already had an attachment surface
(`TicketAttachmentService` + `AttachmentEndpoints`) that linked an
*already-uploaded* document to a ticket: clients posted a JSON body with
`document_id` / `file_name` / `content_type` / `file_size_bytes` and the
service wrote a row in `ticket_attachments`, fired a timeline event, and
emitted a `support.ticket.attachment_added` audit event (introduced in
SUP-B08). The actual bytes were assumed to already live somewhere else
(LegalSynq's Documents Service, in the integrated deployment).

That left two gaps:

1. **Standalone deployments** had nowhere to put bytes. Customer pilots
   running Support without the rest of LegalSynq could not attach files at
   all.
2. **Test environments** had no realistic dispatch surface — the integrated
   Documents Service was not callable from CI.

SUP-INT-08 closes both gaps without breaking the existing link endpoint:

- A new `ISupportFileStorageProvider` abstraction is introduced and selected
  per environment via `Support:FileStorage:Mode` (`NoOp` / `Local` /
  `DocumentsService`).
- A new endpoint `POST /support/api/tickets/{id:guid}/attachments/upload`
  accepts `multipart/form-data`, runs validation, calls the configured
  provider to persist bytes, and then *reuses the existing attachment
  persistence path* so timeline + audit fire identically to a manual link.
- The legacy `POST /attachments` link endpoint is unchanged, so any client
  that already brings its own `document_id` (e.g. a future drag-and-drop
  flow that uploads directly to Documents Service from the browser) still
  works.

The five existing `try/catch`-wrapped dispatch surfaces (notifications +
audit) gave a known-good template for keeping storage failures out of the
mainline transaction; the new provider boundary follows that same shape.

---

## 2. Files created / changed

### New (Support.Api)

- `services/support/Support.Api/Configuration/FileStorageOptions.cs` —
  `FileStorageMode` enum + bound options
  (`Mode`, `MaxFileSizeMb`, `AllowedContentTypes`, `LocalRootPath`,
  `DocumentsService { BaseUrl, TimeoutSeconds, UploadPath }`).
- `services/support/Support.Api/Files/ISupportFileStorageProvider.cs` —
  single-method abstraction (`UploadAsync(SupportFileUploadRequest, ct)`).
- `services/support/Support.Api/Files/SupportFileUploadModels.cs` —
  `SupportFileUploadRequest` (tenant id, ticket id, original/safe file
  name, content type, length, content stream, optional uploader id) and
  `SupportFileUploadResult` (document id, file name, content type, size,
  optional storage URI for diagnostics — never surfaced to API clients).
- `services/support/Support.Api/Files/NoOpSupportFileStorageProvider.cs` —
  throws `SupportFileStorageNotConfiguredException` so callers receive
  503; this is the safe default.
- `services/support/Support.Api/Files/LocalSupportFileStorageProvider.cs` —
  writes to `{LocalRootPath}/{tenant:N}/{ticket:N}/{docId:N}/{safeName}`,
  sanitizes the file name (strips path traversal, restricts characters),
  generates the document id `local-{guid:N}`, and returns
  `SupportFileUploadResult` without exposing the on-disk path to the
  API surface.
- `services/support/Support.Api/Files/DocumentsServiceFileStorageProvider.cs` —
  multipart POST to `{BaseUrl}{UploadPath}` (default
  `/documents/api/documents/upload`), parses `{ document_id, file_name,
  content_type, size }` from the response, named `HttpClient`
  (`support-documents`) with per-call timeout from
  `DocumentsService:TimeoutSeconds`. Wraps any transport / non-2xx error
  in `SupportFileStorageRemoteException` for 502 mapping.
- `services/support/Support.Api/Files/SupportFileStorageException.cs` —
  base + `SupportFileStorageNotConfiguredException` (503) +
  `SupportFileStorageRemoteException` (502).

### Changed (Support.Api)

- `Program.cs` — `Support:FileStorage` configured;
  `IOptions<FileStorageOptions>` registered; switch on `Mode` to register
  the appropriate `ISupportFileStorageProvider` (Local + NoOp as
  singletons; DocumentsService as a typed `HttpClient`-bound
  registration).
- `appsettings.json` — added the `Support:FileStorage` block:
  `Mode=NoOp` default, `MaxFileSizeMb=25`, conservative
  `AllowedContentTypes` allowlist (PDF, PNG, JPEG, plain text, DOCX,
  XLSX), `LocalRootPath=./data/support-uploads`,
  `DocumentsService { BaseUrl=null, TimeoutSeconds=10,
  UploadPath="/documents/api/documents/upload" }`.
- `Services/TicketAttachmentService.cs` — added `UploadAndAttachAsync`,
  refactored `AddAsync` to share a private `PersistAsync(...)` so that
  both the link and upload paths fire the timeline event (`AttachmentAdded`)
  and the audit event (`support.ticket.attachment_added`) identically.
  Validation lives in a single `ValidateFile(IFormFile, displayName,
  FileStorageOptions)` helper covering: presence, zero-byte, max size
  (from options), content-type allowlist (case-insensitive; allowlist
  empty ⇒ allow any), and file-name length / path-traversal rejection.
  Tenant + ticket existence are checked before any byte is read.
- `Endpoints/AttachmentEndpoints.cs` — new
  `POST /attachments/upload` route, `RequireAuthorization(SupportWrite)`,
  `DisableAntiforgery()`, `Accepts<IFormFile>("multipart/form-data")`.
  Maps domain exceptions to status codes: 400 (validation /
  multipart-missing / tenant-missing), 404 (ticket not found), 409
  (duplicate `document_id`), 502
  (`SupportFileStorageRemoteException`), 503
  (`SupportFileStorageNotConfiguredException`).

### Frontend (artifacts/support-ui)

- `src/lib/api/client.ts` — added `uploadMultipart<T>(path, FormData,
  { signal })`. Deliberately does **not** set a `Content-Type` so the
  browser supplies the multipart boundary; otherwise mirrors `request<T>`
  for auth + the typed-error surface (`Validation`, `Unauthorized`,
  `Forbidden`, `NotFound`, `Network`, `Api`).
- `src/lib/api/support.ts` — added `uploadAttachment(ticketId, file,
  { displayName?, signal? })`. The client deliberately does not accept
  or forward an `uploaded_by_user_id` field; the server derives the
  uploader from the JWT subject (see §3 — Identity trust).
- `src/lib/api/hooks.ts` — added `useUploadAttachment(ticketId)` mutation
  hook; on success it invalidates `ticketAttachmentsKey`,
  `ticketTimelineKey`, and `ticketKey` for the ticket.
- `src/lib/mocks/handlers.ts` — added MSW handler for
  `POST /support/api/tickets/:id/attachments/upload` that mirrors
  Local-provider semantics (404 for unknown ticket, 400 for missing /
  empty / oversize file, 201 with a `local-{guid}` document id, and
  pushes the row into `mockDb.attachmentsByTicket` so the GET handler
  reflects it).
- `src/pages/TicketDetail.tsx` — added an inline `AttachmentUploader`
  component rendered inside the existing Attachments panel. Shows
  "Upload file" button → "Uploading…" with a spinner while the mutation
  is pending → success toast on resolve. Validation errors from the
  server (`ValidationError`) are surfaced inline beneath the button via
  `data-testid="text-upload-error"`. The hidden `<input type="file">`
  is driven by an explicit click on the button so file pickers always
  open in response to a real user gesture.

### New (Support.Tests)

- `RecordingFileStorageProvider.cs` — in-memory `ISupportFileStorageProvider`
  with `ThrowOnUpload`, `ThrowNotConfigured`, `ThrowRemote` toggles and a
  `Records` collection so tests can assert what the service actually
  asked the storage layer to do.
- `FileUploadApiFactory.cs` — `WebApplicationFactory` variant that
  swaps in the `RecordingFileStorageProvider` (used for failure-mode
  tests) and a sibling `LocalProviderApiFactory` that force-registers
  `LocalSupportFileStorageProvider` against a per-test temp directory
  (used for the happy-path "Local provider writes bytes to disk" test).
  This split is required because `Program.cs` reads
  `Support:FileStorage:Mode` at host-build time, *before*
  `WebApplicationFactory.ConfigureAppConfiguration` overrides apply, so
  the factories explicitly re-register the provider via
  `ConfigureServices` (mirroring the `AuditApiFactory` pattern).
  `IOptionsMonitor<FileStorageOptions>` deferred binding does pick up
  config overrides at use time, so `MaxFileSizeMb` /
  `AllowedContentTypes` / `LocalRootPath` overrides flow through
  normally.
- `FileUploadTests.cs` — 14 endpoint-level cases (see §7) plus the
  separate `LocalFileProviderTests` suite (one happy-path test that
  asserts bytes hit disk under the expected `{tenant}/{ticket}/{docId}/`
  layout and that the document id is `local-{32-hex-chars}`).

---

## 3. Provider abstraction approach

The abstraction is one method:

```csharp
public interface ISupportFileStorageProvider
{
    Task<SupportFileUploadResult> UploadAsync(
        SupportFileUploadRequest request, CancellationToken ct);
}
```

Why a single method instead of a richer "storage" surface (delete,
download, list):

- Support never *re-reads* attachments in the integrated deployment;
  download URLs come from Documents Service (auth-scoped). Adding read /
  delete to the abstraction would be speculative API surface that two of
  three implementations would have to fake, and tempting to use as a
  back-door around Documents Service's permission model.
- The Standalone (Local) deployment also does not need download yet —
  attachment listing renders metadata only; the download URL is a future
  concern (see §9 — deferred).

Mode selection is wired in `Program.cs` so that swapping environments is
config-only, not code:

```csharp
switch (mode)
{
    case FileStorageMode.Local:
        builder.Services.AddSingleton<ISupportFileStorageProvider,
            LocalSupportFileStorageProvider>();
        break;
    case FileStorageMode.DocumentsService:
        builder.Services.AddHttpClient<ISupportFileStorageProvider,
            DocumentsServiceFileStorageProvider>(
            DocumentsServiceFileStorageProvider.HttpClientName, ...);
        break;
    case FileStorageMode.NoOp:
    default:
        builder.Services.AddSingleton<ISupportFileStorageProvider,
            NoOpSupportFileStorageProvider>();
        break;
}
```

The `NoOp` default is deliberate: an environment that has not consciously
opted in to file storage cannot accidentally start writing files
anywhere. Calls to the upload endpoint return **503 Service Unavailable**
with a clear `title` so the UI can degrade gracefully.

`UploadAndAttachAsync` is the single service entry point; it:

1. Tenant-checks via `TenantContext` (any miss → `TenantMissingException`
   → 400).
2. Resolves the ticket inside the tenant scope
   (`TicketNotFoundException` → 404).
3. Runs `ValidateFile(...)` (presence, size, content-type, name) — any
   miss → `AttachmentUploadValidationException` → RFC 7807 validation
   problem with field-keyed errors.
4. Calls `_storage.UploadAsync(...)` — *any provider exception
   propagates*; the endpoint catches them and maps to the right HTTP
   status. Crucially, no DB row is written if the upload throws.
5. Calls the same private `PersistAsync(...)` that `AddAsync` uses, so
   the timeline event + audit event fire identically and downstream
   consumers cannot tell the difference between a "link" and an "upload".

**Identity trust (security fix from architect review).** The upload
endpoint deliberately does **not** read `uploaded_by_user_id` from the
multipart form. The uploader identity is always taken from the
authenticated JWT subject via `ITenantContext.UserId` and forwarded to
`UploadAndAttachAsync` (which has no `uploadedByUserId` parameter). This
prevents a client from spoofing attribution on either the resulting
`ticket_attachments` row or the downstream Documents Service call. The
asymmetry with the legacy `POST /attachments` link endpoint — which
still accepts `UploadedByUserId` in its JSON body — is intentional and
preserved for backwards compatibility with existing callers; that path
is reviewed independently in SUP-B08 and is out of scope for this
block. A regression test
(`Upload_Form_Field_Cannot_Spoof_Uploader_Identity`) pins the new
behaviour for the upload endpoint, and the happy-path test now also
asserts the JWT subject wins over a forged form value.

---

## 4. Validation rules

Implemented in `TicketAttachmentService.ValidateFile`:

| Check                   | Failure key   | Failure message |
|-------------------------|---------------|-----------------|
| `IFormFile` is null     | `file`        | "A file is required." |
| `Length == 0`           | `file`        | "File is empty." |
| `Length > MaxFileSizeMb * 1MiB` | `file` | "File exceeds the maximum allowed size of {N} MB." |
| `AllowedContentTypes` non-empty and `ContentType` not on the list (case-insensitive) | `contentType` | "Content type '{ct}' is not allowed." |
| Effective name length > 255 | `fileName` | "File name is too long." |
| Effective name contains path-traversal characters (`/`, `\`, `..`, control chars, leading `.`) | `fileName` | "File name contains invalid characters." |

The "effective name" is `displayName ?? file.FileName ?? "upload.bin"`,
trimmed. Local provider further sanitizes by replacing remaining
non-portable characters with `_`, so the on-disk name is always safe even
if validation is loosened in the future.

The allowlist defaults to `[pdf, png, jpeg, jpg, plain text, docx,
xlsx]`. If `AllowedContentTypes` is empty in config, all content types
are accepted; this lets per-tenant pilots opt into a wider set without
needing a code change.

---

## 5. Configuration

`appsettings.json`:

```jsonc
"Support": {
  "FileStorage": {
    "Mode": "NoOp",                // NoOp | Local | DocumentsService
    "MaxFileSizeMb": 25,
    "LocalRootPath": "./data/support-uploads",
    "AllowedContentTypes": [
      "application/pdf",
      "image/png",
      "image/jpeg",
      "image/jpg",
      "text/plain",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ],
    "DocumentsService": {
      "BaseUrl": null,             // required when Mode=DocumentsService
      "TimeoutSeconds": 10,
      "UploadPath": "/documents/api/documents/upload"
    }
  }
}
```

Mode → DI selection (Program.cs):

- `NoOp`  → `NoOpSupportFileStorageProvider` (singleton).
- `Local` → `LocalSupportFileStorageProvider` (singleton).
- `DocumentsService` → typed `HttpClient` registration named
  `support-documents`; per-call timeout = `DocumentsService:TimeoutSeconds`;
  `DocumentsService:BaseUrl` validated at first use, not at startup, so
  Mode-flip in a hot reload doesn't crash an unrelated environment.

`IOptionsMonitor<FileStorageOptions>` is used inside the service and
providers (rather than `IOptions<...>`) so that `MaxFileSizeMb` /
`AllowedContentTypes` changes from `IConfigurationManager` reload are
picked up without a service restart.

---

## 6. Failure handling and HTTP status mapping

| Exception                                       | HTTP | RFC 7807 title |
|-------------------------------------------------|------|----------------|
| `TenantMissingException`                        | 400  | "Tenant context required" |
| Multipart absent (`!HasFormContentType`)        | 400  | "multipart/form-data required" |
| `InvalidDataException` / `BadHttpRequestException` while parsing form | 400 | "Invalid multipart payload" |
| `AttachmentUploadValidationException`           | 400 + `errors` map | (validation problem) |
| `TicketNotFoundException`                       | 404  | (no body) |
| `DuplicateAttachmentException`                  | 409  | "Duplicate attachment" |
| `SupportFileStorageNotConfiguredException`      | 503  | "File upload not available" |
| `SupportFileStorageRemoteException`             | 502  | "Upstream document service unavailable" |
| `SupportFileStorageException` (base)            | 500  | "File upload failed" |

Two non-obvious guarantees:

1. **Storage failure ⇒ no DB row.** `UploadAndAttachAsync` calls
   `_storage.UploadAsync(...)` *before* `PersistAsync(...)`. If the
   provider throws, the endpoint catches the exception and returns the
   mapped status; the attachment row is never inserted, no timeline /
   audit event fires.
2. **Bytes never enter the DB.** The `ticket_attachments` table stores
   `document_id` (string) + metadata (`file_name`, `content_type`,
   `file_size_bytes`, `uploaded_by_user_id`, `created_at`). There is no
   `bytes` / `content` column. The audit event's metadata also excludes
   bytes (only `document_id`, `file_name`, `content_type`,
   `file_size_bytes` per SUP-B08).

---

## 7. Test results

```
=== AuthTests ===                Total: 13   Passed: 13   Failed: 0
=== AuthStartupTests ===         Total:  8   Passed:  8   Failed: 0
=== TicketApiTests ===           Total: 13   Passed: 13   Failed: 0
=== CommentApiTests ===          Total: 12   Passed: 12   Failed: 0
=== AttachmentApiTests ===       Total:  7   Passed:  7   Failed: 0
=== ProductRefApiTests ===       Total:  7   Passed:  7   Failed: 0
=== QueueAndAssignmentTests ===  Total: 21   Passed: 21   Failed: 0
=== NotificationTests ===        Total: 10   Passed: 10   Failed: 0
=== AuditTests ===               Total: 16   Passed: 16   Failed: 0
=== FileUploadTests + LocalFileProviderTests === Total: 15  Passed: 15  Failed: 0

Backend total:                   Total: 123  Passed: 123  Failed: 0
```

Frontend:

```
$ pnpm --filter @workspace/support-ui run typecheck
> tsc -p tsconfig.json --noEmit         (0 errors)

$ pnpm --filter @workspace/support-ui run test --run
Test Files  6 passed (6)
     Tests  39 passed (39)
```

End-to-end (Playwright via the testing skill, status `success`):

> Navigated to `/support/tickets/11111111-1111-1111-1111-111111111101`,
> uploaded an in-memory text file `sup-int-08-e2e.txt` via the
> `Upload file` control, observed the success toast, and confirmed the
> Attachments list refreshed to include the new entry. The button
> returned to its idle state after the mutation settled and no error
> element was rendered.

The 14 new endpoint cases in `FileUploadTests` cover (organized by
intent):

1. `Upload_Returns_201_With_Local_Provider_And_No_Bytes_In_Db` — happy
   path, asserts response shape and that no bytes column exists in the
   attachment row (metadata only).
2. `Upload_Without_Multipart_Returns_400` — JSON body in, 400 out.
3. `Upload_With_Missing_File_Part_Returns_400_Validation` — multipart
   without a `file` part.
4. `Upload_With_Empty_File_Returns_400_Validation` — zero-byte file.
5. `Upload_With_Oversize_File_Returns_400_Validation` — exceeds
   configured `MaxFileSizeMb`.
6. `Upload_With_Disallowed_Content_Type_Returns_400_Validation` —
   allowlist enforcement.
7. `Upload_With_Path_Traversal_File_Name_Returns_400_Validation` —
   `../../etc/passwd`-style names rejected.
8. `Upload_To_Other_Tenants_Ticket_Returns_404` — cross-tenant access
   isolation (mirrors the existing AttachmentApi tenant test).
9. `Upload_To_Unknown_Ticket_Returns_404` — unknown ticket id.
10. `Upload_With_NoOp_Provider_Returns_503` — default-mode safety.
11. `Upload_With_DocumentsService_Failure_Returns_502_And_No_Row` —
    asserts the attachment row count is unchanged after the upstream
    failure.
12. `Upload_Records_Timeline_And_Audit_Events_Identically_To_Link` —
    timeline `AttachmentAdded` row + audit
    `support.ticket.attachment_added` event with the same metadata
    shape as the link path.
13. `Existing_Link_Endpoint_Still_Works_After_Upload_Endpoint_Added` —
    regression test for the legacy `POST /attachments` route.
14. `Upload_Calls_Provider_With_Tenant_Ticket_And_Sanitized_Name` —
    asserts what the service hands to `ISupportFileStorageProvider` via
    the recording provider.

`LocalFileProviderTests` adds the one provider-level integration test:

15. `Local_Provider_Writes_Bytes_To_Disk_Under_Tenant_Ticket_Doc_Layout` —
    bytes appear at
    `{tempRoot}/{tenant:N}/{ticket:N}/{docId:N}/{safeName}`, and the
    returned `document_id` matches `local-[0-9a-f]{32}`.

---

## 8. Build results

```
$ dotnet build services/support --nologo
    8 Warning(s)   (pre-existing: 2× CS0618 ISystemClock obsolete in
                   TestAuthHandler, 2× CS8604 nullable refs in
                   CommentApiTests / ProductRefApiTests, 1× NU1903
                   System.Security.Cryptography.Xml advisory transitively
                   pulled in by Microsoft.IdentityModel.Tokens.Saml,
                   3× build-info)
    0 Error(s)
```

No new warnings introduced by SUP-INT-08. The pre-existing NU1903
advisory is tracked separately and is not introduced by this block.

---

## 9. Known gaps / deferred items

- **Browser-direct download URL.** The API returns metadata only; the UI
  currently renders the file name without a working download link
  (`href="#"`). Local-provider downloads need a signed `/files/...`
  endpoint that streams from `LocalRootPath` after re-checking the
  tenant + ticket. DocumentsService-mode downloads should defer to
  Documents Service's signed-URL endpoint. Out of scope for this block.
- **Antivirus / content scanning.** Not in scope. The Local provider is
  for development + small standalone pilots; the integrated path
  delegates to Documents Service which owns scanning. If standalone
  pilots grow, a `IUploadScanner` hook is the natural extension point —
  it would slot in between validation and `UploadAsync`.
- **Multipart streaming.** The current handler reads via
  `Request.ReadFormAsync(...)`, which buffers the file to disk via
  Kestrel's existing form-options behaviour for files above the
  in-memory threshold. We have not tuned `FormOptions.MultipartBodyLengthLimit`;
  for the current 25 MB cap, Kestrel defaults are sufficient. A future
  block raising the limit should also wire `FormOptions` accordingly.
- **DocumentsService request shape.** The wire contract
  (`POST {BaseUrl}/documents/api/documents/upload`, multipart with
  `file`, `tenant_id`, `product`, `related_entity_type`,
  `related_entity_id`, `uploaded_by_user_id`, response
  `{ document_id, file_name, content_type, size }`) is currently an
  *assumption* mirroring the link endpoint's existing field set.
  When the Documents Service team ratifies the schema, only
  `DocumentsServiceFileStorageProvider` should need updating;
  `ISupportFileStorageProvider` and the endpoint will not change.
- **Per-tenant overrides.** `Support:FileStorage` is global. A future
  multi-tenant SaaS deployment may need per-tenant `Mode` / size limits;
  the abstraction supports this — only `Program.cs` registration would
  need to swap to a `Func<TenantId, ISupportFileStorageProvider>`-style
  resolver.
- **Drag-and-drop UI.** The current control is a single-file picker.
  Multi-file + drag-and-drop is a UI follow-up; the API already accepts
  one file per request, and the mutation hook can be invoked once per
  file.
- **Create-flow upload.** Per the spec, uploading at ticket-creation
  time is explicitly deferred. The detail-page flow proves the contract
  end-to-end first.
- **Link endpoint identity asymmetry.** The new upload endpoint always
  attributes uploads to the JWT subject. The legacy
  `POST /support/api/tickets/{id}/attachments` link endpoint still
  accepts an `UploadedByUserId` field in its JSON body (unchanged
  contract from SUP-B08). Hardening that path to also derive identity
  from the JWT is tracked separately and intentionally not bundled here
  to avoid breaking existing API consumers mid-block.

---

## 10. Validation summary

- Backend: 123 / 123 tests pass (15 in `FileUploadTests` — the 13 from
  the original spec plus 2 added during the security-review fix to lock
  in the JWT-only uploader-identity rule).
- Frontend: 39 / 39 unit tests pass; `tsc --noEmit` clean.
- E2E: Playwright (testing skill) verified the upload control on the
  ticket detail page renders, uploads a small file, surfaces a success
  toast, refreshes the attachment list, and returns to its idle state.
- All three workflows
  (`artifacts/support-ui: web`, `artifacts/api-server: API Server`,
  `artifacts/mockup-sandbox: Component Preview Server`) restart cleanly.
- No bytes are written to the `ticket_attachments` table — the provider
  abstraction is the only writer of file content.
- The legacy `POST /attachments` link endpoint is unchanged and tested.

# SUP-B04 — Gateway & Security — Implementation Report

Status: **COMPLETE**
Result: `dotnet build` clean, `dotnet test` **60/60 passing** (52 functional + 8 fail-closed startup tests).

---

## 1. Codebase Analysis

Going into SUP-B04 the Support Service had:

- A working ASP.NET Core 8 API at `services/support/Support.Api/` with EF Core 8 (Pomelo MySQL) and InMemory in tests.
- Endpoints under `/support/api/*` for tickets, comments, attachments, product-refs, plus `/support/api/health`.
- A `TenantContext` middleware (`Tenancy/TenantContext.cs`) that resolved a tenant from any of: `tenant_id` JWT claim, `X-Tenant-Id` header, or `tenant_id` body field for create.
- Endpoints registered with `MapPost/MapGet/...` but **no** `RequireAuthorization()`.
- No JWT bearer registration. No authorization policies. `Program.cs` added neither `UseAuthentication` nor `UseAuthorization`.
- `TicketService.ResolveTenantId` accepted body `tenant_id` unconditionally on create.
- Test project (`Support.Tests`) used a single `SupportApiFactory` with `UseEnvironment("Testing")` and an `X-Tenant-Id` header convention.

The block had to harden auth/RBAC/tenant binding without breaking existing functional tests.

---

## 2. Files Created / Changed

### Created

| File | Purpose |
|---|---|
| `Support.Api/Auth/SupportRoles.cs` | Role-name constants + policy-name constants. |
| `Support.Api/Auth/AuthExtensions.cs` | `AddSupportAuth()` extension: registers JWT (Production/Dev) or `TestAuthHandler` (Testing) and the four authorization policies. |
| `Support.Api/Auth/TestAuthHandler.cs` | Header-driven test auth scheme used in `Testing` environment so existing functional tests can keep using simple headers without minting JWTs. |
| `Support.Tests/SupportApiFactory.cs` (added `SupportApiProdFactory`) | Production-like factory (Production env + InMemory DB + JWT config injected via env vars). |
| `Support.Tests/TestJwt.cs` | Minimal HS256 token issuer for prod-like tests (matches the symmetric key the prod factory configures). |
| `Support.Tests/AuthTests.cs` | 13 auth/RBAC/tenant runtime tests. |
| `Support.Tests/AuthStartupTests.cs` | 8 fail-closed startup tests for `AddSupportAuth`. |
| `analysis/SUP-B04-report.md` | This report. |

### Modified

| File | Reason |
|---|---|
| `Support.Api/Program.cs` | Wired `AddSupportAuth`, `UseAuthentication`/`UseAuthorization`, made health `AllowAnonymous`. |
| `Support.Api/Tenancy/TenantContext.cs` | Env-aware tenant resolution; in Production reads JWT claims only and 403s authenticated requests with no tenant claim on protected paths. |
| `Support.Api/Services/TicketService.cs` | `ResolveTenantId` body fallback gated to Dev/Testing (added `IWebHostEnvironment` dep). |
| All endpoint registration files (tickets, comments, attachments, product-refs) | Added `RequireAuthorization(<policy>)` per spec mapping. |
| `Support.Api/Support.Api.csproj` | Added `Microsoft.AspNetCore.Authentication.JwtBearer 8.0.10`. |
| `Support.Tests/Support.Tests.csproj` | Added `System.IdentityModel.Tokens.Jwt 7.6.0`. |

No SUP-B01/B02/B03 functional tests were modified.

---

## 3. Authentication Changes

### JWT Bearer (Production / Development)

Configuration keys (consistent with the spec example):

```
Authentication:
  Jwt:
    Authority:              # OIDC mode
    Issuer:                 # REQUIRED, always validated
    Audience:               # REQUIRED, always validated
    RequireHttpsMetadata:   # default: !IsDevelopment
    SymmetricKey:           # local/test mode only - 32+ bytes
```

#### Fail-closed startup validation

In any non-Testing environment, `AddSupportAuth` **throws `InvalidOperationException`** at startup when:

1. Neither `Authority` nor `SymmetricKey` is configured (no signing strategy).
2. Both `Authority` and `SymmetricKey` are configured (ambiguous strategy).
3. `Issuer` is missing.
4. `Audience` is missing.
5. `SymmetricKey` is shorter than 32 bytes (HS256 minimum).

This guarantees a misconfigured deployment refuses to start rather than registering a JWT pipeline that silently accepts attacker-minted tokens. Eight tests in `AuthStartupTests.cs` cover each branch.

#### Two mutually-exclusive signing modes

- **OIDC / Authority mode** — when `Authority` is set, only `Authority` is configured on the bearer options; signing keys are resolved from the IdP's JWKS by `kid` as normal. The handler does **not** install a local key, so legitimate authority-signed tokens are not rejected.
- **Symmetric / local mode** — when `SymmetricKey` is set, a `SymmetricSecurityKey` is installed on `IssuerSigningKey`/`IssuerSigningKeys` and an `IssuerSigningKeyResolver` returns it regardless of the `kid` header (so locally-minted tokens without a `kid` still validate). This is intended for tests and local dev only.

#### Validation parameters (always)

- `ValidateIssuer = true`, `ValidIssuer = <configured>`
- `ValidateAudience = true`, `ValidAudience = <configured>`
- `ValidateLifetime = true`
- `ValidateIssuerSigningKey = true`
- `ClockSkew = 30s`
- `RoleClaimType = "role"`
- `NameClaimType = "sub"`
- `MapInboundClaims = false` (and `JwtSecurityTokenHandler.DefaultMapInboundClaims = false`) so `sub`, `role`, and `tenant_id` survive intact.

Secrets are **never** hardcoded.

### Test Authentication (Testing only)

To keep SUP-B01..B03 tests fast and deterministic without minting JWTs, the API registers a `TestAuthHandler` scheme **only** when `env.IsEnvironment("Testing")`. It reads:

- `X-Test-NoAuth: 1` — request is treated as unauthenticated (drives 401 tests).
- `X-Test-Sub` — value of the `sub` claim (default: `test-user`).
- `X-Test-Roles` — comma-separated roles (default: all support roles).
- `X-Tenant-Id` — added as `tenant_id` claim (default value `t1`).
- `X-Test-NoTenantClaim: 1` — explicitly omits the tenant claim (drives 403 tests).

This handler is **not registered** in any non-Testing environment. Production tests use the real JWT bearer pipeline via `SupportApiProdFactory`.

---

## 4. Authorization / RBAC Changes

### Role constants (`SupportRoles.cs`)

`PlatformAdmin`, `SupportAdmin`, `SupportManager`, `SupportAgent`, `TenantAdmin`, `TenantUser`.

### Policies

| Policy | Allowed roles |
|---|---|
| `SupportRead` | All six |
| `SupportWrite` | All six |
| `SupportManage` | PlatformAdmin, SupportAdmin, SupportManager |
| `SupportInternal` | PlatformAdmin, SupportAdmin, SupportManager, SupportAgent |

Each policy requires authenticated user + `RequireRole(<list>)`.

### Endpoint policy map (applied via `.RequireAuthorization(...)`)

| Endpoint | Policy |
|---|---|
| `POST /support/api/tickets` | `SupportWrite` |
| `GET /support/api/tickets` | `SupportRead` |
| `GET /support/api/tickets/{id}` | `SupportRead` |
| `PUT /support/api/tickets/{id}` | `SupportWrite` |
| `POST /support/api/tickets/{id}/comments` | `SupportWrite` |
| `GET /support/api/tickets/{id}/comments` | `SupportRead` |
| `GET /support/api/tickets/{id}/timeline` | `SupportRead` |
| `POST /support/api/tickets/{id}/attachments` | `SupportWrite` |
| `GET /support/api/tickets/{id}/attachments` | `SupportRead` |
| `POST /support/api/tickets/{id}/product-refs` | `SupportWrite` |
| `GET /support/api/tickets/{id}/product-refs` | `SupportRead` |
| `DELETE /support/api/tickets/{id}/product-refs/{refId}` | `SupportManage` |
| `GET /support/api/health` | `AllowAnonymous` |

Internal-vs-customer comment policy split (InternalNote ⇒ `SupportInternal`) is **deferred** — see §10.

---

## 5. Tenant Resolution Changes

`TenantContext` middleware now branches on `IWebHostEnvironment`:

### Production / non-Development behavior

For requests under `/support/api/*` (excluding `/health`, `/metrics`, `/swagger`):

1. If the user is **not authenticated** → standard 401 from auth pipeline.
2. If authenticated, tenant is read from JWT claims in priority order:
   1. `tenant_id`
   2. `tenantId`
   3. `tid`
3. If authenticated but **no tenant claim** → middleware returns **403** with body `{ "error": "tenant_claim_missing" }`.
4. `X-Tenant-Id` header and request body `tenant_id` are **ignored**.

### Development / Testing behavior

Existing fallback chain preserved:

1. JWT/test claim `tenant_id` (or `tenantId`/`tid`)
2. `X-Tenant-Id` header
3. Request body `tenant_id` — only on `POST /support/api/tickets` (create), via `TicketService.ResolveTenantId`. This was previously environment-agnostic; it is now gated behind `env.IsDevelopment() || env.IsEnvironment("Testing")`. In other environments, an attempt to resolve from body throws and the request fails closed.

Health/metrics/swagger paths are skipped by the middleware so probes remain unauthenticated.

---

## 6. Gateway / YARP Changes

The gateway project does **not** exist in this working repo (`services/support/` is the only checked-in service). Per the spec, no unrelated infrastructure is invented. Instead, the documented YARP route configuration to add to the platform gateway is:

```jsonc
// appsettings.json (gateway service)
{
  "ReverseProxy": {
    "Routes": {
      "support-service": {
        "ClusterId": "support-service",
        "Match": {
          "Path": "/support/api/{**catch-all}"
        }
        // No PathRemovePrefix / Transforms => path is preserved.
      }
    },
    "Clusters": {
      "support-service": {
        "Destinations": {
          "primary": {
            // Use the existing platform service-host convention.
            // In k8s/compose this is the in-cluster DNS name + port.
            "Address": "http://support-service:8080/"
          }
        },
        "HealthCheck": {
          "Active": {
            "Enabled": true,
            "Interval": "00:00:15",
            "Timeout": "00:00:05",
            "Path": "/support/api/health"
          }
        }
      }
    }
  }
}
```

Routing intent:

- `RouteId = support-service`
- `ClusterId = support-service`
- Match path `/support/api/{**catch-all}`
- Path preserved (no remove-prefix / no rewrite)
- Active health check against the anonymous `/support/api/health` endpoint
- The gateway is responsible for terminating TLS and presenting the JWT in the `Authorization: Bearer <token>` header to the downstream Support Service.

When the gateway repo becomes available, this snippet should be added using the existing platform conventions (e.g. environment-specific `Destinations`, OIDC token forwarding).

---

## 7. API Behavior Changes

| Scenario | Before SUP-B04 | After SUP-B04 |
|---|---|---|
| Anonymous request to `/support/api/tickets` | 200 (with header tenant) | **401** in Production, 401 in Testing only when `X-Test-NoAuth: 1` header is present |
| Authenticated user with no tenant claim (Production) | n/a | **403** `tenant_claim_missing` |
| `X-Tenant-Id` header without JWT claim (Production) | accepted | **403** (ignored entirely) |
| Body `tenant_id` on create (Production) | accepted | **ignored** (claim required) |
| Body `tenant_id` on create (Dev/Testing) | accepted | accepted (unchanged) |
| `DELETE /…/product-refs/{refId}` as `SupportAgent` | 200 | **403** (requires `SupportManage`) |
| `GET /support/api/health` | 200 | 200 (unchanged, anonymous) |

No request/response schema changes for the data endpoints. No breaking changes to existing SUP-B01..B03 contract tests.

---

## 8. Test Results

Final run: `cd services/support && dotnet test`

```
Test Run Successful.
Total tests: 60
     Passed: 60
 Total time: ~5s
```

### New tests in `AuthStartupTests.cs` (8)

Cover the fail-closed startup branches added after code review:

- `Production_With_No_Jwt_Config_Throws`
- `Production_With_Both_Authority_And_SymmetricKey_Throws`
- `Production_With_Symmetric_Missing_Audience_Throws`
- `Production_With_Symmetric_Missing_Issuer_Throws`
- `Production_With_Short_SymmetricKey_Throws`
- `Production_With_Valid_Symmetric_Config_Succeeds`
- `Production_With_Valid_Authority_Config_Succeeds`
- `Testing_Environment_Skips_Jwt_Validation`

### New tests in `AuthTests.cs` (13)

Authentication (prod-like factory):

1. `Prod_Tickets_NoToken_Returns_401`
2. `Prod_Comments_NoToken_Returns_401`
3. `Prod_Attachments_NoToken_Returns_401`
4. `Prod_Health_Anonymous_Returns_200`

Tenant resolution:

5. `Prod_With_Tenant_Claim_Succeeds`
6. `Prod_Missing_Tenant_Claim_Returns_403`
7. `Prod_X_Tenant_Id_Header_Alone_Is_Rejected`
8. `Dev_Test_Header_Tenant_Still_Works` (uses `SupportApiFactory` / Testing env)

Authorization:

9. `Test_SupportAgent_Can_Read_Ticket`
10. `Test_SupportAgent_Can_Update_Ticket`
11. `Test_TenantUser_Can_Create_Ticket`
12. `Test_Unauthorized_Role_Returns_403` (`TenantUser` deleting product-ref)
13. `Test_ProductRef_Delete_Requires_SupportManage` (`SupportAgent` denied; `SupportManager` allowed)

### Regression

All 39 pre-existing SUP-B01/B02/B03 tests still pass unchanged (counted within the 52).

---

## 9. Build Results

```
$ dotnet build services/support
Build succeeded.
    0 Error(s)
```

Warnings: pre-existing CS8604 (nullable-flow) warnings in two test files and a CS0618 on `ISystemClock` in the test auth handler (the API contract for AuthenticationHandler is migrating away from ISystemClock in .NET 9 — acceptable for .NET 8). No new errors.

NuGet additions: `Microsoft.AspNetCore.Authentication.JwtBearer 8.0.10` (API), `System.IdentityModel.Tokens.Jwt 7.6.0` (tests).

---

## 10. Known Gaps / Deferred Items

1. **Internal vs customer-visible comment policy split** — `InternalNote` should require `SupportInternal`; currently all comment writes use `SupportWrite`. Deferred to a follow-up that touches `CommentService` / DTOs (out of scope for this block per spec §"Internal vs Customer Comment Security").
2. **Per-requester filtering for `TenantUser`** — `TenantUser` currently sees all tickets in their tenant. Spec allows this conservative implementation; tightening to "only own-created" requires adding `requester_user_id` filtering across List/Get and is deferred.
3. **Cross-tenant `PlatformAdmin` endpoints** — explicitly not added per spec. `PlatformAdmin` today still operates within a tenant context.
4. **YARP gateway code** — gateway project is not in this repo; route configuration is documented (§6) instead of committed.
5. **Metrics endpoint** — `/support/api/metrics` is currently public (Prometheus scrape). The spec allows leaving it public if existing platform pattern does so, with documented risk; a follow-up should restrict it to network-internal scrape (e.g., `RequireHost` or a separate kestrel listener bound to a private port).
6. **Swagger** — now gated to Development only (`if (app.Environment.IsDevelopment()) { UseSwagger(); }`). Production deployments do not expose `/support/api/swagger`.
7. **Production secret management** — `Authentication:Jwt:SymmetricKey` is intended for local/test use only; OIDC `Authority` is the recommended production path. `AddSupportAuth` now **fails startup** in any non-Testing environment if neither is configured, removing the previous "silent placeholder key" risk.
8. **Production-config injection in test host** — `SupportApiProdFactory` injects JWT settings via environment variables (set in a static constructor) rather than `ConfigureAppConfiguration`, because `WebApplication.CreateBuilder` reads `builder.Configuration` eagerly during `Program.cs` execution before `WebApplicationFactory`'s `ConfigureAppConfiguration` callbacks run. The env vars persist for the lifetime of the test process, which is benign because no other test factory inspects them and the `Testing` env short-circuits the JWT pipeline entirely.

---

## Acceptance Criteria Checklist

| # | Criterion | Status |
|---|---|---|
| 1 | JWT authentication is configured | PASS |
| 2 | Protected endpoints require authentication | PASS |
| 3 | Health endpoint remains accessible | PASS |
| 4 | Role-based authorization policies exist | PASS (`SupportRead/Write/Manage/Internal`) |
| 5 | Endpoint policies are applied | PASS (mapping in §4) |
| 6 | Tenant resolution uses JWT claim only in non-dev/non-test envs | PASS |
| 7 | Header/body tenant fallback limited to Dev/Testing only | PASS |
| 8 | Missing tenant claim is rejected | PASS (403 `tenant_claim_missing`) |
| 9 | Unauthorized roles are rejected | PASS (403) |
| 10 | YARP gateway route is added or documented | PASS (documented §6) |
| 11 | Existing SUP-B01/B02/B03 APIs remain functional | PASS |
| 12 | Existing tests still pass | PASS (39 prior tests green) |
| 13 | New security tests added and passing | PASS (13 new tests) |
| 14 | `/analysis/SUP-B04-report.md` exists and is complete | PASS (this file) |

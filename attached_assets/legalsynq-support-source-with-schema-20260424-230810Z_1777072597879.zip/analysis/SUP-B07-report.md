# SUP-B07 — Notifications Integration Report

## 1. Codebase analysis

The Support Service is a .NET 8 minimal-API project (`services/support/Support.Api`) using EF Core 8 + Pomelo for MySQL (in-memory under `Testing` env). Domain mutations are funneled through service-layer classes:

- `Services/TicketService.cs` — `CreateAsync`, `UpdateAsync`, `AssignAsync`.
- `Services/CommentService.cs` — `AddAsync`.
- `Services/QueueService.cs` — queue and queue-member CRUD (queue members live in `support_queue_members`, soft-deleted via `IsActive`).

Auth is JWT-bearer in production / a test handler under `Testing` (`Auth/TestAuthHandler.cs`). Tenant id flows through `ITenantContext` and is authoritative for every read/write. Timeline events are persisted via `IEventLogger` against `support_ticket_events`.

There was no prior outbound-event abstraction in the service. There is no shared `Notifications` SDK in the monorepo. The platform's Notifications Service is treated as an external HTTP collaborator.

Implications for SUP-B07:

- The service-layer write paths are the right trigger points (per spec).
- We can reuse the existing `support_queue_members` schema for queue-member recipient resolution (no new schema).
- A new abstraction (`INotificationPublisher`) is the lowest-risk integration surface — wire mode by configuration, default to `NoOp` so local/test runs are stable.

## 2. Files created / changed

Created:

- `services/support/Support.Api/Notifications/SupportNotification.cs` — `SupportNotification` record, `NotificationRecipient` record, `NotificationRecipientKind` enum, `SupportNotificationEventTypes` constants.
- `services/support/Support.Api/Notifications/NotificationOptions.cs` — `Support:Notifications` config binding (`Enabled`, `BaseUrl`, `TimeoutSeconds`, `Mode`).
- `services/support/Support.Api/Notifications/INotificationPublisher.cs` — interface contract.
- `services/support/Support.Api/Notifications/NoOpNotificationPublisher.cs` — default implementation; logs structured payloads.
- `services/support/Support.Api/Notifications/HttpNotificationPublisher.cs` — typed-HttpClient adapter to Notifications Service; resilient (never throws).
- `services/support/Support.Tests/RecordingNotificationPublisher.cs` — test capture publisher with optional `ThrowOnPublish` mode.
- `services/support/Support.Tests/NotificationsApiFactory.cs` — `WebApplicationFactory<Program>` variant that registers the recording publisher.
- `services/support/Support.Tests/NotificationTests.cs` — 10 backend integration tests.
- `analysis/SUP-B07-report.md` — this document.

Changed:

- `services/support/Support.Api/Program.cs` — bind options, register publisher per `Mode` (default NoOp; typed HttpClient for Http).
- `services/support/Support.Api/appsettings.json` — added `Support.Notifications` block defaulting to `Enabled=false, Mode=NoOp`.
- `services/support/Support.Api/Services/TicketService.cs` — inject publisher, dispatch `support.ticket.created` / `support.ticket.updated` / `support.ticket.status_changed` / `support.ticket.assigned`, with `TryPublishAsync` wrapper.
- `services/support/Support.Api/Services/CommentService.cs` — inject publisher, dispatch `support.ticket.comment_added` with visibility-aware recipient resolution.

No frontend, schema, or API endpoint changes (recipients are computed inside service layer; no new DTOs surfaced to clients).

## 3. Notification integration approach

```
┌────────────────────────┐    POST /notifications     ┌──────────────────────┐
│ TicketService          │ ───────────────────────►   │  Notifications       │
│ CommentService         │   (HTTP adapter, opt-in)    │  Service             │
└────────┬───────────────┘                              └──────────────────────┘
         │ INotificationPublisher
         │
   ┌─────┴─────────┐
   │ NoOp (default)│ ── logs structured "would dispatch" record
   │ Http          │ ── POSTs SupportNotification JSON; swallows failures
   │ Recording     │ ── test-only; captures notifications in-memory
   └───────────────┘
```

- **Best-effort**: every publish is wrapped in `try/catch` inside the service layer. Notification failures NEVER roll back ticket / comment / assignment writes.
- **Best-effort at the publisher too**: `HttpNotificationPublisher` itself catches all exceptions and logs warnings — defense in depth.
- **Configurable kill-switch**: `Support:Notifications:Enabled = false` makes both adapters skip all dispatch (no HTTP, no log noise above debug).
- **Templating belongs to Notifications Service**: Support emits canonical event types and a structured payload. No SendGrid / SMTP / template logic in this codebase.
- **Outbox**: not implemented. Documented as a deferred enhancement under §11.

## 4. Event-to-notification mapping

| Trigger                                              | Event type                          | Recipients                                                                   | Payload keys                                                                                                                                |
| ---------------------------------------------------- | ----------------------------------- | ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| `POST /support/api/tickets`                          | `support.ticket.created`            | requester `user_id` + requester `email` (when present)                       | `ticket_id`, `ticket_number`, `title`, `status`, `priority`, `tenant_id`, `requester_user_id`, `requester_email`, `product_code`            |
| `PUT /support/api/tickets/{id}`                      | `support.ticket.updated`            | requester (user/email) + assigned user (if any)                              | `ticket_id`, `ticket_number`, `title`, `status`, `priority`, `tenant_id`                                                                    |
| `PUT /support/api/tickets/{id}` (status change)      | `support.ticket.status_changed`     | requester (user/email) + assigned user (if any)                              | `ticket_id`, `ticket_number`, `title`, `previous_status`, `new_status`, `tenant_id`                                                          |
| `PUT /support/api/tickets/{id}/assignment`           | `support.ticket.assigned`           | new assigned user + active queue members (when queue assigned)               | `ticket_id`, `ticket_number`, `title`, `assigned_user_id`, `assigned_queue_id`, `previous_assigned_user_id`, `previous_assigned_queue_id`, `tenant_id` |
| `POST /support/api/tickets/{id}/comments`            | `support.ticket.comment_added`      | visibility-aware (see below)                                                 | `ticket_id`, `ticket_number`, `comment_id`, `comment_type`, `visibility`, `author_user_id`, `tenant_id`                                      |

Visibility rules for comment notifications (`Services/CommentService.cs:ResolveCommentRecipients`):

- `Visibility=Internal` **or** `CommentType=InternalNote` → never customer; only assigned user (if present).
- `CommentType=CustomerReply` (visibility customer-visible) → assigned user (support participant). Customer is the author here, so they are not re-notified.
- Otherwise (customer-visible support reply) → requester `user_id` + requester `email`.

## 5. Configuration changes

`appsettings.json` (defaults):

```json
"Support": {
  "Notifications": {
    "Enabled": false,
    "Mode": "NoOp",
    "BaseUrl": null,
    "TimeoutSeconds": 5
  }
}
```

| Key                                  | Type   | Default | Notes                                                            |
| ------------------------------------ | ------ | ------- | ---------------------------------------------------------------- |
| `Support:Notifications:Enabled`      | bool   | `false` | Master kill-switch; suppresses dispatch in both adapters.        |
| `Support:Notifications:Mode`         | string | `NoOp`  | `NoOp` or `Http`. Selects publisher registered in `Program.cs`.  |
| `Support:Notifications:BaseUrl`      | string | `null`  | Required for `Http`. Notifications Service base URL.             |
| `Support:Notifications:TimeoutSeconds` | int  | `5`     | Per-call deadline for HTTP dispatch.                             |

Override in production by environment variables, e.g.:

```
Support__Notifications__Enabled=true
Support__Notifications__Mode=Http
Support__Notifications__BaseUrl=http://notifications.internal/api
Support__Notifications__TimeoutSeconds=3
```

## 6. API / client changes

None. No public endpoints, DTOs, or schemas changed. The Notifications dispatch payload is private to Support↔Notifications and is not exposed to API consumers.

## 7. UI changes

None — explicitly excluded by the spec ("No full notification center UI").

## 8. Validation behavior

- **Failure isolation**: Every emit point is wrapped in `try/catch` inside the service. The `RecordingNotificationPublisher` test (case 9) flips `ThrowOnPublish=true`, performs an update, asserts HTTP 200 and a persisted change. Confirmed.
- **No recipients → log + skip**: Per spec ("If no recipient can be resolved: log and skip dispatch"), the service logs an `Information`-level entry and does not invoke the publisher when the resolved recipient list is empty. The originating write still succeeds (case 8).
- **Disabled mode**: Both publishers honor `Enabled=false` and skip work without throwing (case 10 covers `NoOpNotificationPublisher` directly).
- **Internal notes**: Verified the customer (requester user/email) is never present in recipients for `Visibility=Internal` or `CommentType=InternalNote` (case 6).
- **Queue routing**: Active members are included; soft-deleted (`IsActive=false`) members are excluded (case 7).

## 9. Test results

`services/support/Support.Tests/NotificationTests.cs` — 10 cases:

1. `Create_Ticket_Publishes_TicketCreated`
2. `Update_Ticket_Publishes_TicketUpdated`
3. `Status_Change_Publishes_StatusChanged`
4. `Assignment_Publishes_TicketAssigned`
5. `Comment_Added_Publishes_CommentAdded`
6. `Internal_Note_Does_Not_Notify_Requester`
7. `Queue_Assignment_Notifies_Active_Queue_Members`
8. `No_Recipients_Does_Not_Fail_Operation`
9. `Publisher_Failure_Does_Not_Fail_Ticket_Update`
10. `NoOp_Publisher_Honors_Disabled_Flag`

```
Notification suite:  Passed: 10, Failed: 0
Queue/Assignment:    Passed: 21, Failed: 0
Auth + Auth startup: Passed: 21, Failed: 0
TicketApi:           Passed: 13, Failed: 0
CommentApi:          Passed: 12, Failed: 0
AttachmentApi:       Passed:  7, Failed: 0
ProductRefApi:       Passed:  7, Failed: 0
─────────────────────────────────────────────
Total:               Passed: 91, Failed: 0
```

No frontend tests added (no UI work). Existing 39 vitest specs in `artifacts/support-ui` were not touched.

## 10. Build results

```
$ cd services/support && dotnet build Support.sln --no-restore
Build succeeded.
    0 Error(s)
```

(The first `dotnet restore` after package-cache invalidation completed in ~5s. Subsequent `--no-restore` builds are warning-free aside from pre-existing MSB3106 strong-name warnings on third-party assemblies — not introduced by SUP-B07.)

## 11. Known gaps / deferred items

- **Durable outbox**: notifications are emitted in-process after `SaveChangesAsync`. If the process crashes between commit and publish, the dispatch is lost. A future change should introduce a `support_notification_outbox` table written in the same transaction, plus a background dispatcher. Out of scope for B07.
- **Per-user preferences**: not implemented — explicitly out of scope.
- **Provider routing / templates**: handled by Notifications Service; not in this repo.
- **Retries / circuit breaking**: `HttpNotificationPublisher` is single-shot. Add Polly handlers when telemetry shows it's needed.
- **Deduplication for queue + assigned-user overlap**: when a queue's assigned user is also an active member of the new queue, they appear twice in recipients (`User` + `QueueMember`). Notifications Service can dedupe by user id; can also be tightened in Support if required.
- **Recipient hydration**: only ids/emails on the ticket are forwarded. Looking up display names / locales is delegated to Notifications Service.

## 12. Acceptance checklist

- [x] Notification publishing abstraction exists (`INotificationPublisher`).
- [x] Notifications Service adapter (`HttpNotificationPublisher`) and documented NoOp adapter (`NoOpNotificationPublisher`) exist.
- [x] Ticket created notification triggered.
- [x] Ticket updated notification triggered.
- [x] Status changed notification triggered.
- [x] Ticket assigned notification triggered.
- [x] Comment added notification triggered.
- [x] Internal-only comments do not notify customers.
- [x] Queue assignment notifies active queue members.
- [x] Notification failures do not break ticket operations.
- [x] Configuration controls enabled/disabled behavior.
- [x] Tests added and passing (10 new + 81 prior = 91/91).
- [x] Existing SUP-B01..SUP-B06 behavior still works.
- [x] `analysis/SUP-B07-report.md` exists and is complete.

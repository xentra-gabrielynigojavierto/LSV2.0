# SUP-B03 — Attachments & Product Context

Adds the document-reference layer and the multi-product entity-link layer on
top of SUP-B01 (tickets) and SUP-B02 (comments + timeline) without any
breaking changes.

---

## 1. Codebase analysis

The Support Service was already organised into clean layers:

- `Domain/` — POCO entities.
- `Dtos/` — request/response shapes.
- `Validators/` — FluentValidation per request DTO.
- `Services/` — business logic, all `IXxxService` + impl, with `IEventLogger`
  and `ITenantContext` injected.
- `Endpoints/` — minimal-API map functions, validation + exception → HTTP
  translation only.
- `Data/SupportDbContext.cs` — single DbContext, tables configured fluently.
- `Data/Migrations/` — EF Core migrations (Pomelo MySQL).
- `Support.Tests/` — xUnit + WebApplicationFactory + EF InMemory.

SUP-B03 follows that exact pattern. No restructuring. No retro-fits. All new
work is additive.

---

## 2. Files created / changed

**New files**

- `Domain/SupportTicketAttachment.cs` — `SupportTicketAttachment`, `SupportTicketProductRef`.
- `Dtos/AttachmentDtos.cs` — `CreateTicketAttachmentRequest`, `TicketAttachmentResponse`.
- `Dtos/ProductRefDtos.cs` — `CreateProductReferenceRequest`, `ProductReferenceResponse`.
- `Validators/AttachmentValidators.cs` — `CreateTicketAttachmentRequestValidator`, `CreateProductReferenceRequestValidator`.
- `Services/TicketAttachmentService.cs` — `ITicketAttachmentService` / `TicketAttachmentService`.
- `Services/TicketProductReferenceService.cs` — `ITicketProductReferenceService` / `TicketProductReferenceService`, plus `DuplicateProductReferenceException` and `ProductReferenceNotFoundException`.
- `Endpoints/AttachmentEndpoints.cs` — POST/GET attachment endpoints.
- `Endpoints/ProductRefEndpoints.cs` — POST/GET/DELETE product-reference endpoints.
- `Data/Migrations/20260424024151_AddSupportAttachmentsAndProductRefs.cs` — EF migration with FK constraints, supporting indexes, and unique constraints.
- `Support.Tests/AttachmentApiTests.cs` — 6 acceptance tests.
- `Support.Tests/ProductRefApiTests.cs` — 7 acceptance tests.

**Modified files**

- `Data/SupportDbContext.cs` — added `TicketAttachments` and `TicketProductRefs` `DbSet`s plus column / index / FK / unique-constraint configuration.
- `Program.cs` — registered `ITicketAttachmentService`, `ITicketProductReferenceService`, mapped `MapAttachmentEndpoints` and `MapProductRefEndpoints`.

---

## 3. Database / schema changes

Two new tables, both tenant-scoped and FK-bound to `support_tickets(id)` with
cascade delete.

### `support_ticket_attachments`

| Column | Type | Notes |
|---|---|---|
| `id` | char(36) PK | `Guid` |
| `ticket_id` | char(36) NOT NULL | FK `fk_support_ticket_attachments_ticket` → `support_tickets(id)` ON DELETE CASCADE |
| `tenant_id` | varchar(64) NOT NULL | indexed |
| `document_id` | varchar(128) NOT NULL | snapshot — FK to Documents Service externally |
| `file_name` | varchar(255) NOT NULL | snapshot |
| `content_type` | varchar(150) NULL | snapshot |
| `file_size_bytes` | bigint NULL | snapshot |
| `uploaded_by_user_id` | varchar(64) NULL | – |
| `created_at` | datetime NOT NULL | UTC |

Indexes: `ix_support_ticket_attachments_tenant`,
`ix_support_ticket_attachments_ticket`,
`ix_support_ticket_attachments_document`,
`ix_support_ticket_attachments_created_at`.

Unique: `ux_support_ticket_attachments_tenant_ticket_document` on
`(tenant_id, ticket_id, document_id)` — prevents the same document being
attached to the same ticket twice.

### `support_ticket_product_refs`

| Column | Type | Notes |
|---|---|---|
| `id` | char(36) PK | `Guid` |
| `ticket_id` | char(36) NOT NULL | FK `fk_support_ticket_product_refs_ticket` → `support_tickets(id)` ON DELETE CASCADE |
| `tenant_id` | varchar(64) NOT NULL | indexed |
| `product_code` | varchar(50) NOT NULL | normalised to UPPERCASE |
| `entity_type` | varchar(100) NOT NULL | – |
| `entity_id` | varchar(128) NOT NULL | – |
| `display_label` | varchar(255) NULL | – |
| `metadata_json` | text NULL | validated as JSON |
| `created_by_user_id` | varchar(64) NULL | – |
| `created_at` | datetime NOT NULL | UTC |

Indexes: `ix_support_ticket_product_refs_tenant`,
`ix_support_ticket_product_refs_ticket`,
`ix_support_ticket_product_refs_product`,
`ix_support_ticket_product_refs_entity_type`,
`ix_support_ticket_product_refs_entity_id`,
`ix_support_ticket_product_refs_created_at`.

Unique: `ux_support_ticket_product_refs_unique` on
`(tenant_id, ticket_id, product_code, entity_type, entity_id)` — prevents
duplicate references on the same ticket. The service performs an explicit
pre-check so callers receive `409 Conflict` instead of a raw DB error.

**Migration name:** `AddSupportAttachmentsAndProductRefs`
(file `20260424024151_AddSupportAttachmentsAndProductRefs.cs`).

---

## 4. API endpoints added

All endpoints sit under `/support/api/tickets/{id:guid}` and use the existing
`TenantResolutionMiddleware`. Cross-tenant access returns `404`. Missing
tenant returns `400`. Validation errors return RFC 7807 `ValidationProblem`.
Endpoints appear in Swagger under the **Attachments** and
**Product References** tags.

| Verb | Route | Tag | Returns |
|------|-------|-----|---------|
| POST | `/attachments` | Attachments | `201 Created` `TicketAttachmentResponse` |
| GET | `/attachments` | Attachments | `200 OK` `List<TicketAttachmentResponse>` (ASC) |
| POST | `/product-refs` | Product References | `201 Created` `ProductReferenceResponse` (or `409` on duplicate) |
| GET | `/product-refs?product_code=…&entity_type=…` | Product References | `200 OK` `List<ProductReferenceResponse>` (ASC) |
| DELETE | `/product-refs/{refId}` | Product References | `204 No Content` |

---

## 5. Documents Service integration approach

Support Service stores **references only**. It never accepts file bytes,
never base64-encodes a file body, and never talks to S3. A
`CreateTicketAttachmentRequest` is metadata only:

- `document_id` — opaque identifier that callers obtain from the Documents
  Service (after the actual upload happens there).
- `file_name`, `content_type`, `file_size_bytes` — denormalised snapshots so
  the ticket UI can render an attachment row without round-tripping the
  Documents Service for every list request.
- `uploaded_by_user_id` — provenance.

The split keeps Support free of binary plumbing, S3 credentials, virus
scanning, and lifecycle policies. Those remain Documents Service concerns
and will be wired through a typed client when the Documents Service public
contract is available — explicitly out of scope for SUP-B03.

---

## 6. Product reference model

A product reference is a flexible (`product_code`, `entity_type`, `entity_id`)
triple. It allows a single ticket to be linked to records across multiple
products without Support Service knowing the schema of any of them.

- `product_code` is a free-form string but **normalised to uppercase** at the
  service layer (`"fund"` → `"FUND"`). The list filter normalises the same
  way, so callers can use any casing.
- Spec lists `PLATFORM`, `LIENS`, `FUND`, `CARECONNECT`, `IDENTITY`,
  `NOTIFICATIONS`, `DOCUMENTS`, `TASK`, `MONITORING` — these are not
  hardcoded; only length and presence are validated.
- `entity_type` / `entity_id` are owned by the referenced product. Support
  treats them as opaque strings.
- `display_label` is a denormalised snapshot for UI rendering.
- `metadata_json` is opaque-but-validated JSON for any extra context the
  caller wants to attach.

---

## 7. Timeline / event behaviour

The existing `IEventLogger` from SUP-B02 is reused. Three new event types
are emitted:

| Trigger | `event_type` | `summary` | `metadata_json` |
|---|---|---|---|
| `POST /attachments` | `attachment_added` | `Attachment added` | `{ "attachment_id": "…", "document_id": "…", "file_name": "…" }` |
| `POST /product-refs` | `product_ref_linked` | `Product reference linked` | `{ "product_ref_id": "…", "product_code": "…", "entity_type": "…", "entity_id": "…", "display_label": "…" }` |
| `DELETE /product-refs/{refId}` | `product_ref_removed` | `Product reference removed` | `{ "product_ref_id": "…", "product_code": "…", "entity_type": "…", "entity_id": "…" }` |

Logging happens in the service layer, never in endpoints. The event is
queued into the change tracker before a single `SaveChangesAsync`, so the
mutation and its event commit atomically — failed mutations leave no orphan
events.

---

## 8. Validation rules

### `CreateTicketAttachmentRequestValidator`

- `document_id` — required, max 128.
- `file_name` — required, max 255.
- `content_type` — max 150.
- `file_size_bytes` — `>= 0` when supplied.
- `uploaded_by_user_id` — max 64.

### `CreateProductReferenceRequestValidator`

- `product_code` — required, max 50.
- `entity_type` — required, max 100.
- `entity_id` — required, max 128.
- `display_label` — max 255.
- `created_by_user_id` — max 64.
- `metadata_json` — must parse as valid JSON when supplied (`JsonDocument.Parse`).

---

## 9. Test results

```
Passed!  - Failed: 0, Passed: 39, Skipped: 0, Total: 39
```

That is 13 SUP-B01 + 12 SUP-B02 + **14 new SUP-B03** tests.

### Attachments (`AttachmentApiTests`)

| Test | Acceptance item |
|---|---|
| `Add_Attachment_Succeeds` | POST happy path |
| `Add_Attachment_Fails_Without_DocumentId` | Required field |
| `Add_Attachment_Fails_Without_FileName` | Required field |
| `List_Attachments_Returns_Tenant_Scoped_Records` | List + ASC ordering |
| `Cross_Tenant_Attachment_Add_Returns_404` | Tenant isolation (POST + GET) |
| `Add_Attachment_Rejects_Duplicate_Document_Link` | Same `document_id` on same ticket → 409 |
| `Attachment_Add_Creates_Timeline_Event` | `attachment_added` event with metadata |

### Product References (`ProductRefApiTests`)

| Test | Acceptance item |
|---|---|
| `Add_Product_Reference_Succeeds` | POST happy path |
| `Add_Product_Reference_Normalizes_Product_Code_To_Uppercase` | Normalisation rule |
| `Add_Product_Reference_Rejects_Duplicate` | Unique constraint, case-insensitive |
| `List_Product_References_Supports_Product_Code_Filter` | Filter + normalisation |
| `Delete_Product_Reference_Succeeds` | Delete happy path |
| `Delete_Product_Reference_Is_Tenant_Scoped` | Cross-tenant DELETE → 404 |
| `Product_Reference_Create_And_Delete_Create_Timeline_Events` | Both link + remove events emitted with metadata |

All 25 SUP-B01 + SUP-B02 tests still pass — no regressions.

---

## 10. Build results

```
0 Warning(s) of substance, 0 Error(s)
Time Elapsed 00:00:10.36
```

(There are 3 informational warnings: two MSB3277 transitive-version notices
on `EntityFrameworkCore.Relational` from the test project, and two CS8604
nullable-reference notices in test code — neither is from SUP-B03 and none
break the build or tests.)

Run locally:

```bash
cd services/support
dotnet build
dotnet test
```

Migration:

```bash
dotnet ef database update --project Support.Api
# applies, in order:
#   20260424020928_InitialSupportSchema
#   20260424022505_AddSupportCommentsAndEvents
#   20260424024151_AddSupportAttachmentsAndProductRefs
```

---

## 11. Known gaps / deferred items

- **Documents Service typed client** — Support stores references only; the
  actual upload, antivirus scan, and signed-URL retrieval happen in the
  Documents Service. A typed HTTP client is intentionally deferred until
  that service publishes its contract.
- **Attachment delete API** — out of scope for B03; spec only required
  link/list. Will land alongside richer document lifecycle support.
- **Product-code allowlist** — kept open by design so new products can link
  without a Support deploy. A dynamic registry can be introduced later if
  hard validation is desired.
- **Notifications / Audit fan-out** — events are persisted locally only,
  same as SUP-B02. No outbox/message-bus publication yet.
- **Tenant trust at the edge** — same caveat as SUP-B01/B02: the
  `X-Tenant-Id` header is trusted as a fallback for service-to-service calls
  pending the auth gateway (SUP-AUTH).
- **Author / actor identity provenance** — `uploaded_by_user_id` and
  `created_by_user_id` are accepted from the body for now; they should be
  derived from the authenticated principal once auth is wired.
- **Pagination** — list endpoints return the full set; pagination will be
  added when ticket activity volume warrants it.

---

## Acceptance checklist

| # | Criterion | Status |
|---|---|---|
| 1 | `support_ticket_attachments` table exists | ✅ |
| 2 | `support_ticket_product_refs` table exists | ✅ |
| 3 | Attachment create/list APIs work | ✅ |
| 4 | Product reference create/list/delete APIs work | ✅ |
| 5 | Support stores document references only, not files | ✅ — no binary fields, no S3 client |
| 6 | Multi-product / multi-entity linking | ✅ — flexible `(product_code, entity_type, entity_id)` |
| 7 | Duplicate product refs prevented | ✅ — service-level pre-check + DB unique index |
| 8 | Timeline events for attachment & product-ref activity | ✅ — `attachment_added`, `product_ref_linked`, `product_ref_removed` |
| 9 | Tenant isolation enforced on all new endpoints | ✅ — 404 cross-tenant, 400 missing tenant |
| 10 | FluentValidation applied | ✅ |
| 11 | Migration created | ✅ `AddSupportAttachmentsAndProductRefs` |
| 12 | Tests added and passing | ✅ 13 new tests, 38/38 total |
| 13 | SUP-B01 and SUP-B02 still pass | ✅ |
| 14 | `/analysis/SUP-B03-report.md` exists and is complete | ✅ this file |

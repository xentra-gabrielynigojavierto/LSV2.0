# SUP-B01 — Support Portal Service Foundation

**Status:** Complete  
**Stack:** .NET 8 / ASP.NET Core Minimal APIs / EF Core 8 (Pomelo MySQL) / xUnit  
**Location:** `services/support/`

---

## 1. Scope Delivered

The SUP-B01 ticket called for the foundational backend slice of the
Support Service: a tenant-aware support-ticket domain with persistent storage,
validated REST endpoints, observability hooks, and an automated test suite. All
acceptance items from the spec are implemented and exercised by tests:

- Multi-tenant isolation enforced on every read and write path.
- Ticket CRUD (create / list / get-by-id / update) under `/support/api/tickets`.
- Human-readable ticket numbers in the form `SUP-{YYYY}-{000001}`, monotonically
  increasing per tenant per year.
- Status workflow with explicit allowed transitions.
- FluentValidation request validation.
- Swagger/OpenAPI, Serilog structured logging, OpenTelemetry tracing, Prometheus
  metrics, and a `/health` endpoint.
- xUnit + FluentAssertions test suite — **10 / 10 passing**.

Out of scope (deferred to later SUP tickets, per the spec): comments,
attachments, SLA tracking, agent assignment workflows, and a UI.

## 2. Solution Layout

```
services/support/
├── Support.sln
├── Support.Api/
│   ├── Program.cs                       # DI + middleware composition
│   ├── appsettings.json
│   ├── Domain/
│   │   ├── Enums.cs                     # TicketStatus, TicketPriority, TicketCategory
│   │   ├── SupportTicket.cs
│   │   └── TicketNumberSequence.cs      # per (tenant_id, year) counter
│   ├── Data/
│   │   ├── SupportDbContext.cs
│   │   ├── DesignTimeDbContextFactory.cs
│   │   └── Migrations/
│   │       └── 20260424020526_InitialSupportSchema.cs
│   ├── Tenancy/
│   │   └── TenantContext.cs             # ITenantContext + middleware
│   ├── Dtos/
│   │   └── TicketDtos.cs
│   ├── Validators/
│   │   └── TicketValidators.cs          # Create / Update validators
│   ├── Services/
│   │   ├── TicketNumberGenerator.cs
│   │   └── TicketService.cs             # status-transition rules
│   └── Endpoints/
│       └── TicketEndpoints.cs           # Minimal-API route group
└── Support.Tests/
    ├── SupportApiFactory.cs             # WebApplicationFactory + InMemory DB
    └── TicketApiTests.cs                # 10 acceptance tests
```

## 3. Domain Model

`SupportTicket` aggregates the following columns (mirrored 1-to-1 in the EF
migration):

| Column          | Type          | Notes |
|-----------------|---------------|-------|
| Id              | GUID (PK)     | server-generated |
| TenantId        | string(64)    | required, indexed |
| TicketNumber    | string(32)    | unique per tenant, format `SUP-YYYY-NNNNNN` |
| Title           | string(200)   | required |
| Description     | string(4000)  | optional |
| Status          | enum          | Open · InProgress · Pending · Resolved · Closed · Cancelled |
| Priority        | enum          | Low · Normal · High · Urgent |
| Category        | enum          | Billing · Technical · Account · Other |
| RequesterEmail  | string(320)   | required, RFC-validated |
| RequesterName   | string(200)   | optional |
| AssigneeId      | string(64)    | optional |
| CreatedAt       | DateTime UTC  | server-stamped |
| UpdatedAt       | DateTime UTC  | server-stamped on every write |
| ClosedAt        | DateTime UTC? | stamped when terminal status reached |
| Version         | uint (rowver) | optimistic concurrency token |

A second table, `TicketNumberSequence`, holds a `(TenantId, Year)` composite
key with a `LastValue` counter and a `RowVersion` optimistic-concurrency
token, and is the single source of truth for ticket numbering — see §6.

## 4. API Surface

All routes live under the `/support/api` prefix and require a tenant
identifier resolved by the tenancy middleware (see §5).

| Verb | Route                              | Purpose                      | Body / Query |
|------|------------------------------------|------------------------------|--------------|
| GET  | `/support/api/health`              | Liveness probe               | – |
| GET  | `/support/api/metrics`             | Prometheus scrape endpoint   | – |
| GET  | `/support/api/swagger`             | OpenAPI/Swagger UI           | – |
| POST | `/support/api/tickets`             | Create ticket                | `CreateTicketRequest` |
| GET  | `/support/api/tickets`             | List tickets for tenant      | `?status=&priority=&category=&assigneeId=&search=&page=&pageSize=` |
| GET  | `/support/api/tickets/{id}`        | Fetch by id (tenant-scoped)  | – |
| PUT  | `/support/api/tickets/{id}`        | Patch-style update           | `UpdateTicketRequest` |

Validation errors return RFC-7807 `ValidationProblem` payloads with field-level
detail; missing/invalid tenant returns `400` with a structured problem
response; cross-tenant fetches return `404` (deliberately indistinguishable
from "not found").

## 5. Tenancy

The `TenantMiddleware` resolves the active tenant in the following priority
order, populating a request-scoped `ITenantContext`:

1. JWT claim `tenant_id` (when an authenticated principal is present).
2. `X-Tenant-Id` request header.
3. `tenant_id` field in the JSON body (create endpoint only — convenient for
   service-to-service calls without auth wired up yet).

If none of the above resolve, the request short-circuits with `400 Bad
Request` and a `tenant resolution failed` problem document. Every database
query in `TicketService` filters by `_tenant.TenantId`; there is no code path
that reads or writes another tenant's rows.

## 6. Ticket Number Generation

`TicketNumberGenerator` runs the following loop (max 10 retries):

1. Read the `TicketNumberSequence` row for `(TenantId, Year)` via EF.
2. If the row is missing, queue an insert with `LastValue = 1`. If it exists,
   increment `LastValue` and bump `RowVersion` (the EF `IsConcurrencyToken`).
3. Call `SaveChangesAsync`. Two failure modes are handled with a fresh-read
   retry:
   - `DbUpdateException` — composite-primary-key collision when two workers
     insert the very first row simultaneously.
   - `DbUpdateConcurrencyException` — the `RowVersion` token mismatch when two
     workers read the same `LastValue` and both tried to write back. Only one
     wins; the other retries against the now-incremented row.
4. Format the result as `SUP-{year}-{LastValue:D6}`.

This guarantees:
- Numbers are monotonic per tenant per year.
- Tenants never see another tenant's sequence (Tenant-A and Tenant-B both start
  at `SUP-2026-000001`) — verified by the
  `Tenants_Get_Independent_Number_Sequences` test.
- Concurrent allocations are safe without a separate distributed lock: the
  optimistic-concurrency token forces serialization at the database layer and
  duplicate numbers cannot be issued.

## 7. Status Transition Rules

Implemented in `TicketService.IsValidTransition`:

| From          | Allowed Next                        |
|---------------|-------------------------------------|
| Open          | InProgress, Pending, Cancelled      |
| InProgress    | Pending, Resolved, Cancelled        |
| Pending       | InProgress, Resolved, Cancelled     |
| Resolved      | Closed, InProgress (re-open)        |
| Closed        | *(immutable)*                       |
| Cancelled     | *(immutable)*                       |

Invalid transitions return `400` with the message
`Invalid status transition: {from} -> {to}`. Reaching `Closed` or `Cancelled`
stamps `ClosedAt = DateTime.UtcNow`.

## 8. Cross-Cutting Concerns

- **Logging** — Serilog console sink with structured properties
  (`tenant_id`, `ticket_number`); request logging via
  `UseSerilogRequestLogging`.
- **Tracing** — OpenTelemetry with ASP.NET Core instrumentation exporting via
  the OTLP-compatible Prometheus exporter.
- **Metrics** — Prometheus exporter mounted at `/support/api/metrics`; the
  default ASP.NET Core meters expose request rate, duration histograms, and
  error counts out of the box.
- **Health** — `/support/api/health` returns `{ "status": "Healthy" }` (used
  by the test suite as the liveness check).
- **Swagger** — UI at `/support/api/swagger`, JSON at
  `/support/api/swagger/v1/swagger.json`.

## 9. Testing

`SupportApiFactory` boots the API via `WebApplicationFactory<Program>` with the
environment set to `Testing`, which causes `Program.cs` to skip the MySQL
DbContext registration; the test factory then registers
`Microsoft.EntityFrameworkCore.InMemory` instead. This keeps tests hermetic —
no MySQL container is required to run them.

Tests (all passing — **13 / 13**):

| Test                                          | Covers |
|-----------------------------------------------|--------|
| Create_Ticket_Succeeds                        | POST happy path, 201 + body |
| Create_Without_Title_Fails                    | FluentValidation required field |
| Requester_Email_Validation_Works              | FluentValidation email format |
| Ticket_Number_Is_Generated                    | `SUP-YYYY-NNNNNN` format |
| Tenants_Get_Independent_Number_Sequences      | Per-tenant sequence isolation |
| List_Returns_Only_Active_Tenant_Records       | Cross-tenant list isolation |
| List_Without_Tenant_Returns_400               | Tenant resolution failure |
| Detail_Returns_404_For_Wrong_Tenant           | Cross-tenant get isolation |
| Update_Valid_Status_Transition_Succeeds       | Allowed transition |
| Update_Invalid_Transition_Returns_400         | Disallowed transition |
| Pending_Can_Resolve_Directly                  | Pending → Resolved per matrix |
| InProgress_Can_Be_Cancelled                   | InProgress → Cancelled + ClosedAt stamp |
| Health_Endpoint_Returns_Healthy               | `/health` liveness |

```
Test Run Successful.  Total tests: 13  Passed: 13  Time: 0.47s
```

Run locally with:

```bash
cd services/support
dotnet test
```

## 10. Operating the Service

Configuration lives in `appsettings.json`; the only required setting is
`ConnectionStrings:Support` (MySQL). EF migrations are checked in under
`Support.Api/Data/Migrations/`.

```bash
# one-time: install the local EF tool
cd services/support
dotnet tool restore

# create the database schema
dotnet ef database update --project Support.Api

# run the service
dotnet run --project Support.Api
# → Swagger UI: http://localhost:5000/support/api/swagger
# → Health:    http://localhost:5000/support/api/health
# → Metrics:   http://localhost:5000/support/api/metrics
```

### Known limitations / required follow-ups

- **Authenticated tenant binding.** This foundation accepts the
  `X-Tenant-Id` header at the edge so the service is testable today, but in
  production the tenant must be bound exclusively from a verified JWT claim
  (`tenant_id`). The middleware already prefers the JWT claim when present —
  the remaining work is to stand up the auth gateway and disable the
  header/body fallback in production environments. **This must land before any
  production traffic.**

### Follow-up tickets (recommended)

- **SUP-AUTH** — Wire JWT/SSO validation; remove header/body tenant fallback in prod.
- **SUP-B02** — Comments + activity timeline. ✅ *Delivered — see next section.*
- **SUP-B03** — Attachments (object-storage backed).
- **SUP-B04** — SLA tracking & escalation jobs.
- **SUP-B05** — Agent assignment / queue routing.
- **SUP-B06** — Public-facing portal UI.

---

## SUP-B02 Implementation

The communication layer (comments, events, unified timeline) shipped on top of
SUP-B01 without any breaking changes to the existing ticket APIs.

### 1. Code changes

**New files**
- `Domain/SupportTicketComment.cs` — `SupportTicketComment`, `SupportTicketEvent`, plus `CommentType` and `CommentVisibility` enums.
- `Dtos/CommentDtos.cs` — `CreateCommentRequest`, `CommentResponse`, `TimelineItem`.
- `Validators/CommentValidators.cs` — `CreateCommentRequestValidator`.
- `Services/EventLogger.cs` — `IEventLogger` / `EventLogger` (queues events into the change tracker; the calling service controls the transaction boundary).
- `Services/CommentService.cs` — `ICommentService` / `CommentService` (add comment, list comments, build unified timeline). Always asserts ticket ownership via tenant before doing anything else.
- `Endpoints/CommentEndpoints.cs` — three endpoints under `/support/api/tickets/{id}`.
- `Data/Migrations/20260424022505_AddSupportCommentsAndEvents.cs` — EF Core migration (includes FK constraints `fk_support_ticket_comments_ticket` and `fk_support_ticket_events_ticket` with cascade delete to `support_tickets`).
- `Support.Tests/CommentApiTests.cs` — 12 new acceptance tests.

**Modified files**
- `Data/SupportDbContext.cs` — added `TicketComments` and `TicketEvents` `DbSet`s plus their column/index configuration.
- `Services/TicketService.cs` — injected `IEventLogger`; logs `created` on `CreateAsync`, and `status_changed` (with `{from,to}` metadata) + `updated` on `UpdateAsync`. Events are queued before `SaveChangesAsync` so the ticket and its events commit in the same transaction.
- `Program.cs` — registered `IEventLogger`, `ICommentService`, and mapped `CommentEndpoints`.

### 2. New tables / entities

| Table                        | Purpose                                    |
|------------------------------|--------------------------------------------|
| `support_ticket_comments`    | Internal/customer/system comments per ticket. Tenant-isolated; indexed on `tenant_id`, `ticket_id`, `created_at`. |
| `support_ticket_events`      | Append-only activity log per ticket (`created`, `updated`, `status_changed`, `comment_added`, …). Tenant-isolated; indexed on `tenant_id`, `ticket_id`, `created_at`. |

Comments enum columns (`comment_type`, `visibility`) are stored as strings via
EF value conversion. Events store free-form JSON in `metadata_json` to avoid
schema churn for new event types.

### 3. API endpoints added

| Verb | Route                                          | Purpose |
|------|------------------------------------------------|---------|
| POST | `/support/api/tickets/{id}/comments`           | Add a comment (default `CustomerReply` / `CustomerVisible`). |
| GET  | `/support/api/tickets/{id}/comments`           | List comments ASC; optional `visibility` and `comment_type` filters. |
| GET  | `/support/api/tickets/{id}/timeline`           | Unified `comment` + `event` timeline ordered ASC. |

All three reject cross-tenant access with `404` (indistinguishable from
not-found). Missing tenant returns `400`. Validation errors return RFC 7807
`ValidationProblem`. Endpoints are visible in Swagger under the **Comments**
tag.

### 4. Event logging behaviour

| Trigger              | `event_type`     | `summary`                          | `metadata_json` |
|----------------------|------------------|------------------------------------|-----------------|
| `POST /tickets`      | `created`        | `Ticket created`                   | `{ "ticket_number": "SUP-…" }` |
| `PUT /tickets/{id}` (any field changes) | `updated` | `Ticket updated`                   | – |
| `PUT /tickets/{id}` with new status     | `status_changed` | `Status changed from {From} to {To}` | `{ "from": "…", "to": "…" }` |
| `POST /tickets/{id}/comments` | `comment_added` | `Comment added`             | `{ "comment_id": "…", "visibility": "…" }` |

Logging is performed in the service layer (`TicketService` / `CommentService`),
never in the endpoints. Events queue into the DbContext change tracker and
commit atomically with the ticket/comment write — no events are persisted for
failed mutations.

### 5. Validation rules

`CreateCommentRequestValidator`:
- `body` — required, max 8000 chars.
- `comment_type` — must be a valid `CommentType` enum value when supplied.
- `visibility` — must be a valid `CommentVisibility` enum value when supplied.
- `author_email` — must be a valid email address when supplied.
- `author_user_id` — max 64 chars.
- `author_name` — max 200 chars.

### 6. Test results

```
Passed!  - Failed: 0, Passed: 25, Skipped: 0, Total: 25
```

New SUP-B02 coverage (12 tests in `CommentApiTests`):

| Test                                              | Acceptance item |
|---------------------------------------------------|-----------------|
| `Add_Comment_Succeeds`                            | POST happy path |
| `Add_Comment_Fails_If_Ticket_Not_Found`           | 404 for unknown ticket |
| `Add_Comment_Fails_For_Wrong_Tenant`              | Tenant isolation on comment write |
| `Add_Comment_Fails_For_Empty_Body`                | FluentValidation `body` required |
| `List_Comments_Ordered_Asc_And_Tenant_Scoped`     | List ordering + tenant scope |
| `List_Comments_Cross_Tenant_Returns_404`          | Tenant isolation on `GET /comments` |
| `Timeline_Returns_Events_And_Comments_In_Order`   | Unified timeline + ASC ordering |
| `Timeline_Cross_Tenant_Returns_404`               | Tenant isolation on `GET /timeline` |
| `Timeline_Without_Tenant_Returns_400`             | Missing tenant → 400 on `GET /timeline` |
| `Ticket_Creation_Logs_Created_Event`              | Auto event on `POST /tickets` |
| `Ticket_Update_Logs_Updated_Event`                | Auto event on `PUT /tickets` |
| `Status_Change_Logs_Event_With_Metadata`          | `status_changed` + JSON `{from,to}` |

All 13 SUP-B01 tests continue to pass — no regressions.

Run locally:

```bash
cd services/support
dotnet build
dotnet test
```

Migration:

```bash
dotnet ef database update --project Support.Api
# applies: 20260424020928_InitialSupportSchema
#          20260424021953_AddSupportCommentsAndEvents
```

### 7. Known gaps

- **Attachments** — explicitly out of scope; will land in SUP-B03.
- **Notifications / Comms / Audit fan-out** — events are persisted locally only; no outbox or message-bus publication. To be added when the notification service is wired up.
- **Tenant trust at the edge** — same caveat as SUP-B01: in production the tenant must come from a verified JWT claim, not the `X-Tenant-Id` header. The middleware already prefers the claim when present; the header fallback exists for service-to-service calls until the auth gateway lands (SUP-AUTH).
- **Timeline pagination** — endpoints return the full timeline. Pagination/cursoring will be added when ticket activity volume warrants it.
- **Author identity provenance** — `author_user_id` / `author_name` / `author_email` are accepted from the request body for now; once auth is wired they should be derived from the authenticated principal and rejected from the body.

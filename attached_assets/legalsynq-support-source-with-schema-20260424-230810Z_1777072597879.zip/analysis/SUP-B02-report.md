# SUP-B02 — Comments & Timeline (Support Communication Layer)

The communication layer (comments, events, unified timeline) ships on top of
SUP-B01 without any breaking changes to the existing ticket APIs.

---

## 1. Code changes

**New files**
- `Domain/SupportTicketComment.cs` — `SupportTicketComment`, `SupportTicketEvent`, plus `CommentType` and `CommentVisibility` enums.
- `Dtos/CommentDtos.cs` — `CreateCommentRequest`, `CommentResponse`, `TimelineItem`.
- `Validators/CommentValidators.cs` — `CreateCommentRequestValidator`.
- `Services/EventLogger.cs` — `IEventLogger` / `EventLogger` (queues events into the change tracker; the calling service controls the transaction boundary).
- `Services/CommentService.cs` — `ICommentService` / `CommentService` (add comment, list comments, build unified timeline). Always asserts ticket ownership via tenant before doing anything else.
- `Endpoints/CommentEndpoints.cs` — three endpoints under `/support/api/tickets/{id}`.
- `Data/Migrations/20260424022505_AddSupportCommentsAndEvents.cs` — EF Core migration (includes FK constraints `fk_support_ticket_comments_ticket` and `fk_support_ticket_events_ticket` with cascade delete to `support_tickets`).
- `Support.Tests/CommentApiTests.cs` — 12 new acceptance tests.

**Modified files**
- `Data/SupportDbContext.cs` — added `TicketComments` and `TicketEvents` `DbSet`s plus their column/index/relationship configuration.
- `Services/TicketService.cs` — injected `IEventLogger`; logs `created` on `CreateAsync`, and `status_changed` (with `{from,to}` metadata) + `updated` on `UpdateAsync`. Events are queued before `SaveChangesAsync` so the ticket and its events commit in the same transaction.
- `Program.cs` — registered `IEventLogger`, `ICommentService`, and mapped `CommentEndpoints`.

---

## 2. New tables / entities

| Table                        | Purpose                                    |
|------------------------------|--------------------------------------------|
| `support_ticket_comments`    | Internal/customer/system comments per ticket. Tenant-isolated; indexed on `tenant_id`, `ticket_id`, `created_at`. FK to `support_tickets(id)` with cascade delete. |
| `support_ticket_events`      | Append-only activity log per ticket (`created`, `updated`, `status_changed`, `comment_added`, …). Tenant-isolated; indexed on `tenant_id`, `ticket_id`, `created_at`. FK to `support_tickets(id)` with cascade delete. |

Comment enum columns (`comment_type`, `visibility`) are stored as strings via
EF value conversion. Events store free-form JSON in `metadata_json` to avoid
schema churn for new event types.

---

## 3. API endpoints added

| Verb | Route                                          | Purpose |
|------|------------------------------------------------|---------|
| POST | `/support/api/tickets/{id}/comments`           | Add a comment (default `CustomerReply` / `CustomerVisible`). |
| GET  | `/support/api/tickets/{id}/comments`           | List comments ASC; optional `visibility` and `comment_type` filters. |
| GET  | `/support/api/tickets/{id}/timeline`           | Unified `comment` + `event` timeline ordered ASC. |

All three reject cross-tenant access with `404` (indistinguishable from
not-found). Missing tenant returns `400`. Validation errors return RFC 7807
`ValidationProblem`. Endpoints are visible in Swagger under the **Comments**
tag.

---

## 4. Event logging behaviour

| Trigger              | `event_type`     | `summary`                          | `metadata_json` |
|----------------------|------------------|------------------------------------|-----------------|
| `POST /tickets`      | `created`        | `Ticket created`                   | `{ "ticket_number": "SUP-…" }` |
| `PUT /tickets/{id}` (any field changes) | `updated` | `Ticket updated`                   | – |
| `PUT /tickets/{id}` with new status     | `status_changed` | `Status changed from {From} to {To}` | `{ "from": "…", "to": "…" }` |
| `POST /tickets/{id}/comments` | `comment_added` | `Comment added`             | `{ "comment_id": "…", "visibility": "…" }` |

Logging is performed in the service layer (`TicketService` / `CommentService`),
never in the endpoints. Events queue into the DbContext change tracker and
commit atomically with the ticket/comment write — no events are persisted for
failed mutations.

---

## 5. Validation rules

`CreateCommentRequestValidator`:
- `body` — required, max 8000 chars.
- `comment_type` — must be a valid `CommentType` enum value when supplied.
- `visibility` — must be a valid `CommentVisibility` enum value when supplied.
- `author_email` — must be a valid email address when supplied.
- `author_user_id` — max 64 chars.
- `author_name` — max 200 chars.

---

## 6. Test results

```
Passed!  - Failed: 0, Passed: 25, Skipped: 0, Total: 25
```

New SUP-B02 coverage (12 tests in `CommentApiTests`):

| Test                                              | Acceptance item |
|---------------------------------------------------|-----------------|
| `Add_Comment_Succeeds`                            | POST happy path |
| `Add_Comment_Fails_If_Ticket_Not_Found`           | 404 for unknown ticket |
| `Add_Comment_Fails_For_Wrong_Tenant`              | Tenant isolation on comment write |
| `Add_Comment_Fails_For_Empty_Body`                | FluentValidation `body` required |
| `List_Comments_Ordered_Asc_And_Tenant_Scoped`     | List ordering + tenant scope |
| `List_Comments_Cross_Tenant_Returns_404`          | Tenant isolation on `GET /comments` |
| `Timeline_Returns_Events_And_Comments_In_Order`   | Unified timeline + ASC ordering |
| `Timeline_Cross_Tenant_Returns_404`               | Tenant isolation on `GET /timeline` |
| `Timeline_Without_Tenant_Returns_400`             | Missing tenant → 400 on `GET /timeline` |
| `Ticket_Creation_Logs_Created_Event`              | Auto event on `POST /tickets` |
| `Ticket_Update_Logs_Updated_Event`                | Auto event on `PUT /tickets` |
| `Status_Change_Logs_Event_With_Metadata`          | `status_changed` + JSON `{from,to}` |

All 13 SUP-B01 tests continue to pass — no regressions.

Run locally:

```bash
cd services/support
dotnet build
dotnet test
```

Migration:

```bash
dotnet ef database update --project Support.Api
# applies: 20260424020928_InitialSupportSchema
#          20260424022505_AddSupportCommentsAndEvents
```

---

## 7. Known gaps

- **Attachments** — explicitly out of scope; will land in SUP-B03.
- **Notifications / Comms / Audit fan-out** — events are persisted locally only; no outbox or message-bus publication. To be added when the notification service is wired up.
- **Tenant trust at the edge** — same caveat as SUP-B01: in production the tenant must come from a verified JWT claim, not the `X-Tenant-Id` header. The middleware already prefers the claim when present; the header fallback exists for service-to-service calls until the auth gateway lands (SUP-AUTH).
- **Timeline pagination** — endpoints return the full timeline. Pagination/cursoring will be added when ticket activity volume warrants it.
- **Author identity provenance** — `author_user_id` / `author_name` / `author_email` are accepted from the request body for now; once auth is wired they should be derived from the authenticated principal and rejected from the body.

---

## Acceptance checklist

| # | Criterion | Status |
|---|-----------|--------|
| 1 | `support_ticket_comments` table exists | ✅ |
| 2 | `support_ticket_events` table exists | ✅ |
| 3 | Comment create/list APIs work | ✅ |
| 4 | Timeline API returns unified results | ✅ |
| 5 | Auto event logging (create / update / status / comment) | ✅ |
| 6 | Tenant isolation enforced on all new endpoints | ✅ |
| 7 | Validation implemented | ✅ |
| 8 | Migration created and applied | ✅ `AddSupportCommentsAndEvents` |
| 9 | Tests added and passing | ✅ 25/25 |
| 10 | Report updated | ✅ this file + `analysis/SUP-B01-report.md` |

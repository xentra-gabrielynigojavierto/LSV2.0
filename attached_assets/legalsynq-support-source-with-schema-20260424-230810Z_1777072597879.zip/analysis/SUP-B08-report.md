# SUP-B08 — Audit Integration

## 1. Codebase analysis

Going into SUP-B08 the Support Service already had a clean dispatch boundary
(`INotificationPublisher`) introduced in SUP-B07, plus an in-DB `EventLogger`
(`IEventLogger`) that captures human-readable timeline entries against each
ticket. The two surfaces are deliberately distinct:

- `IEventLogger` writes to `ticket_events` for end-user "ticket history" UX.
- `INotificationPublisher` fans out to subscribers (queue members,
  requesters) for messaging.

Neither was suitable as a compliance audit trail:

- `ticket_events` is tenant-scoped and intentionally summary-grade.
- Notifications are recipient-targeted; many compliance-relevant actions
  (e.g. queue config changes) have no recipients at all.

So SUP-B08 introduces a third, parallel dispatch boundary —
`IAuditPublisher` — modeled on the SUP-B07 notification pattern. The
existing `TenantContext` already exposes `TenantId` / `UserId` derived from
the JWT, but it does not expose roles / email / correlation metadata, so a
new `IActorAccessor` was introduced to read those claims from
`IHttpContextAccessor` without disturbing tenant resolution.

The five service classes that needed wiring (`TicketService`,
`CommentService`, `TicketAttachmentService`,
`TicketProductReferenceService`, `QueueService`) all already had a
`try/catch`-wrapped notification dispatch, which gave a known-good template
for the audit dispatch — same shape, same isolation guarantees.

---

## 2. Files created / changed

### New (Support.Api)

- `services/support/Support.Api/Audit/SupportAuditEvent.cs` — wire
  contract (record + `SupportAuditEventTypes`, `SupportAuditResourceTypes`,
  `SupportAuditActions`, `SupportAuditOutcomes` constants).
- `services/support/Support.Api/Audit/AuditOptions.cs` — bound from
  `Support:Audit` configuration section.
- `services/support/Support.Api/Audit/IAuditPublisher.cs` — abstraction.
- `services/support/Support.Api/Audit/NoOpAuditPublisher.cs` — default
  publisher; logs would-be dispatch and honors `Enabled` flag.
- `services/support/Support.Api/Audit/HttpAuditPublisher.cs` — typed
  `HttpClient` adapter (named `support-audit`); POSTs to
  `{BaseUrl}/audit-events`; never throws.
- `services/support/Support.Api/Auth/ActorAccessor.cs` —
  `AuditActor`, `AuditRequestContext`, `IActorAccessor`, and the
  `HttpContextActorAccessor` implementation.

### Changed (Support.Api)

- `Program.cs` — `using Support.Api.Audit;`,
  `AddHttpContextAccessor()`, `AddScoped<IActorAccessor,
  HttpContextActorAccessor>()`, `Configure<AuditOptions>`, mode-driven
  registration of `HttpAuditPublisher` (typed client) or
  `NoOpAuditPublisher` (singleton).
- `appsettings.json` — added `Support:Audit` block (`Enabled=false`,
  `Mode=NoOp`, `BaseUrl=null`, `TimeoutSeconds=5`).
- `Services/TicketService.cs` — injected `IAuditPublisher` /
  `IActorAccessor`; added `TryAuditAsync` + `BuildTicketAudit` helpers;
  emits `support.ticket.created` (Create), `support.ticket.status_changed`
  + `support.ticket.updated` (Update), `support.ticket.assignment_changed`
  (Assign).
- `Services/CommentService.cs` — emits
  `support.ticket.comment_added`, body length only — never body content.
- `Services/TicketAttachmentService.cs` — emits
  `support.ticket.attachment_added` with file metadata only.
- `Services/TicketProductReferenceService.cs` — emits
  `support.ticket.product_ref_linked` and `…product_ref_removed`.
- `Services/QueueService.cs` — emits `support.queue.created`,
  `…updated`, `…member_added` (both insert + reactivate paths), and
  `…member_removed`.

### New (Support.Tests)

- `services/support/Support.Tests/RecordingAuditPublisher.cs` —
  thread-safe in-memory publisher with `ThrowOnPublish` toggle and
  `ForTenant` / `ForResource` / `OfType` selectors.
- `services/support/Support.Tests/AuditApiFactory.cs` — only swaps
  `IAuditPublisher`; notifications stay on the default `NoOp` so audit
  assertions are not polluted.
- `services/support/Support.Tests/AuditTests.cs` — 14 tests covering
  every spec event + failure isolation + actor enrichment + NoOp flag.

---

## 3. Audit integration approach

- Service-layer placement only. No endpoint code emits audit events; this
  keeps the boundary identical to the existing notification dispatch and
  guarantees coverage regardless of future endpoint refactors.
- Single abstraction (`IAuditPublisher`) with a transport adapter selected
  by configuration (`Support:Audit:Mode`). Default `NoOp` is safe for
  local + test runs and for any environment where the Audit Service is
  not reachable.
- Each service holds a private `TryAudit…Async` wrapper that swallows
  exceptions and logs them at `Warning`. Audit dispatch can never roll
  back the underlying ticket / comment / queue mutation.
- Actor enrichment runs through `IActorAccessor`. It reads the JWT
  (`sub`, `name`, `email`, both singular `role` and plural `roles`
  claims, plus the .NET `ClaimTypes.NameIdentifier` / `ClaimTypes.Name`
  / `ClaimTypes.Email` / `ClaimTypes.Role` fallbacks) and request
  metadata (`X-Correlation-Id` / `X-Request-Id` / `TraceIdentifier`,
  `RemoteIpAddress`, `User-Agent`). The plural `roles` claim is itself
  parsed for comma / space / semicolon delimiters to cover both
  Microsoft (one claim per role) and Auth0 (single delimited claim)
  conventions; values are case-insensitively de-duplicated. When the
  principal is anonymous (background work / future system flows) the
  accessor returns nulls and the service falls back to
  `TenantContext.UserId` or any domain-supplied actor id (e.g. comment
  author) — never to a request body actor field.

### Why a new accessor instead of extending `TenantContext`

`TenantContext` is intentionally minimal — tenant + user only. Roles,
email, correlation metadata, IP, and user-agent are concerns of the
audit / observability surface, not of tenant resolution. Adding them to
`TenantContext` would expand its blast radius and force every consumer
to re-read the JWT on each access.

---

## 4. Audit event mapping

| Event type                                | Trigger                                                | Resource type            | Action            | Metadata keys |
|-------------------------------------------|--------------------------------------------------------|--------------------------|-------------------|---------------|
| `support.ticket.created`                  | `TicketService.CreateAsync`                            | `support_ticket`         | `create`          | `title`, `priority`, `status`, `product_code`, `requester_user_id`, `requester_email` |
| `support.ticket.updated`                  | `TicketService.UpdateAsync`                            | `support_ticket`         | `update`          | `status`, `priority`, `assigned_user_id`, `assigned_queue_id`, `title_changed`, `description_changed`, `category_changed`, `due_at_changed` |
| `support.ticket.status_changed`           | `TicketService.UpdateAsync` (status delta)             | `support_ticket`         | `status_change`   | `previous_status`, `new_status` |
| `support.ticket.assignment_changed`       | `TicketService.AssignAsync`                            | `support_ticket`         | `assign`          | `previous_assigned_user_id`, `previous_assigned_queue_id`, `assigned_user_id`, `assigned_queue_id`, `cleared` |
| `support.ticket.comment_added`            | `CommentService.AddAsync`                              | `support_ticket`         | `comment_add`     | `comment_id`, `comment_type`, `visibility`, `author_user_id`, `body_length` |
| `support.ticket.attachment_added`         | `TicketAttachmentService.AddAsync`                     | `support_ticket`         | `attachment_link` | `attachment_id`, `document_id`, `file_name`, `content_type`, `file_size_bytes` |
| `support.ticket.product_ref_linked`       | `TicketProductReferenceService.AddAsync`               | `support_ticket`         | `product_ref_link` | `product_ref_id`, `product_code`, `entity_type`, `entity_id`, `display_label` |
| `support.ticket.product_ref_removed`      | `TicketProductReferenceService.RemoveAsync`            | `support_ticket`         | `product_ref_remove` | `product_ref_id`, `product_code`, `entity_type`, `entity_id` |
| `support.queue.created`                   | `QueueService.CreateAsync`                             | `support_queue`          | `create`          | `queue_id`, `name`, `product_code`, `is_active` |
| `support.queue.updated`                   | `QueueService.UpdateAsync`                             | `support_queue`          | `update`          | `queue_id`, `name`, `product_code`, `is_active` |
| `support.queue.member_added`              | `QueueService.AddMemberAsync` (insert + reactivate)    | `support_queue_member`   | `member_add`      | `queue_id`, `user_id`, `role`, `is_active` |
| `support.queue.member_removed`            | `QueueService.RemoveMemberAsync`                       | `support_queue_member`   | `member_remove`   | `queue_id`, `user_id`, `role`, `is_active` |

Resource enrichment notes:

- For ticket-resource events, `resource_id` is the ticket id and
  `resource_number` is the human ticket number (`SUP-YYYY-######`).
- For queue / queue-member events, `resource_number` is null.
- For attachment / product-ref events, the underlying resource is still
  the parent ticket (so a single ticket's audit log contains all related
  activity); the attachment / product-ref id is in metadata.

### Sensitive-data exclusions

- Comment body content is never placed in metadata — only `body_length`.
  `Comment_Added_Emits_Audit_Event_Without_Body` actively asserts no
  metadata value contains the original body text.
- Attachment file contents are never placed in metadata; only
  `document_id` / `file_name` / `content_type` / `file_size_bytes`.
- No JWT or session token ever appears in metadata.

---

## 5. Configuration changes

`appsettings.json`:

```jsonc
"Support": {
  "Notifications": { /* unchanged */ },
  "Audit": {
    "Enabled": false,        // master kill-switch
    "Mode": "NoOp",          // NoOp | Http
    "BaseUrl": null,         // required when Mode=Http
    "TimeoutSeconds": 5      // upper bound on a single dispatch
  }
}
```

`Program.cs` registers:

- `IHttpContextAccessor`
- `IActorAccessor` → `HttpContextActorAccessor` (scoped)
- `IOptions<AuditOptions>` bound from `Support:Audit`
- `IAuditPublisher` → `HttpAuditPublisher` (typed `HttpClient` named
  `support-audit`) **iff** `Mode = Http`, otherwise singleton
  `NoOpAuditPublisher`.

The HTTP transport links the call's `CancellationToken` to a per-call
timeout (`TimeoutSeconds`) so a hanging Audit Service cannot stall a
Support write.

---

## 6. Failure handling behavior

Audit dispatch is best-effort. The contract is enforced at three layers:

1. **HttpAuditPublisher** wraps the HTTP call in `try/catch`, logs at
   `Warning`, and returns normally on transport / serialization /
   timeout exceptions. Non-2xx responses are also logged but never
   thrown.
2. **NoOpAuditPublisher** never throws; honours `Enabled=false` by
   short-circuiting at `Debug` level (no Information-level log spam
   when audit is disabled).
3. **Each service** wraps the publisher call in its own
   `TryAudit…Async` (`try/catch` → `_log.LogWarning(ex, …)`). Even if a
   buggy custom publisher were registered that threw, the surrounding
   ticket / comment / queue mutation has already been committed and the
   HTTP response will still be 2xx.

`Audit_Failure_Does_Not_Break_Ticket_Create` and
`Audit_Failure_Does_Not_Break_Comment_Add` exercise this with a
`RecordingAuditPublisher` flipped into throwing mode.

No durable outbox is introduced in this block — that is explicitly
deferred per the spec.

---

## 7. Test results

```
=== AuthTests ===                Total: 13   Passed: 13   Failed: 0
=== AuthStartupTests ===         Total:  8   Passed:  8   Failed: 0
=== TicketApiTests ===           Total: 13   Passed: 13   Failed: 0
=== CommentApiTests ===          Total: 12   Passed: 12   Failed: 0
=== AttachmentApiTests ===       Total:  7   Passed:  7   Failed: 0
=== ProductRefApiTests ===       Total:  7   Passed:  7   Failed: 0
=== QueueAndAssignmentTests ===  Total: 21   Passed: 21   Failed: 0
=== NotificationTests ===        Total: 10   Passed: 10   Failed: 0
=== AuditTests ===               Total: 16   Passed: 16   Failed: 0

Backend total:                   Total: 107  Passed: 107  Failed: 0
```

The 16 new audit tests cover:

1. `Ticket_Created_Emits_Audit_Event` — schema + actor + metadata.
2. `Ticket_Updated_Emits_Audit_Event` — change-flag metadata.
3. `Ticket_Status_Change_Emits_Status_And_Update_Audit_Events` — both
   `status_changed` and `updated` fire on a status delta, with
   `previous_status` / `new_status`.
4. `Ticket_Assignment_Emits_Audit_Event` — assigned-user + cleared.
5. `Comment_Added_Emits_Audit_Event_Without_Body` — body length present,
   body content provably absent.
6. `Attachment_Added_Emits_Audit_Event_Without_Contents` — file
   metadata only; no `content` / `bytes` keys.
7. `Product_Reference_Linked_And_Removed_Emit_Audit_Events` — both
   transitions in one flow.
8. `Queue_Created_Emits_Audit_Event` — `support_queue` resource type.
9. `Queue_Updated_Emits_Audit_Event` — name change.
10. `Queue_Member_Added_And_Removed_Emit_Audit_Events` —
    `support_queue_member` resource type, both transitions.
11. `Audit_Failure_Does_Not_Break_Ticket_Create` — throwing publisher;
    ticket POST still 201.
12. `Audit_Failure_Does_Not_Break_Comment_Add` — throwing publisher;
    comment POST still 2xx.
13. `Audit_Event_Includes_Actor_Roles_And_Correlation_Id` — JWT roles,
    `X-Correlation-Id`, and `User-Agent` flow through to the event;
    `OccurredAt` is UTC.
14. `NoOp_Publisher_Honors_Disabled_Flag` — `NoOpAuditPublisher` is
    no-throw with `Enabled` true or false.
15. `Actor_Accessor_Reads_Name_And_Plural_Roles_Claims` — JWT `name`
    claim and Auth0-style plural `roles` claim (comma- or
    space-delimited) flow into `AuditActor`, with case-insensitive
    de-duplication against per-claim `role` values.
16. `Actor_Accessor_Returns_Empty_For_Unauthenticated_Principal` —
    anonymous principals yield an empty actor (no exceptions, no
    leakage of test defaults).

---

## 8. Build results

```
$ dotnet build Support.sln --no-restore
    4 Warning(s)   (pre-existing: 2× CS0618 ISystemClock obsolete in
                   TestAuthHandler, 2× CS8604 nullable refs in
                   CommentApiTests / ProductRefApiTests)
    0 Error(s)
```

Both `Support.Api` and `Support.Tests` compile clean. No new warnings
introduced by SUP-B08. The previously emitted MSB3277 (conflicting
`Microsoft.EntityFrameworkCore.Relational` versions 8.0.2 vs 8.0.10
between `Pomelo.EntityFrameworkCore.MySql` 8.0.2 and the explicit EF
Core 8.0.10 references) has been resolved by pinning
`Microsoft.EntityFrameworkCore.Relational` 8.0.10 in
`Support.Api.csproj`, which forces a unified runtime version through
the transitive graph.

---

## 9. Known gaps / deferred items

- **Durable audit outbox** — explicitly deferred. Today, an Audit
  Service outage means lost dispatches (logged but not retried). Adding
  an outbox table + dispatcher belongs in a future block alongside any
  similar reliability work for notifications.
- **Audit viewer UI** — out of scope per the spec.
- **HTTP retry policy** — `HttpAuditPublisher` is single-attempt; a
  Polly retry / circuit breaker can be layered on later when an outbox
  exists.
- **Bulk / batch dispatch** — events are emitted one-by-one. A status
  change on a busy ticket produces two events
  (`status_changed` + `updated`); both POSTs run sequentially.
  Acceptable for current load profiles.
- **Background system actions** — there are none today, so the
  "actor = system" path is exercised only by `_tenant.UserId` /
  domain-actor fallbacks. When a future scheduler emits events, it
  should explicitly set `ActorUserId = "system"`.
- **Schema versioning** — `SupportAuditEvent` is not yet versioned. If
  the wire format needs to evolve incompatibly, add an explicit
  `schema_version` field before that change rather than relying on
  duck-typing.
